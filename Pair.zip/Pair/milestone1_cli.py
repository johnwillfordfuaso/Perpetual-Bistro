#!/usr/bin/env python3
"""
milestone1_cli.py - Milestone 1 verification: SPEECH -> FSM -> SQLite, with no GUI.

For every turn it prints the evidence the panel wants to see:
    HEARD   what the speech-to-text produced (after the repair of common recognition mistakes)
    FSM     the state transition(s) that turn caused
    TOOL    the SQLite tool calls Qwen made (or GUARD if a guardrail answered before the model)
    SQLITE  the live tab and orders read back from restaurant.db
    Waiter  the reply (also spoken with pyttsx3)

Ways to run it
    python milestone1_cli.py                 real microphone + speakers + Ollama (press Enter, then speak)
    python milestone1_cli.py --text          type instead of speak (same evidence output)
    python milestone1_cli.py --wav a.wav b.wav   feed recorded speech files through the real STT
    python milestone1_cli.py --selftest      NO microphone, NO Ollama: a simulated microphone and a scripted
                                             "Qwen" run the whole pipeline and ASSERT the results in SQLite.
                                             Exit code 0 = Milestone 1 pipeline verified.
    python milestone1_cli.py --list-voices   show the TTS voices installed on this computer
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Callable, Optional

import db_tools as db
from fsm_agent import FSMAgent, LLMError, OllamaClient, STATE_GREETING
from speech_engine import ScriptedSTT, SpeechEngine, SpeechError, SpeechRecognitionSTT, correct_transcript

HERE = Path(__file__).resolve().parent
LINE = "-" * 72


# ---------------------------------------------------------------------------------------------
# Evidence printing
# ---------------------------------------------------------------------------------------------
def describe_turn(agent: FSMAgent, heard: str, reply: str, out: Callable[[str], None] = print) -> None:
    turn = agent.log["turns"][-1]
    out(LINE)
    out(f"  HEARD  : {heard!r}")
    trans = turn["state_transitions"]
    if trans:
        chain = " -> ".join([trans[0]["from"]] + [t["to"] for t in trans])
        out(f"  FSM    : {chain}")
    else:
        out(f"  FSM    : {turn['state_after']}  (no change)")
    for call in turn["tool_calls"]:
        res = call.get("result") or {}
        args = call.get("arguments") or {}
        if call["tool"] == "guardrail":
            what = args.get("category") or args.get("scope") or ""
            out(f"  GUARD  : {args.get('type')} ({what}) -> answered in code, model not called")
        else:
            short = ", ".join(f"{k}={v!r}" for k, v in args.items() if k != "confirmed_by_customer")
            out(f"  TOOL   : {call['tool']}({short}) -> {res.get('status', '?')}"
                + (f" [{res.get('error')}]" if res.get("error") else ""))
    sid = agent.session_id
    if sid:
        view = db.view_current_order(sid)
        tab = ", ".join(f"{i['quantity']}x {i['name']}" for i in view.get("items", [])) or "empty"
        orders = db.session_orders(sid)
        sent = ", ".join(f"#{o['order_id']}:{o['status']}" for o in orders) or "none"
        out(f"  SQLITE : session #{sid} (table {agent.table_no}) | tab: {tab} | orders: {sent}")
    else:
        out("  SQLITE : no active session")
    first = reply.strip().splitlines()[0] if reply.strip() else ""
    out(f"  Waiter : {first[:110]}")


def process_utterance(agent: FSMAgent, engine: SpeechEngine, heard: str, out: Callable[[str], None] = print) -> Optional[str]:
    """One full turn: text from the microphone -> FSM agent -> evidence -> spoken reply."""
    if not heard.strip():
        engine.send_output("Sorry, I didn't catch that. Could you say it again?")
        return None
    if heard.strip().lower() in ("/quit", "quit", "exit", "goodbye", "bye"):
        return "QUIT"
    reply = agent.handle(heard)
    describe_turn(agent, heard, reply, out)
    engine.echo = False                              # evidence block already printed the reply
    engine.send_output(reply)
    return reply


# ---------------------------------------------------------------------------------------------
# Self-test (no hardware, no Ollama)
# ---------------------------------------------------------------------------------------------
class ScriptedLLM:
    """Stands in for Qwen: replays tool-call JSON exactly as the real model would emit it."""

    def __init__(self, outputs):
        self.outputs = list(outputs)

    def __call__(self, messages):
        if not self.outputs:
            raise LLMError("scripted LLM ran out of outputs")
        return self.outputs.pop(0)


def _call(tool: str, **arguments) -> str:
    return json.dumps({"tool": tool, "arguments": arguments})


def selftest() -> int:
    results: list[tuple[bool, str]] = []

    def check(ok: bool, label: str) -> None:
        results.append((bool(ok), label))
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")

    with tempfile.TemporaryDirectory() as tmp:
        dbfile = Path(tmp) / "milestone1.db"
        db.set_db_path(dbfile)
        db.init_db(reset=True)
        raw = sqlite3.connect(dbfile)                   # an independent connection = proof it is really in SQLite
        raw.row_factory = sqlite3.Row
        menu_names = [i["name"] for cat in db.get_menu_by_category("all")["menu"].values() for i in cat]
        raw.execute("UPDATE menu SET stock_qty = 0 WHERE name = 'Onion Rings'")     # edge case: sold out
        raw.commit()

        llm = ScriptedLLM([
            _call("add_item_to_order", item_name="Cheeseburger", qty=2, instructions="no onions"), "Two cheeseburgers, no onions.",
            _call("add_item_to_order", item_name="Onion Rings", qty=1), "Sorry, the Onion Rings are sold out today.",
        ])
        agent = FSMAgent(llm, llm_label="scripted-qwen (selftest)", confirm_ai_orders=True)
        mic = ScriptedSTT([
            "table for",                                    # ASR error: must become "table 4"
            "what's the weather like today",                # off-topic guardrail
            "two cheese burger without onions please",      # ASR error: must become Cheeseburger
            "yes",
            "one onion rings please",                       # sold-out edge case
            "that's all",
            "gcash",
            "cancel my order",                              # post-CONFIRMED edge case
            "remove the cheeseburger",
        ], vocabulary=menu_names)
        engine = SpeechEngine(mic, None, echo=False, speak_replies=False)

        print("\nMILESTONE 1 SELF-TEST  (simulated microphone -> FSM -> SQLite)\n")
        print(f"  greeting: {agent.start()[:70]}...")

        def turn() -> str:
            return process_utterance(agent, engine, mic.listen())

        # 1. spoken table number -> GREETING -> TAKING_ORDER, session row written
        turn()
        row = raw.execute("SELECT table_no, status FROM sessions ORDER BY session_id DESC LIMIT 1").fetchone()
        check(agent.log["turns"][-1]["state_before"] == STATE_GREETING and agent.state == "STATE_TAKING_ORDER",
              "spoken 'table for' (misheard) -> corrected to table 4 -> GREETING to TAKING_ORDER")
        check(row and row["table_no"] == 4 and row["status"] == "active", "SQLite: sessions row created for table 4")

        # 2. off-topic
        calls_before = len(llm.outputs)
        reply = turn()
        check(len(llm.outputs) == calls_before and "Perpetual Bistro" in reply, "off-topic question refused in code; Qwen was never called")

        # 3-4. spoken order -> tool call -> confirm -> cart row
        turn()
        n = raw.execute("SELECT COUNT(*) FROM order_items").fetchone()[0]
        check(n == 0, "AI-proposed item is only staged (no cart row until the customer says yes)")
        turn()
        line = raw.execute("SELECT name, quantity, instructions FROM order_items").fetchone()
        check(line and line["name"] == "Cheeseburger" and line["quantity"] == 2 and "onions" in (line["instructions"] or "").lower(),
              "SQLite: order_items has 2x Cheeseburger with the 'no onions' instruction")

        # 5. sold out
        reply = turn()
        names = [r["name"] for r in raw.execute("SELECT name FROM order_items")]
        check("Onion Rings" not in names and "sold out" in reply.lower(), "out-of-stock item blocked by db_tools; nothing added to the cart")

        # 6-7. review then confirm
        turn()
        check(agent.state == "STATE_REVIEW", "'that's all' -> TAKING_ORDER to REVIEW (itemised tab shown)")
        turn()
        turn_log = agent.log["turns"][-1]
        chain = [t["to"] for t in turn_log["state_transitions"]]
        order = raw.execute("SELECT order_id, status, payment_method FROM orders").fetchone()
        stock = raw.execute("SELECT stock_qty FROM menu WHERE name = 'Cheeseburger'").fetchone()[0]
        check("STATE_CONFIRMED" in chain, "'gcash' -> REVIEW to CONFIRMED (transaction committed)")
        check(order and order["status"] == "received" and order["payment_method"] == "GCash", "SQLite: orders row written (status received, GCash)")
        check(stock == 18, "SQLite: Cheeseburger stock reduced 20 -> 18 atomically on confirm")

        # 8-9. post-CONFIRMED edit / cancel attempts
        before_lines = raw.execute("SELECT name, quantity FROM order_lines").fetchall()
        reply = turn()
        reply2 = turn()
        order2 = raw.execute("SELECT status FROM orders").fetchone()
        after_lines = raw.execute("SELECT name, quantity FROM order_lines").fetchall()
        req = raw.execute("SELECT kind, status FROM service_requests").fetchall()
        check(order2["status"] == "received" and [tuple(r) for r in before_lines] == [tuple(r) for r in after_lines],
              "after CONFIRMED: 'cancel my order' / 'remove the cheeseburger' do NOT change the order in SQLite")
        check("already with the kitchen" in reply and "already with the kitchen" in reply2, "waiter explains the order is locked")
        check(len(req) == 1 and req[0]["kind"] == "cancel_order", "request handed to staff (service_requests: cancel_order, de-duplicated)")

        # 10. state skipping
        raw.close()
        db.init_db(reset=True)                          # fresh database file -> fresh raw connection
        raw = sqlite3.connect(dbfile)
        a2 = FSMAgent(ScriptedLLM([]), llm_label="skip-test")
        a2.start()
        outs = [a2.handle("yes"), a2.handle("confirm"), a2.handle("/confirm"), a2.handle("gcash")]
        orders_n = raw.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
        check(a2.state == STATE_GREETING and orders_n == 0, "GREETING cannot jump to CONFIRMED ('yes' / 'confirm' / '/confirm' / 'gcash' ignored)")
        raw.close()

    failed = [label for ok, label in results if not ok]
    print(LINE)
    print(f"  {len(results) - len(failed)}/{len(results)} checks passed" + ("" if not failed else "  -> FAILED"))
    return 1 if failed else 0


# ---------------------------------------------------------------------------------------------
# Real run
# ---------------------------------------------------------------------------------------------
def real_run(args) -> int:
    from virtual_waiter_prototype import check_ollama           # same Ollama check as the Lab 6.1 CLI
    db.set_db_path(args.db)
    db.init_db(reset=args.reset_db)
    check_ollama(args.host, args.model)
    menu_names = [i["name"] for cat in db.get_menu_by_category("all")["menu"].values() for i in cat]

    if args.text:
        engine = SpeechEngine(None, None, echo=True, speak_replies=False)
    else:
        engine = SpeechEngine.auto(menu_names, args.stt_backend, args.whisper_model, args.voice, args.rate, args.mic_index,
                                   want_stt=not args.wav, want_tts=not args.no_tts)
        if args.wav:
            engine.stt = SpeechRecognitionSTT(args.stt_backend, whisper_model=args.whisper_model, vocabulary=menu_names)

    st = engine.status()
    print(f"Speech: STT={st['stt'] or 'off (typing)'}  TTS={st['tts'] or 'off'}")
    for note in st["notes"]:
        print(f"  note: {note}")

    agent = FSMAgent(OllamaClient(args.model, args.host), llm_label=args.model)
    engine.echo = True
    engine.send_output(agent.start())
    engine.echo = False
    try:
        if args.wav:
            for path in args.wav:
                heard = engine.stt.transcribe_file(path)
                print(f"\n[{path}]")
                if process_utterance(agent, engine, heard) == "QUIT":
                    break
        else:
            while True:
                try:
                    heard = engine.get_input() if not args.text else input("You: ")
                except (EOFError, KeyboardInterrupt):
                    print()
                    break
                if args.text:
                    heard = correct_transcript(heard, menu_names) if heard and not heard.startswith("/") else heard
                if process_utterance(agent, engine, heard) == "QUIT":
                    break
    finally:
        agent.save_log(args.log)
        agent.shutdown()
        print(f"\nConversation log saved to {args.log}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Milestone 1: voice -> FSM -> SQLite command-line test")
    ap.add_argument("--selftest", action="store_true", help="simulated microphone + scripted Qwen; asserts the SQLite results")
    ap.add_argument("--text", action="store_true", help="type instead of speaking")
    ap.add_argument("--wav", nargs="+", metavar="FILE", help="transcribe these WAV files instead of using the microphone")
    ap.add_argument("--list-voices", action="store_true")
    ap.add_argument("--model", default="qwen2.5:3b", help="Ollama model (qwen2.5:7b recommended, qwen2.5:3b for 8GB laptops)")
    ap.add_argument("--host", default="http://localhost:11434")
    ap.add_argument("--db", default=str(HERE / "restaurant.db"))
    ap.add_argument("--log", default=str(HERE / "milestone1_log.json"))
    ap.add_argument("--reset-db", action="store_true", help="rebuild the database (restores stock)")
    ap.add_argument("--stt-backend", default="auto", choices=["auto", "whisper", "faster-whisper", "vosk", "sphinx"])
    ap.add_argument("--whisper-model", default="base.en", help="tiny.en / base.en / small.en ...")
    ap.add_argument("--voice", help="part of a TTS voice name, e.g. 'zira' or 'english'")
    ap.add_argument("--rate", type=int, default=170, help="speaking speed in words per minute")
    ap.add_argument("--mic-index", type=int)
    ap.add_argument("--no-tts", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        return selftest()
    if args.list_voices:
        from speech_engine import Pyttsx3TTS
        try:
            for v in Pyttsx3TTS().list_voices():
                print(f"{v['name']}  [{v['id']}]")
        except SpeechError as exc:
            print(exc)
            return 1
        return 0
    return real_run(args)


if __name__ == "__main__":
    sys.exit(main())
