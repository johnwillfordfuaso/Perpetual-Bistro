"""Adds Cordon Bleu, Steak Sandwich, Ravioli Pasta and Caesar Salad to the Perpetual Bistro menu.
Run once from the project folder (stop the server first, or just restart it afterwards):
    python add_new_dishes.py
Safe to run twice - dishes that already exist are skipped. Edit prices/descriptions here or later in Admin > Menu & stock."""
import sys
from pathlib import Path

import db_tools as db

DB_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "restaurant.db"

DISHES = [
    dict(name="Cordon Bleu", category="Mains", price=240, stock=20, vegetarian=False, allergens="gluten, dairy, egg",
         description="Crumb-coated chicken rolled around ham and melted cheese, baked golden. Served with rice."),
    dict(name="Steak Sandwich", category="Mains", price=260, stock=15, vegetarian=False, allergens="gluten, dairy, egg",
         description="Sliced grilled beef steak, caramelised onions, tomato and rocket on toasted flatbread with garlic mayo."),
    dict(name="Ravioli Pasta", category="Mains", price=230, stock=18, vegetarian=False, allergens="gluten, dairy, egg",
         description="Handmade pasta pillows in brown-butter sauce with crispy sage and bacon bits."),
    dict(name="Caesar Salad", category="Sides", price=150, stock=25, vegetarian=False, allergens="gluten, dairy, egg, fish",
         description="Crisp greens with crunchy croutons, shaved parmesan, grated egg and creamy Caesar dressing."),
]

db.set_db_path(DB_FILE)
db.init_db()                       # upgrades an older database in place if needed
for d in DISHES:
    r = db.admin_add_menu_item(**d)
    print(("added:   " if r["status"] == "ok" else "skipped: ") + d["name"] + ("" if r["status"] == "ok" else f" ({r.get('error')})"))
print("Done. Restart the server (or just refresh) to see them.")