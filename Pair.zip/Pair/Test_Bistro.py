"""Perpetual Bistro tests. Run from the project folder:  python3 -m unittest discover -s tests -v
No Ollama needed: the FSM tests use a scripted LLM and the API tests start the real server as a subprocess."""
import http.cookiejar, json, os, socket, subprocess, sys, tempfile, time, unittest, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import db_tools as db
from fsm_agent import FSMAgent, LLMError, parse_simple_order


class ScriptedLLM:
    def __init__(self, outputs): self.outputs = list(outputs)
    def __call__(self, messages): return self.outputs.pop(0)


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        db.set_db_path(Path(self.tmp.name) / "t.db")
        db.init_db(reset=True)
    def tearDown(self): self.tmp.cleanup()

    def session(self, table=1):
        r = db.create_table_session(table)
        return r["session_id"]


class TestDb(DbCase):
    def test_add_deducts_stock_on_confirm_and_cancel_restores(self):
        sid = self.session()
        item = next(i for items in db.get_menu_by_category("all")["menu"].values() for i in items if i["name"] == "Cheeseburger")
        before = item["stock"]
        self.assertEqual(db.add_item_to_order(sid, "Cheeseburger", 2)["status"], "ok")
        res = db.confirm_order(sid, "Cash")
        self.assertEqual(res["status"], "ok")
        oid = res["order_id"]
        after = db.list_menu_items()
        stock = lambda: next(i for i in db.list_menu_items() if i["name"] == "Cheeseburger")["stock"]
        self.assertEqual(stock(), before - 2)
        db.set_order_status(oid, "cancelled", "test", "manager")
        self.assertEqual(stock(), before)

    def test_cannot_order_sold_out_or_more_than_stock(self):
        sid = self.session()
        self.assertNotEqual(db.add_item_to_order(sid, "Onion Rings", 1)["status"], "ok")      # seeded as sold out
        self.assertNotEqual(db.add_item_to_order(sid, "Cheeseburger", 9999)["status"], "ok")

    def test_status_must_advance_one_step(self):
        sid = self.session(); db.add_item_to_order(sid, "Cola", 1)
        oid = db.confirm_order(sid, "Cash")["order_id"]
        self.assertNotEqual(db.set_order_status(oid, "served", "", "kitchen")["status"], "ok")
        self.assertEqual(db.set_order_status(oid, "preparing", "", "kitchen")["status"], "ok")

    def test_empty_order_rejected(self):
        sid = self.session()
        self.assertNotEqual(db.confirm_order(sid, "Cash")["status"], "ok")

    def test_unknown_payment_method_rejected(self):
        self.assertIsNone(db.find_payment_method("Bitcoin"))
        self.assertEqual(db.find_payment_method("gcash"), "GCash")

    def test_tip_and_split(self):
        sid = self.session(); db.add_item_to_order(sid, "Cola", 2)
        o = db.confirm_order(sid, "GCash", tip=10, split_count=2)
        self.assertEqual(o["tip"], 10.0); self.assertEqual(o["split_count"], 2)
        self.assertAlmostEqual(o["per_person"], o["grand_total"] / 2, places=2)

    def test_online_paid_cash_unpaid(self):
        s1, s2 = self.session(1), self.session(2)
        db.add_item_to_order(s1, "Cola", 1); db.add_item_to_order(s2, "Cola", 1)
        a = db.confirm_order(s1, "GCash"); b = db.confirm_order(s2, "Cash")
        self.assertEqual(a["payment_status"], "paid"); self.assertTrue(a["payment_ref"].startswith("DEMO-"))
        self.assertEqual(b["payment_status"], "unpaid")
        self.assertEqual(db.mark_order_paid(b["order_id"])["order"]["payment_status"], "paid")

    def test_service_request_dedupes(self):
        sid = self.session()
        self.assertFalse(db.create_service_request(sid, "water")["duplicate"])
        self.assertTrue(db.create_service_request(sid, "water")["duplicate"])
        self.assertNotEqual(db.create_service_request(sid, "dance")["status"], "ok")

    def test_feedback_once_and_range(self):
        sid = self.session(); db.add_item_to_order(sid, "Cola", 1)
        oid = db.confirm_order(sid, "Cash")["order_id"]
        self.assertNotEqual(db.add_feedback(oid, 9, "")["status"], "ok")
        self.assertEqual(db.add_feedback(oid, 5, "great")["status"], "ok")
        self.assertEqual(db.add_feedback(oid, 4, "")["error"], "already_rated")

    def test_allergen_check(self):
        r = db.check_item_allergen("Cheeseburger", "dairy")
        self.assertEqual(r["status"], "ok"); self.assertTrue(r["contains_allergen"])

    def test_sql_injection_is_inert(self):
        sid = self.session()
        r = db.add_item_to_order(sid, "x'; DROP TABLE menu;--", 1)
        self.assertNotEqual(r["status"], "ok"); self.assertTrue(db.list_menu_items())


class TestFsm(DbCase):
    def agent(self, outputs=(), **kw):
        return FSMAgent(ScriptedLLM(outputs), llm_label="test", confirm_ai_orders=kw.pop("confirm", False), **kw)

    def test_flow_to_receipt_and_rounds(self):
        a = self.agent([json.dumps({"tool": "add_item_to_order", "arguments": {"item_name": "Cola", "qty": 1}}), "Added a Cola."])
        a.start(); a.handle("Table 2"); a.handle("one cola please")
        self.assertIn("pay", a.handle("that's all").lower())
        a.handle("yes"); out = a.handle("GCash")
        self.assertIn("RECEIPT", out)
        self.assertEqual(a.state, "STATE_TAKING_ORDER")       # session persists for another round
        self.assertEqual(len(a.order_ids), 1)

    def test_ai_orders_need_yes(self):
        a = self.agent([json.dumps({"tool": "add_item_to_order", "arguments": {"item_name": "Cola", "qty": 1}}), "ok"], confirm=True)
        a.start(); a.handle("Table 2"); out = a.handle("a cola")
        self.assertIn("Did you mean", out)
        self.assertTrue(db.view_current_order(a.session_id)["is_empty"])
        a.handle("yes")
        self.assertFalse(db.view_current_order(a.session_id)["is_empty"])

    def test_offline_parser(self):
        got = {x["name"]: x["qty"] for x in parse_simple_order("2 cheeseburgers and a cola", [i["name"] for i in db.list_menu_items()])}
        self.assertEqual(got, {"Cheeseburger": 2, "Cola": 1})

    def test_llm_failure_degrades_not_crashes(self):
        class Boom:
            def __call__(self, m): raise LLMError("down")
        a = FSMAgent(Boom(), llm_label="boom"); a.start(); a.handle("Table 1")
        self.assertIn("offline", a.handle("hello there").lower())

    def test_double_hello_before_table(self):
        a = self.agent(); a.start(); a.handle("hello"); a.handle("hello")


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Client:
    def __init__(self, base):
        self.base = base; self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def req(self, method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        r = urllib.request.Request(self.base + path, data, {"Content-Type": "application/json"}, method=method)
        try: x = self.op.open(r, timeout=15); code = x.status
        except urllib.error.HTTPError as e: x, code = e, e.code
        raw = x.read()
        try: return code, json.loads(raw)
        except ValueError: return code, raw
    def get(self, p): return self.req("GET", p)
    def post(self, p, b=None): return self.req("POST", p, {} if b is None else b)


class TestApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(); port = free_port(); cls.base = f"http://127.0.0.1:{port}"
        cls.proc = subprocess.Popen([sys.executable, str(ROOT / "web_dashboard.py"), "--port", str(port), "--no-browser", "--reset-db",
                                     "--db", f"{cls.tmp.name}/a.db", "--logfile", f"{cls.tmp.name}/a.log", "--log", f"{cls.tmp.name}/a.json",
                                     "--manager-pin", "m-pin-1", "--kitchen-pin", "k-pin-1"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=ROOT)
        for _ in range(60):
            try: urllib.request.urlopen(cls.base + "/api/health", timeout=1); break
            except Exception: time.sleep(0.25)
        else: raise RuntimeError("server did not start")

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(5); cls.tmp.cleanup()

    def C(self): return Client(self.base)

    def customer(self, table, item="Cola"):
        c = self.C(); c.get("/"); c.post("/api/chat", {"text": f"Table {table}"}); c.post("/api/order/add", {"item_name": item, "qty": 1}); return c

    def test_status_route_exists(self):
        self.assertEqual(self.C().get("/api/status")[0], 200)

    def test_sessions_are_independent_and_cart_updates(self):
        a, b = self.customer(1), self.customer(2, "Cheeseburger")
        self.assertEqual(a.get("/api/state")[1]["cart"]["items"][0]["name"], "Cola")
        self.assertEqual(b.get("/api/state")[1]["cart"]["items"][0]["name"], "Cheeseburger")
        self.assertEqual(a.get("/api/state")[1]["table_no"], 1)

    def test_checkout_decline_and_success(self):
        a = self.customer(3)
        self.assertEqual(a.post("/api/checkout", {"payment_method": "Bitcoin"})[0], 400)
        self.assertEqual(a.post("/api/checkout", {"payment_method": "GCash", "simulate": "fail"})[0], 402)
        self.assertFalse(a.get("/api/state")[1]["cart"]["is_empty"])        # decline keeps the cart
        code, d = a.post("/api/checkout", {"payment_method": "GCash", "tip": 5, "split_count": 2})
        self.assertEqual(code, 200); self.assertEqual(d["order"]["payment_status"], "paid")

    def test_staff_auth_and_roles(self):
        self.assertEqual(self.C().get("/api/admin/orders")[0], 401)
        self.assertEqual(self.C().get("/api/log")[0], 401)
        self.assertEqual(self.C().post("/api/admin/login", {"pin": "wrong"})[0], 401)
        k = self.C(); self.assertEqual(k.post("/api/admin/login", {"pin": "k-pin-1"})[0], 200)
        self.assertEqual(k.get("/api/admin/orders")[0], 200)
        self.assertEqual(k.get("/api/admin/overview")[0], 403)
        self.assertEqual(k.post("/api/admin/menu/1", {"price": 1})[0], 403)
        self.assertEqual(k.post("/api/admin/menu/1", {"available": True})[0], 200)

    def test_receipt_ownership(self):
        a, b = self.customer(4), self.customer(5)
        oid = a.post("/api/checkout", {"payment_method": "Cash"})[1]["order"]["order_id"]
        self.assertEqual(a.get(f"/receipt/{oid}")[0], 200)
        self.assertEqual(b.get(f"/receipt/{oid}")[0], 404)

    def test_kitchen_flow_and_live_status(self):
        a = self.customer(6); oid = a.post("/api/checkout", {"payment_method": "Cash"})[1]["order"]["order_id"]
        k = self.C(); k.post("/api/admin/login", {"pin": "k-pin-1"})
        self.assertEqual(k.post(f"/api/admin/orders/{oid}/status", {"status": "ready"})[0], 409)   # cannot skip
        self.assertEqual(k.post(f"/api/admin/orders/{oid}/status", {"status": "preparing"})[0], 200)
        self.assertEqual(a.get("/api/state")[1]["orders"][0]["status"], "preparing")

    def test_feedback_only_own_order_once(self):
        a, b = self.customer(7), self.customer(8)
        oid = a.post("/api/checkout", {"payment_method": "Cash"})[1]["order"]["order_id"]
        self.assertEqual(b.post("/api/feedback", {"order_id": oid, "rating": 1})[0], 403)
        self.assertEqual(a.post("/api/feedback", {"order_id": oid, "rating": 5})[0], 200)
        self.assertEqual(a.post("/api/feedback", {"order_id": oid, "rating": 4})[0], 409)

    def test_close_table_resets_customer(self):
        a = self.customer(1)
        m = self.C(); m.post("/api/admin/login", {"pin": "m-pin-1"})
        self.assertEqual(m.post("/api/admin/tables/1/close")[0], 200)
        s = a.get("/api/state")[1]; self.assertTrue(s["closed_by_staff"]); self.assertEqual(s["state"], "STATE_GREETING")

    def test_bad_input(self):
        c = self.C()
        self.assertEqual(c.req("POST", "/api/chat", None)[0], 400)
        self.assertEqual(c.get("/nope")[0], 404)
        self.assertEqual(c.get("/api/chat")[0], 405)

    def test_image_upload_rejects_non_images(self):
        import base64
        m = self.C(); m.post("/api/admin/login", {"pin": "m-pin-1"})
        self.assertEqual(m.post("/api/admin/menu/1/image", {"data": base64.b64encode(b"hello").decode()})[0], 415)

    def test_zzz_pin_lockout(self):
        c = self.C(); codes = [c.post("/api/admin/login", {"pin": "nope"})[0] for _ in range(8)]
        self.assertIn(429, codes)


if __name__ == "__main__":
    unittest.main()