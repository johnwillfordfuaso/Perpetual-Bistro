import sys
from pathlib import Path

import db_tools as db

DB_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "restaurant.db"

DISHES = [
    dict(name="Garlic Butter Shrimp", category="Mains", price=290, stock=15, vegetarian=False, allergens="shellfish, dairy",
         description="Plump shrimp sauteed in garlic butter and white wine, finished with fresh parsley."),
    dict(name="Acqua Pazza", category="Mains", price=320, stock=12, vegetarian=False, allergens="fish",
         description="Italian-style poached white fish in a light garlic and cherry-tomato broth with fresh basil."),
    dict(name="Buko Pandan", category="Desserts", price=100, stock=25, vegetarian=False, allergens="dairy",
         description="Chilled young coconut and pandan jelly in sweet creamy milk. A Filipino classic."),
]

db.set_db_path(DB_FILE)
db.init_db()
for d in DISHES:
    r = db.admin_add_menu_item(**d)
    print(("added:   " if r["status"] == "ok" else "skipped: ") + d["name"] + ("" if r["status"] == "ok" else f" ({r.get('error')})"))
print("Done. Refresh the page to see them.")