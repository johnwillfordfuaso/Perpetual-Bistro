"""Adds Lumpiang Shanghai, Chicken Tenders and Steak Pizzaiola to the Perpetual Bistro menu.
Run once from the project folder (stop the server first, or just refresh the page afterwards):
    python add_lumpia_tenders_steak.py
Safe to run twice - dishes that already exist are skipped. Edit prices/descriptions/stock later in Admin > Menu & stock.
The photos are images/lumpiang-shanghai.jpg, images/chicken-tenders.jpg and images/steak-pizzaiola.jpg."""
import sys
from pathlib import Path

import db_tools as db

DB_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "restaurant.db"

DISHES = [
    dict(name="Lumpiang Shanghai", category="Sides", price=120, stock=30, vegetarian=False, allergens="gluten, egg, soy",
         description="Crispy golden rolls of seasoned ground pork, carrot and onion, served with sweet chili dip. A Filipino party favourite."),
    dict(name="Chicken Tenders", category="Sides", price=180, stock=25, vegetarian=False, allergens="gluten, egg, dairy",
         description="Hand-breaded chicken strips fried until crunchy, served with a spicy tomato dip and creamy honey mustard."),
    dict(name="Steak Pizzaiola", category="Mains", price=340, stock=12, vegetarian=False, allergens="none",
         description="Sliced seared beef steak simmered in a rich tomato, bell pepper and garlic sauce, finished with fresh basil."),
]

db.set_db_path(DB_FILE)
db.init_db()
for d in DISHES:
    r = db.admin_add_menu_item(**d)
    print(("added:   " if r["status"] == "ok" else "skipped: ") + d["name"] + ("" if r["status"] == "ok" else f" ({r.get('error')})"))
print("Done. Refresh the page to see them.")
