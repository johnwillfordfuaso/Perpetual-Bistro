"""
speech_engine.py - decoupled Speech-to-Text / Text-to-Speech adapters for the Perpetual Bistro waiter.

Everything here runs LOCALLY (the project rule is zero cloud / no internet at the live defense):

  STT  SpeechRecognition captures the microphone, then ONE offline recogniser transcribes it:
         1. whisper         pip install openai-whisper      (best accuracy, needs ffmpeg + a few GB RAM)
         2. faster-whisper  pip install faster-whisper      (same models, lighter and faster on CPU)
         3. vosk            pip install vosk                (+ unzip a model, set VOSK_MODEL_PATH)
         4. pocketsphinx    pip install pocketsphinx        (tiny, works anywhere, lowest accuracy)
       The cloud recogniser (recognize_google) is deliberately never called.
  TTS  pyttsx3 (Windows SAPI5 / macOS NSSpeech / Linux espeak-ng) - all offline.

The agent never imports this file.  It only sees text, through two functions:
      SpeechEngine.get_input()   -> str     (replaces input())
      SpeechEngine.send_output() -> None    (replaces print())
which matches the I/O abstraction used in virtual_waiter_prototype.py (Lesson 6.5.1).

Speech recognition ERRORS are a graded edge case, so the engine also repairs the usual ones before
the text reaches the FSM: "table for" -> "table 4", "cheese burger" -> "Cheeseburger", etc.
"""
from __future__ import annotations

import difflib
import importlib
import importlib.util
import logging
import os
import re
import threading
from typing import Callable, Iterable, Optional

log = logging.getLogger("speech")


class SpeechError(RuntimeError):
    """Base class for speech problems (the CLI falls back to typing when it sees one)."""


class SpeechUnavailable(SpeechError):
    """A needed library, microphone or voice is missing."""


# =============================================================================================
# Text helpers
# =============================================================================================
_HOMOPHONE_NUMBERS = {"for": "4", "four": "4", "to": "2", "too": "2", "two": "2", "tree": "3", "three": "3",
                      "free": "3", "won": "1", "one": "1", "ate": "8", "eight": "8", "fine": "5", "five": "5",
                      "sex": "6", "six": "6", "seven": "7", "nine": "9", "ten": "10"}
_NUMBER_WORDS = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
                 "seven": "7", "eight": "8", "nine": "9", "ten": "10", "eleven": "11", "twelve": "12"}


def correct_transcript(text: str, vocabulary: Iterable[str] = (), cutoff: float = 0.84) -> str:
    """Repair common speech-recognition mistakes before the FSM sees the text.

    * "table for / to / tree"        -> "table 4 / 2 / 3"   (number homophones after the word 'table')
    * "table number four"            -> "table 4"
    * "cheese burger", "cheeseburgr" -> "Cheeseburger"      (fuzzy match against the real menu names)
    Anything that cannot be repaired confidently is left unchanged."""
    t = " ".join((text or "").split())
    if not t:
        return ""
    # table numbers
    m = re.search(r"\btable\s*(?:no\.?|number|#)?\s*([a-z]+|\d{1,2})\b", t, re.I)
    if m:
        tok = m.group(1).lower()
        num = tok if tok.isdigit() else _HOMOPHONE_NUMBERS.get(tok)
        if num:
            t = t[:m.start()] + f"table {num}" + t[m.end():]
    # menu vocabulary: slide a 4..1 word window over the sentence and replace windows that are
    # almost exactly a menu name once spaces are ignored ("cheese burger" == "cheeseburger")
    names = [v for v in vocabulary if v]
    if names:
        flat_names = {re.sub(r"[^a-z0-9]", "", n.lower()): n for n in names}
        words = t.split()
        out, i = [], 0
        while i < len(words):
            hit = None
            for size in (4, 3, 2, 1):
                if i + size > len(words):
                    continue
                flat = re.sub(r"[^a-z0-9]", "", " ".join(words[i:i + size]).lower())
                if len(flat) < 4:
                    continue
                best, best_ratio = None, 0.0
                for fn, original in flat_names.items():
                    if abs(len(flat) - len(fn)) > max(2, int(len(fn) * 0.2)):
                        continue                                   # a window with extra words is not a match
                    r = difflib.SequenceMatcher(None, flat, fn).ratio()
                    if r > best_ratio:
                        best, best_ratio = original, r
                if best and best_ratio >= cutoff:
                    trail = re.search(r"[.,!?]+$", words[i + size - 1])
                    hit = (best + (trail.group(0) if trail else ""), size)
                    break
            if hit:
                out.append(hit[0]); i += hit[1]
            else:
                out.append(words[i]); i += 1
        t = " ".join(out)
    return t


def speakable(text: str, max_chars: int = 400) -> str:
    """Turn a screen reply into something worth saying aloud.  Receipts and itemised tabs are
    summarised instead of reading out boxes of dashes."""
    t = (text or "").strip()
    if not t:
        return ""
    if "OFFICIAL RECEIPT" in t.upper() or "RECEIPT" in t.upper().split("\n")[0:3].__str__():
        oid = re.search(r"Order #(\d+)", t)
        total = re.search(r"TOTAL[^\n\d]*([\d,]+(?:\.\d+)?)", t)
        method = re.search(r"Payment method:\s*([A-Za-z]+)", t)
        parts = [f"Your order{(' number ' + oid.group(1)) if oid else ''} has been sent to the kitchen."]
        if total:
            parts.append(f"The total is {total.group(1).replace(',', '')} pesos" +
                         (f", paid by {method.group(1)}." if method else "."))
        parts.append("Thank you! Would you like anything else?")
        return " ".join(parts)
    if re.search(r"^\s*-{5,}\s*$", t, re.M):                      # itemised tab
        lines = [ln.strip() for ln in t.split("\n")]
        items = [re.sub(r"\s{2,}[\d,.]+$", "", ln) for ln in lines if re.match(r"^\d+x\s", ln)]
        total = re.search(r"TOTAL[^\n\d]*([\d,]+(?:\.\d+)?)", t)
        ask = [ln for ln in lines if ln.lower().startswith("shall i send")]
        head = ["Here is your order: " + ", ".join(re.sub(r"^(\d+)x\s+", r"\1 ", i) for i in items) + "."] if items else []
        if total:
            head.append(f"The total is {total.group(1).replace(',', '')} pesos.")
        head.append("Shall I send this to the kitchen? Say yes and tell me how you'd like to pay." if ask else "")
        t = " ".join(h for h in head if h)
    t = re.sub(r"[=\-_*#`|]{3,}", " ", t)
    t = t.replace("₱", " pesos ").replace("PHP", "pesos")
    t = re.sub(r"\(\s*pesos\s*\)", "", t)
    t = re.sub(r"(\d+)x\s", r"\1 ", t)
    t = re.sub(r"\s*\n+\s*", ". ", t)
    t = re.sub(r"\.\s*\.", ".", t)
    t = re.sub(r"\s{2,}", " ", t).strip()
    if len(t) > max_chars:
        cut = t[:max_chars]
        stop = max(cut.rfind(". "), cut.rfind("? "), cut.rfind("! "))
        t = (cut[:stop + 1] if stop > 80 else cut.rstrip()) + ("" if stop > 80 else "...")
    return t


# =============================================================================================
# Speech-to-Text
# =============================================================================================
def _has(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


class SpeechRecognitionSTT:
    """Microphone (or WAV file) -> text, 100% offline."""

    def __init__(self, backend: str = "auto", language: str = "en", whisper_model: str = "base.en",
                 mic_index: Optional[int] = None, vocabulary: Iterable[str] = (), pause_threshold: float = 0.9,
                 energy_threshold: Optional[int] = None):
        try:
            import speech_recognition as sr
        except ImportError as exc:
            raise SpeechUnavailable("SpeechRecognition is not installed.  Run: pip install SpeechRecognition pyaudio") from exc
        self.sr = sr
        self.language = language
        self.whisper_model = os.environ.get("WHISPER_MODEL", whisper_model)
        self.mic_index = mic_index
        self.vocabulary = [v for v in vocabulary if v]
        self.rec = sr.Recognizer()
        self.rec.pause_threshold = pause_threshold
        if energy_threshold:
            self.rec.energy_threshold = energy_threshold
            self.rec.dynamic_energy_threshold = False
        self._calibrated = False
        self.backend = self._pick_backend(backend)
        log.info("STT backend: %s", self.backend)

    # ---- backend selection ----------------------------------------------------------------
    @staticmethod
    def available_backends() -> list[str]:
        found = []
        if _has("whisper"):
            found.append("whisper")
        if _has("faster_whisper"):
            found.append("faster-whisper")
        if _has("vosk") and os.environ.get("VOSK_MODEL_PATH"):
            found.append("vosk")
        if _has("pocketsphinx"):
            found.append("sphinx")
        return found

    def _pick_backend(self, wanted: str) -> str:
        found = self.available_backends()
        if wanted == "auto":
            if not found:
                raise SpeechUnavailable(
                    "No OFFLINE speech recogniser installed.  Install one of:\n"
                    "   pip install openai-whisper        (best; also needs ffmpeg)\n"
                    "   pip install faster-whisper\n"
                    "   pip install pocketsphinx          (smallest)\n"
                    "(the cloud recogniser is intentionally not used: the system must run without internet)")
            return found[0]
        if wanted not in found:
            raise SpeechUnavailable(f"STT backend '{wanted}' is not available here (found: {', '.join(found) or 'none'}).")
        return wanted

    # ---- recognition ----------------------------------------------------------------------
    def _transcribe(self, audio) -> str:
        sr = self.sr
        prompt = ("Perpetual Bistro order. Table number. Menu: " + ", ".join(self.vocabulary)) if self.vocabulary else None
        try:
            if self.backend == "whisper":
                opts = {"initial_prompt": prompt} if prompt else {}
                text = self.rec.recognize_whisper(audio, model=self.whisper_model, language=self.language.split("-")[0], **opts)
            elif self.backend == "faster-whisper":
                text = self.rec.recognize_faster_whisper(audio, model=self.whisper_model, language=self.language.split("-")[0])
            elif self.backend == "vosk":
                import json
                text = json.loads(self.rec.recognize_vosk(audio)).get("text", "")
            else:
                text = self.rec.recognize_sphinx(audio)
        except sr.UnknownValueError:
            return ""
        except Exception as exc:                                    # model missing, ffmpeg missing, ...
            raise SpeechError(f"Speech recognition failed ({type(exc).__name__}: {exc})") from exc
        return correct_transcript(str(text).strip(), self.vocabulary)

    def transcribe_file(self, path: str) -> str:
        """WAV / AIFF / FLAC file -> text.  Lets you test the pipeline without a microphone."""
        with self.sr.AudioFile(path) as source:
            audio = self.rec.record(source)
        return self._transcribe(audio)

    def listen(self, timeout: Optional[float] = 8, phrase_time_limit: Optional[float] = 15) -> str:
        """Block until the customer speaks one phrase; return '' if nothing intelligible was heard."""
        sr = self.sr
        try:
            mic = sr.Microphone(device_index=self.mic_index)
        except (OSError, AttributeError) as exc:
            raise SpeechUnavailable("No microphone available (is PyAudio installed and a mic plugged in?).  "
                                    "Install with: pip install pyaudio") from exc
        with mic as source:
            if not self._calibrated:
                self.rec.adjust_for_ambient_noise(source, duration=0.7)
                self._calibrated = True
            try:
                audio = self.rec.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
            except sr.WaitTimeoutError:
                return ""
        return self._transcribe(audio)


class LocalTranscriber:
    """WAV bytes -> text, 100% offline.  Used by the web dashboard (POST /api/stt): the browser records the
    microphone itself (no Google / Microsoft speech service), sends 16 kHz mono WAV, and this class turns it
    into text with whichever OFFLINE recogniser is installed:  faster-whisper > openai-whisper > vosk.

    Needs no microphone library (no PyAudio) and no SpeechRecognition package."""

    def __init__(self, model: Optional[str] = None):
        self.model_name = model or os.environ.get("WHISPER_MODEL", "base.en")
        self.backend: Optional[str] = None
        for name, module in (("faster-whisper", "faster_whisper"), ("whisper", "whisper")):
            if _has(module):
                self.backend = name
                break
        if self.backend is None and _has("vosk") and os.environ.get("VOSK_MODEL_PATH"):
            self.backend = "vosk"
        self._model = None
        self._lock = threading.Lock()

    @property
    def available(self) -> bool:
        return self.backend is not None

    def status(self) -> dict:
        return {"available": self.available, "backend": self.backend,
                "model": self.model_name if self.backend in ("faster-whisper", "whisper") else os.environ.get("VOSK_MODEL_PATH")}

    def load(self) -> None:
        """Load the model once (slow the first time).  Safe to call from a background thread."""
        with self._lock:
            if self._model is not None or not self.available:
                return
            if self.backend == "faster-whisper":
                from faster_whisper import WhisperModel
                self._model = WhisperModel(self.model_name, device="cpu", compute_type="int8")
            elif self.backend == "whisper":
                import whisper
                self._model = whisper.load_model(self.model_name)
            elif self.backend == "vosk":
                import vosk
                self._model = vosk.Model(os.environ["VOSK_MODEL_PATH"])

    @staticmethod
    def wav_to_pcm(data: bytes) -> tuple[bytes, int]:
        """Validate a PCM16 mono WAV and return (raw pcm bytes, sample rate)."""
        import io
        import wave
        try:
            with wave.open(io.BytesIO(data), "rb") as w:
                if w.getsampwidth() != 2 or w.getnchannels() != 1:
                    raise SpeechError("Audio must be 16-bit mono WAV.")
                return w.readframes(w.getnframes()), w.getframerate()
        except wave.Error as exc:
            raise SpeechError(f"Not a valid WAV file ({exc}).") from exc

    def transcribe(self, wav_bytes: bytes, language: str = "en", vocabulary: Iterable[str] = ()) -> str:
        if not self.available:
            raise SpeechUnavailable("No offline speech recogniser is installed (pip install faster-whisper).")
        pcm, rate = self.wav_to_pcm(wav_bytes)
        if len(pcm) < rate * 2 * 0.25:                       # under 0.25 s: nothing to recognise
            return ""
        vocab = [v for v in vocabulary if v]
        prompt = ("Perpetual Bistro order. Table number. Menu: " + ", ".join(vocab)) if vocab else None
        self.load()
        with self._lock:
            try:
                if self.backend == "vosk":
                    import json
                    import vosk
                    rec = vosk.KaldiRecognizer(self._model, rate)
                    rec.AcceptWaveform(pcm)
                    text = json.loads(rec.FinalResult()).get("text", "")
                else:
                    import numpy as np
                    audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
                    lang = {"fil": "tl"}.get(language.split("-")[0], language.split("-")[0])
                    if self.model_name.endswith(".en"):
                        lang = "en"                           # English-only model: it cannot do Tagalog
                    if self.backend == "faster-whisper":
                        segs, _info = self._model.transcribe(audio, language=lang, initial_prompt=prompt,
                                                             beam_size=1, vad_filter=False)
                        text = " ".join(s.text.strip() for s in segs)
                    else:
                        opts = {"initial_prompt": prompt} if prompt else {}
                        text = self._model.transcribe(audio, language=lang, fp16=False, **opts).get("text", "")
            except SpeechError:
                raise
            except Exception as exc:
                raise SpeechError(f"Speech recognition failed ({type(exc).__name__}: {exc})") from exc
        return correct_transcript(str(text).strip(), vocab)


class ScriptedSTT:
    """A pretend microphone that 'hears' a fixed list of phrases.  Used by --selftest and unit tests
    so the whole voice pipeline can be verified on a machine with no microphone."""

    def __init__(self, phrases: Iterable[str], vocabulary: Iterable[str] = ()):
        self.phrases = list(phrases)
        self.vocabulary = list(vocabulary)
        self.backend = "scripted"

    def listen(self, timeout=None, phrase_time_limit=None) -> str:
        if not self.phrases:
            raise EOFError("scripted microphone has nothing left to say")
        return correct_transcript(self.phrases.pop(0), self.vocabulary)

    def transcribe_file(self, path: str) -> str:
        return self.listen()


# =============================================================================================
# Text-to-Speech
# =============================================================================================
class Pyttsx3TTS:
    """pyttsx3 wrapper.  A fresh engine is created for every utterance: re-using one engine is the
    classic cause of 'speaks once, then goes silent' (esp. on Windows and with threads)."""

    def __init__(self, rate: int = 170, volume: float = 1.0, voice: Optional[str] = None, pitch: Optional[int] = None):
        try:
            import pyttsx3
        except ImportError as exc:
            raise SpeechUnavailable("pyttsx3 is not installed.  Run: pip install pyttsx3") from exc
        self._pyttsx3 = pyttsx3
        self.rate, self.volume, self.voice, self.pitch = rate, volume, voice, pitch
        self._lock = threading.Lock()
        self._engine = None
        try:                                                        # fail early, not in the middle of a demo
            self.list_voices()
        except Exception as exc:
            raise SpeechUnavailable(f"No text-to-speech voice available ({exc}).  On Linux install espeak-ng.") from exc

    def _new_engine(self):
        eng = self._pyttsx3.init()
        eng.setProperty("rate", self.rate)              # words per minute (default ~200: a bit fast for a waiter)
        eng.setProperty("volume", self.volume)          # 0.0 - 1.0
        if self.voice:
            for v in eng.getProperty("voices"):
                if self.voice.lower() in (v.name or "").lower() or self.voice.lower() in str(v.id).lower():
                    eng.setProperty("voice", v.id)
                    break
        if self.pitch is not None:                      # only some drivers (espeak) support pitch; ignored elsewhere
            try:
                eng.setProperty("pitch", self.pitch)
            except Exception:
                pass
        return eng

    def list_voices(self) -> list[dict]:
        eng = self._pyttsx3.init()
        try:
            return [{"id": v.id, "name": v.name, "languages": getattr(v, "languages", [])} for v in eng.getProperty("voices")]
        finally:
            try:
                eng.stop()
            except Exception:
                pass

    def speak(self, text: str) -> None:
        text = speakable(text)
        if not text:
            return
        with self._lock:
            eng = self._new_engine()
            self._engine = eng
            try:
                eng.say(text)
                eng.runAndWait()
            except Exception as exc:
                raise SpeechError(f"Text-to-speech failed: {exc}") from exc
            finally:
                self._engine = None
                try:
                    eng.stop()
                except Exception:
                    pass

    def stop(self) -> None:
        eng = self._engine
        if eng is not None:
            try:
                eng.stop()
            except Exception:
                pass

    def save_wav(self, text: str, path: str) -> None:
        eng = self._new_engine()
        eng.save_to_file(speakable(text), path)
        eng.runAndWait()


class SilentTTS:
    """Used when no voice is installed: the waiter still 'speaks' on screen."""

    def speak(self, text: str) -> None:
        pass

    def stop(self) -> None:
        pass


# =============================================================================================
# Facade used by the application
# =============================================================================================
class SpeechEngine:
    def __init__(self, stt=None, tts=None, echo: bool = True, speak_replies: bool = True):
        self.stt = stt
        self.tts = tts or SilentTTS()
        self.echo = echo                    # also print the waiter's words
        self.speak_replies = speak_replies
        self.notes: list[str] = []          # why something is unavailable (shown in the CLI banner)

    @classmethod
    def auto(cls, vocabulary: Iterable[str] = (), stt_backend: str = "auto", whisper_model: str = "base.en",
             voice: Optional[str] = None, rate: int = 170, mic_index: Optional[int] = None,
             want_stt: bool = True, want_tts: bool = True) -> "SpeechEngine":
        """Build the best engine this machine supports; never raises, it records what is missing."""
        notes, stt, tts = [], None, None
        if want_stt:
            try:
                stt = SpeechRecognitionSTT(stt_backend, whisper_model=whisper_model, mic_index=mic_index, vocabulary=vocabulary)
            except SpeechError as exc:
                notes.append(f"STT off: {exc}")
        if want_tts:
            try:
                tts = Pyttsx3TTS(rate=rate, voice=voice)
            except SpeechError as exc:
                notes.append(f"TTS off: {exc}")
        eng = cls(stt, tts)
        eng.notes = notes
        return eng

    # ---- status ---------------------------------------------------------------------------
    @property
    def can_listen(self) -> bool:
        return self.stt is not None

    @property
    def can_speak(self) -> bool:
        return not isinstance(self.tts, SilentTTS)

    def status(self) -> dict:
        return {"stt": getattr(self.stt, "backend", None), "tts": "pyttsx3" if self.can_speak else None, "notes": self.notes}

    # ---- the two I/O hooks the agent loop uses --------------------------------------------
    def listen(self, **kw) -> str:
        if self.stt is None:
            raise SpeechUnavailable("speech-to-text is not available")
        return self.stt.listen(**kw)

    def send_output(self, text: str) -> None:
        if self.echo:
            print(f"\nWaiter: {text}\n")
        if self.speak_replies:
            try:
                self.tts.speak(text)
            except SpeechError as exc:
                log.warning("%s", exc)
                self.notes.append(str(exc))
                self.speak_replies = False          # stop retrying a broken voice mid-demo

    def get_input(self, prompt: str = "You: ") -> str:
        """Press Enter to talk, or type text.  Falls back to typing if the microphone fails."""
        if self.stt is None:
            return input(prompt)
        raw = input(f"{prompt}[Enter = speak, or type] ")
        if raw.strip():
            return raw
        print("   listening ...", flush=True)
        try:
            heard = self.listen()
        except SpeechError as exc:
            print(f"   (microphone problem: {exc}) - please type instead.")
            return input(prompt)
        if not heard:
            print("   (I didn't catch that - try again or type)")
            return ""
        print(f"   heard: {heard!r}")
        return heard