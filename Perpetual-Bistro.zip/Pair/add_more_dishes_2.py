"""Adds Ginataang Kalabasa at Sitaw, Creme Brulee and Tiramisu to the Perpetual Bistro menu.
Run once from the project folder (stop the server first, or just refresh the page afterwards):
    python add_more_dishes_2.py
Safe to run twice - dishes that already exist are skipped. Edit prices/descriptions/stock later in Admin > Menu & stock.
The photos are images/ginataang-kalabasa-at-sitaw.jpg, images/creme-brulee.jpg and images/tiramisu.jpg."""
import sys
from pathlib import Path

import db_tools as db

DB_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "restaurant.db"

DISHES = [
    dict(name="Ginataang Kalabasa at Sitaw", category="Mains", price=150, stock=20, vegetarian=False, allergens="shellfish",
         description="Sweet kalabasa (squash) and crisp sitaw (string beans) simmered in creamy coconut milk with garlic, ginger and shrimp. A Filipino home-cooking favourite."),
    dict(name="Creme Brulee", category="Desserts", price=160, stock=15, vegetarian=True, allergens="dairy, egg",
         description="Silky vanilla custard under a crackling caramelised sugar crust, topped with fresh berries."),
    dict(name="Tiramisu", category="Desserts", price=170, stock=15, vegetarian=True, allergens="gluten, dairy, egg",
         description="Layers of coffee-soaked ladyfingers and light mascarpone cream, dusted with cocoa."),
]

db.set_db_path(DB_FILE)
db.init_db()
for d in DISHES:
    r = db.admin_add_menu_item(**d)
    print(("added:   " if r["status"] == "ok" else "skipped: ") + d["name"] + ("" if r["status"] == "ok" else f" ({r.get('error')})"))
print("Done. Refresh the page to see them.")
