"""
db_tools.py - Database layer and LLM tool definitions for Perpetual Bistro.

Tables
  menu              dishes, price, stock, allergens
  sessions          one row per customer visit at a table
  order_items       the *cart* of an open session (cleared when an order is sent)
  orders            confirmed orders ("rounds") with a kitchen status and payment info
  order_lines       snapshot of what each confirmed order contains
  service_requests  "call a server", "water", "bill" requests
  feedback          1-5 star rating per order
  chat_log          every customer <-> waiter exchange (for the admin AI-log viewer)

Older restaurant.db files are upgraded in place by init_db().
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterable, Optional

CURRENCY = "PHP"
SERVICE_FEE_RATE = 0.10
# PWD / Senior Citizen discount (Philippines: RA 10754 / RA 9994): 20% off, the customer must show a valid ID.
# The discount is taken off the food subtotal first; the service fee is then computed on the discounted amount.
DISCOUNTS = {"pwd": {"label": "PWD", "rate": 0.20}, "senior": {"label": "Senior Citizen", "rate": 0.20}}
LOW_STOCK_THRESHOLD = 5
DEFAULT_STOCK = 50
MAX_QTY_PER_LINE = 50

# ---------------------------------------------------------------------------
# Payment methods (name -> details shown in the UI)
# ---------------------------------------------------------------------------
PAYMENT_METHODS = {
    "GCash":     {"type": "online", "code": "GC",   "icon": "\U0001F4F1", "label": "E-wallet",
                  "note": "Pay with GCash. Show your payment confirmation to the cashier."},
    "Cash":      {"type": "cash",   "code": "CASH", "icon": "\U0001F4B5", "label": "At the table",
                  "note": "Please hand your cash to the server or cashier."},
    "BPI":       {"type": "online", "code": "BPI",  "icon": "\U0001F3E6", "label": "Online banking",
                  "note": "Pay with BPI. Show your payment confirmation to the cashier."},
    "Metrobank": {"type": "online", "code": "MB",   "icon": "\U0001F3E6", "label": "Online banking",
                  "note": "Pay with Metrobank. Show your payment confirmation to the cashier."},
    "Maribank":  {"type": "online", "code": "MARI", "icon": "\U0001F3E6", "label": "Digital bank",
                  "note": "Pay with Maribank. Show your payment confirmation to the cashier."},
}
_PAYMENT_ALIASES = {
    "gcash": "GCash", "g-cash": "GCash", "g cash": "GCash",
    "cash": "Cash",
    "bpi": "BPI", "bank of the philippine islands": "BPI",
    "metrobank": "Metrobank", "metro bank": "Metrobank",
    "maribank": "Maribank", "mari bank": "Maribank",
}


def find_payment_method(text) -> Optional[str]:
    """Return the canonical payment method named in `text`, or None."""
    low = str(text or "").lower().strip()
    if not low:
        return None
    if low in _PAYMENT_ALIASES:
        return _PAYMENT_ALIASES[low]
    for alias in sorted(_PAYMENT_ALIASES, key=len, reverse=True):
        if re.search(r"(?<![a-z])" + re.escape(alias) + r"(?![a-z])", low):
            return _PAYMENT_ALIASES[alias]
    return None


# ---------------------------------------------------------------------------
# Constants for orders / requests
# ---------------------------------------------------------------------------
ORDER_STATUSES = ("received", "preparing", "ready", "served", "cancelled")
ACTIVE_STATUSES = ("received", "preparing", "ready")
_NEXT = {"received": "preparing", "preparing": "ready", "ready": "served"}
_BACK = {"preparing": "received", "ready": "preparing", "served": "ready"}
_STATUS_TS = {"preparing": "preparing_at", "ready": "ready_at", "served": "served_at"}

SERVICE_KINDS = {"server": "Call a server", "water": "Water / refill", "bill": "Bring the bill",
                 "cancel_order": "Cancel / change a sent order"}

ALLERGEN_CHOICES = ["gluten", "dairy", "egg", "soy", "nuts", "fish", "shellfish", "sesame"]
_ALLERGEN_ALIASES = {
    "milk": "dairy", "cheese": "dairy", "lactose": "dairy", "butter": "dairy", "cream": "dairy",
    "wheat": "gluten", "flour": "gluten", "eggs": "egg", "soya": "soy", "soybean": "soy",
    "peanut": "nuts", "peanuts": "nuts", "nut": "nuts", "tree nuts": "nuts", "treenuts": "nuts",
    "shrimp": "shellfish", "prawn": "shellfish", "crab": "shellfish",
}

# Defaults applied when a database predates stock / allergen tracking
_DEFAULT_ALLERGENS = {
    "Cheeseburger": "gluten,dairy,egg", "Veggie Burger": "gluten,soy", "Spaghetti Bolognese": "gluten,egg",
    "Chicken Adobo Rice": "soy", "Pesto Pasta": "gluten,dairy,nuts", "French Fries": "none",
    "Garden Salad": "none", "Onion Rings": "gluten,egg", "Iced Tea": "none", "Mango Smoothie": "dairy",
    "Cola": "none", "Bottled Water": "none", "Matcha Sea Salt": "dairy", "Leche Flan": "dairy,egg",
    "Halo-Halo": "dairy",
}
_DEFAULT_STOCK = {
    "Cheeseburger": 20, "Veggie Burger": 15, "Spaghetti Bolognese": 12, "Chicken Adobo Rice": 18,
    "Pesto Pasta": 3, "French Fries": 30, "Garden Salad": 10, "Onion Rings": 0, "Iced Tea": 40,
    "Mango Smoothie": 15, "Cola": 40, "Bottled Water": 50, "Matcha Sea Salt": 20, "Leche Flan": 8,
    "Halo-Halo": 6,
}

_DB_PATH = Path(__file__).parent / "restaurant.db"


def set_db_path(path: str | Path) -> None:
    global _DB_PATH
    _DB_PATH = Path(path)


def _now() -> str:
    """Local wall-clock time, second precision (all order timestamps use this)."""
    return datetime.now().isoformat(sep=" ", timespec="seconds")


def _parse_ts(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(_DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 15000")
    return conn


def _err(code: str, message: str, **extra: Any) -> dict:
    return {"status": "error", "error": code, "message": message, **extra}


def _to_int(value: Any) -> Optional[int]:
    """Lenient int: accepts 2, 2.0, '2'. Returns None for anything else (incl. bool)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str) and re.fullmatch(r"\s*-?\d+\s*", value):
        return int(value)
    return None


def _to_float(value: Any, default: float = 0.0) -> Optional[float]:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if f == f and abs(f) != float("inf") else None


def _ensure_column(cur: sqlite3.Cursor, table: str, column: str, ddl: str) -> bool:
    cols = [r[1] for r in cur.execute(f"PRAGMA table_info({table})").fetchall()]
    if column in cols:
        return False
    cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
    return True


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------
def init_db(reset: bool = False) -> None:
    if reset:
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(_DB_PATH) + suffix)
            if p.exists():
                p.unlink()
    conn = _get_conn()
    cur = conn.cursor()
    try:
        cur.execute("PRAGMA journal_mode = WAL")   # lets kitchen/admin read while customers write
    except sqlite3.DatabaseError:
        pass
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS menu (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        category TEXT NOT NULL,
        price REAL NOT NULL,
        available INTEGER NOT NULL DEFAULT 1,
        description TEXT,
        vegetarian INTEGER NOT NULL DEFAULT 0,
        stock_qty INTEGER NOT NULL DEFAULT 50,
        allergens TEXT NOT NULL DEFAULT 'none'
    );

    CREATE TABLE IF NOT EXISTS sessions (
        session_id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_no INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        payment_method TEXT,
        closed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS order_items (
        item_id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        instructions TEXT,
        unit_price REAL NOT NULL,
        FOREIGN KEY (session_id) REFERENCES sessions(session_id),
        FOREIGN KEY (name) REFERENCES menu(name)
    );

    CREATE TABLE IF NOT EXISTS orders (
        order_id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        table_no INTEGER NOT NULL,
        round_no INTEGER NOT NULL DEFAULT 1,
        status TEXT NOT NULL DEFAULT 'received',
        subtotal REAL NOT NULL,
        service_fee REAL NOT NULL,
        tip REAL NOT NULL DEFAULT 0,
        grand_total REAL NOT NULL,
        split_count INTEGER NOT NULL DEFAULT 1,
        payment_method TEXT,
        payment_status TEXT NOT NULL DEFAULT 'unpaid',
        payment_ref TEXT,
        cancel_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        preparing_at TEXT,
        ready_at TEXT,
        served_at TEXT,
        paid_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_orders_session ON orders(session_id);
    CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);

    CREATE TABLE IF NOT EXISTS order_lines (
        line_id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        instructions TEXT,
        unit_price REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_lines_order ON order_lines(order_id);

    CREATE TABLE IF NOT EXISTS service_requests (
        request_id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        table_no INTEGER NOT NULL,
        kind TEXT NOT NULL,
        note TEXT,
        status TEXT NOT NULL DEFAULT 'open',
        created_at TEXT NOT NULL,
        done_at TEXT
    );

    CREATE TABLE IF NOT EXISTS feedback (
        feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL UNIQUE,
        rating INTEGER NOT NULL,
        comment TEXT,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS chat_log (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        client TEXT,
        session_id INTEGER,
        table_no INTEGER,
        user_text TEXT,
        assistant_text TEXT,
        state_before TEXT,
        state_after TEXT,
        tool_calls TEXT,
        degraded INTEGER NOT NULL DEFAULT 0
    );
    """)

    # ---- migrations for databases created by older versions ----
    _ensure_column(cur, "sessions", "payment_method", "TEXT")
    _ensure_column(cur, "sessions", "closed_at", "TEXT")
    _ensure_column(cur, "sessions", "discount_type", "TEXT")
    _ensure_column(cur, "sessions", "discount_id", "TEXT")
    _ensure_column(cur, "orders", "discount_type", "TEXT")
    _ensure_column(cur, "orders", "discount_rate", "REAL NOT NULL DEFAULT 0")
    _ensure_column(cur, "orders", "discount_amount", "REAL NOT NULL DEFAULT 0")
    _ensure_column(cur, "orders", "discount_id", "TEXT")
    new_stock = _ensure_column(cur, "menu", "stock_qty", "INTEGER NOT NULL DEFAULT 50")
    new_allergens = _ensure_column(cur, "menu", "allergens", "TEXT NOT NULL DEFAULT 'none'")
    if new_stock:
        for name, qty in _DEFAULT_STOCK.items():
            cur.execute("UPDATE menu SET stock_qty = ? WHERE name = ?", (qty, name))
    if new_allergens:
        for name, al in _DEFAULT_ALLERGENS.items():
            cur.execute("UPDATE menu SET allergens = ? WHERE name = ?", (al, name))

    # ---- seed menu if empty ----
    cur.execute("SELECT COUNT(*) FROM menu")
    if cur.fetchone()[0] == 0:
        default_menu = [
            ("Cheeseburger", "Mains", 180.00, 1, "Juicy beef patty, melted cheddar, lettuce, tomato and house sauce on a toasted bun.", 0),
            ("Veggie Burger", "Mains", 170.00, 1, "Crisp garden-vegetable and bean patty with avocado spread and fresh greens.", 1),
            ("Spaghetti Bolognese", "Mains", 220.00, 1, "Slow-simmered beef ragu over al dente spaghetti, finished with parmesan.", 0),
            ("Chicken Adobo Rice", "Mains", 160.00, 1, "Soy-vinegar braised chicken, garlic and bay leaf over steamed garlic rice.", 0),
            ("Pesto Pasta", "Mains", 200.00, 1, "Fresh basil pesto, pine nuts and parmesan tossed through penne.", 1),
            ("French Fries", "Sides", 80.00, 1, "Golden, crispy shoestring fries lightly salted. Perfect for sharing.", 1),
            ("Garden Salad", "Sides", 95.00, 1, "Mixed greens, cherry tomato, cucumber and carrot with a light vinaigrette.", 1),
            ("Onion Rings", "Sides", 90.00, 0, "Thick-cut onions in a crunchy golden batter, served with dipping sauce.", 1),
            ("Iced Tea", "Drinks", 75.00, 1, "Freshly brewed black tea over ice with a squeeze of lemon.", 1),
            ("Mango Smoothie", "Drinks", 110.00, 1, "Ripe Philippine mango blended with milk and ice. Sweet and creamy.", 1),
            ("Cola", "Drinks", 65.00, 1, "Ice-cold classic cola, served in a tall glass.", 1),
            ("Bottled Water", "Drinks", 40.00, 1, "Purified still water, chilled.", 1),
            ("Matcha Sea Salt", "Drinks", 120.00, 1, "Creamy iced matcha topped with a hint of sea salt foam.", 1),
            ("Leche Flan", "Desserts", 90.00, 1, "Silky caramel custard, steamed low and slow the traditional way.", 1),
            ("Halo-Halo", "Desserts", 130.00, 1, "Shaved ice with sweet beans, fruit, leche flan, ube and evaporated milk.", 1),
        ]
        cur.executemany("""
            INSERT OR IGNORE INTO menu (name, category, price, available, description, vegetarian, stock_qty, allergens)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [(n, c, p, a, d, v, _DEFAULT_STOCK.get(n, DEFAULT_STOCK), _DEFAULT_ALLERGENS.get(n, "none"))
              for (n, c, p, a, d, v) in default_menu])
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Menu
# ---------------------------------------------------------------------------
def _split_allergens(raw: Optional[str]) -> list[str]:
    parts = [p.strip().lower() for p in (raw or "").split(",")]
    return [p for p in parts if p and p != "none"]


def _item_from_row(r: sqlite3.Row) -> dict:
    stock = int(r["stock_qty"])
    enabled = bool(r["available"])
    return {
        "id": r["id"],
        "name": r["name"],
        "category": r["category"],
        "price": r["price"],
        "available": enabled and stock > 0,   # what customers can actually order
        "enabled": enabled,                    # the manager's on/off switch
        "stock": stock,
        "low_stock": 0 < stock <= LOW_STOCK_THRESHOLD,
        "description": r["description"] or "",
        "vegetarian": bool(r["vegetarian"]),
        "allergens": _split_allergens(r["allergens"]),
    }


def get_menu_by_category(category: str = "all") -> dict:
    conn = _get_conn()
    cur = conn.cursor()
    if str(category).lower() == "all":
        cur.execute("SELECT * FROM menu ORDER BY id")
    else:
        cur.execute("SELECT * FROM menu WHERE category COLLATE NOCASE = ? ORDER BY id", (str(category).strip(),))
    rows = cur.fetchall()
    conn.close()
    menu_dict: dict[str, list] = {}
    for r in rows:
        menu_dict.setdefault(r["category"], []).append(_item_from_row(r))
    return {"status": "ok", "menu": menu_dict}


def list_menu_items() -> list[dict]:
    conn = _get_conn()
    rows = conn.execute("SELECT * FROM menu ORDER BY category, id").fetchall()
    conn.close()
    return [_item_from_row(r) for r in rows]


def get_menu_item(item_id: int) -> Optional[dict]:
    conn = _get_conn()
    r = conn.execute("SELECT * FROM menu WHERE id = ?", (item_id,)).fetchone()
    conn.close()
    return _item_from_row(r) if r else None


def _clean_allergens(value: Any) -> Optional[str]:
    if value is None:
        return "none"
    items = value if isinstance(value, (list, tuple)) else str(value).split(",")
    out: list[str] = []
    for a in items:
        a = str(a).strip().lower()
        a = _ALLERGEN_ALIASES.get(a, a)
        if a in ("", "none"):
            continue
        if not re.fullmatch(r"[a-z][a-z ]{0,19}", a):
            return None
        if a not in out:
            out.append(a)
    return ",".join(out) if out else "none"


def _validate_item_fields(f: dict, partial: bool) -> tuple[Optional[dict], Optional[dict]]:
    """Return (clean_columns, error). Column names are menu-table columns."""
    clean: dict[str, Any] = {}
    if "name" in f or not partial:
        name = str(f.get("name", "")).strip()
        if not (1 <= len(name) <= 60):
            return None, _err("invalid_name", "Name must be 1-60 characters.")
        clean["name"] = name
    if "category" in f or not partial:
        cat = str(f.get("category", "")).strip()
        if not (1 <= len(cat) <= 30):
            return None, _err("invalid_category", "Category must be 1-30 characters.")
        clean["category"] = cat
    if "price" in f or not partial:
        price = _to_float(f.get("price"), default=-1)
        if price is None or not (0 <= price <= 100000):
            return None, _err("invalid_price", "Price must be a number between 0 and 100000.")
        clean["price"] = round(price, 2)
    if "description" in f:
        clean["description"] = str(f.get("description") or "").strip()[:300]
    if "vegetarian" in f:
        clean["vegetarian"] = 1 if f.get("vegetarian") in (True, 1, "1", "true", "True") else 0
    if "available" in f:
        clean["available"] = 1 if f.get("available") in (True, 1, "1", "true", "True") else 0
    if "stock" in f or "stock_qty" in f:
        stock = _to_int(f.get("stock", f.get("stock_qty")))
        if stock is None or not (0 <= stock <= 9999):
            return None, _err("invalid_stock", "Stock must be a whole number between 0 and 9999.")
        clean["stock_qty"] = stock
    if "allergens" in f:
        al = _clean_allergens(f.get("allergens"))
        if al is None:
            return None, _err("invalid_allergens", "Allergens must be short words such as gluten, dairy, egg.")
        clean["allergens"] = al
    return clean, None


def admin_add_menu_item(**fields: Any) -> dict:
    fields.setdefault("stock", DEFAULT_STOCK)
    fields.setdefault("available", True)
    fields.setdefault("allergens", "none")
    clean, err = _validate_item_fields(fields, partial=False)
    if err:
        return err
    conn = _get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO menu (name, category, price, available, description, vegetarian, stock_qty, allergens) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (clean["name"], clean["category"], clean["price"], clean.get("available", 1),
             clean.get("description", ""), clean.get("vegetarian", 0), clean["stock_qty"], clean["allergens"]))
        conn.commit()
        item_id = cur.lastrowid
    except sqlite3.IntegrityError:
        conn.close()
        return _err("duplicate_name", f"There is already a menu item called {clean['name']!r}.")
    conn.close()
    return {"status": "ok", "item": get_menu_item(item_id)}


def admin_update_menu_item(item_id: int, **fields: Any) -> dict:
    clean, err = _validate_item_fields(fields, partial=True)
    if err:
        return err
    if not clean:
        return _err("nothing_to_update", "No valid fields were given.")
    conn = _get_conn()
    old = conn.execute("SELECT name FROM menu WHERE id = ?", (item_id,)).fetchone()
    if not old:
        conn.close()
        return _err("unknown_item", "That menu item does not exist.")
    try:
        sets = ", ".join(f"{col} = ?" for col in clean)          # column names come from a whitelist above
        conn.execute(f"UPDATE menu SET {sets} WHERE id = ?", (*clean.values(), item_id))
        if "name" in clean and clean["name"] != old["name"]:      # keep open carts valid after a rename
            conn.execute("UPDATE order_items SET name = ? WHERE name = ?", (clean["name"], old["name"]))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return _err("duplicate_name", f"There is already a menu item called {clean.get('name')!r}.")
    conn.close()
    return {"status": "ok", "item": get_menu_item(item_id)}


def admin_delete_menu_item(item_id: int) -> dict:
    conn = _get_conn()
    row = conn.execute("SELECT name FROM menu WHERE id = ?", (item_id,)).fetchone()
    if not row:
        conn.close()
        return _err("unknown_item", "That menu item does not exist.")
    used = conn.execute("SELECT COUNT(*) FROM order_lines WHERE name = ?", (row["name"],)).fetchone()[0]
    if used:
        conn.close()
        return _err("item_in_use", f"{row['name']} appears in past orders, so it can't be deleted. "
                                   "Switch it to 'unavailable' to hide it from customers instead.")
    conn.execute("DELETE FROM order_items WHERE name = ?", (row["name"],))
    conn.execute("DELETE FROM menu WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
    return {"status": "ok", "deleted": row["name"]}


def low_stock_items() -> list[dict]:
    return [i for i in list_menu_items() if i["enabled"] and i["stock"] <= LOW_STOCK_THRESHOLD]


def check_item_allergen(item_name: str, allergen: str) -> dict:
    conn = _get_conn()
    r = conn.execute("SELECT * FROM menu WHERE name COLLATE NOCASE = ?", (str(item_name).strip(),)).fetchone()
    conn.close()
    if not r:
        return _err("unknown_item", f"Item {item_name!r} is not on the menu.")
    listed = _split_allergens(r["allergens"])
    a = str(allergen).strip().lower()
    a = _ALLERGEN_ALIASES.get(a, a)
    contains = a in listed or a.rstrip("s") in listed
    return {"status": "ok", "item": r["name"], "allergen": a, "contains_allergen": contains,
            "listed_allergens": listed, "note": "Based on the bistro's allergen records only."}


def get_popular_items(limit: int = 3) -> dict:
    limit = max(1, min(_to_int(limit) or 3, 10))
    since = (datetime.now() - timedelta(days=30)).isoformat(sep=" ", timespec="seconds")
    conn = _get_conn()
    rows = conn.execute("""
        SELECT l.name AS name, SUM(l.quantity) AS qty, m.price AS price
        FROM order_lines l JOIN orders o ON o.order_id = l.order_id
        JOIN menu m ON m.name = l.name
        WHERE o.status != 'cancelled' AND o.created_at >= ? AND m.available = 1 AND m.stock_qty > 0
        GROUP BY l.name ORDER BY qty DESC, l.name LIMIT ?""", (since, limit)).fetchall()
    items = [{"name": r["name"], "price": r["price"], "ordered": r["qty"]} for r in rows]
    if len(items) < limit:   # not enough history: pad with in-stock mains / first dishes
        have = {i["name"] for i in items}
        for r in conn.execute("SELECT name, price FROM menu WHERE available = 1 AND stock_qty > 0 "
                              "ORDER BY CASE category WHEN 'Mains' THEN 0 ELSE 1 END, id").fetchall():
            if r["name"] not in have and len(items) < limit:
                items.append({"name": r["name"], "price": r["price"], "ordered": 0})
    conn.close()
    return {"status": "ok", "items": items}


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------
def create_table_session(table_no: int) -> dict:
    table_no = _to_int(table_no)
    if table_no is None or not (1 <= table_no <= 50):
        return _err("invalid_table", "Table number must be between 1 and 50.")
    conn = _get_conn()
    cur = conn.execute("INSERT INTO sessions (table_no, status, created_at) VALUES (?, 'active', ?)",
                       (table_no, _now()))
    session_id = cur.lastrowid
    conn.commit()
    conn.close()
    return {"status": "ok", "session_id": session_id, "table_no": table_no}


def get_session(session_id: Optional[int]) -> Optional[dict]:
    if not session_id:
        return None
    conn = _get_conn()
    r = conn.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
    conn.close()
    return dict(r) if r else None


def session_is_active(session_id: Optional[int]) -> bool:
    s = get_session(session_id)
    return bool(s and s["status"] == "active")


def cancel_session(session_id: int) -> dict:
    """End a session. A session that already sent orders is 'closed'; an empty one is 'cancelled'."""
    conn = _get_conn()
    n_orders = conn.execute("SELECT COUNT(*) FROM orders WHERE session_id = ?", (session_id,)).fetchone()[0]
    status = "closed" if n_orders else "cancelled"
    conn.execute("UPDATE sessions SET status = ?, closed_at = ? WHERE session_id = ? AND status = 'active'",
                 (status, _now(), session_id))
    conn.execute("DELETE FROM order_items WHERE session_id = ?", (session_id,))
    conn.execute("UPDATE service_requests SET status = 'done', done_at = ? WHERE session_id = ? AND status = 'open'",
                 (_now(), session_id))
    conn.commit()
    conn.close()
    return {"status": "ok", "message": "Session ended."}


def close_table(table_no: int) -> dict:
    conn = _get_conn()
    ids = [r[0] for r in conn.execute("SELECT session_id FROM sessions WHERE table_no = ? AND status = 'active'",
                                      (table_no,)).fetchall()]
    conn.close()
    for sid in ids:
        cancel_session(sid)
    return {"status": "ok", "table_no": table_no, "closed_sessions": ids}


def close_orphan_sessions() -> int:
    """Call at server start: no browser can still own an 'active' session after a restart."""
    conn = _get_conn()
    ids = [r[0] for r in conn.execute("SELECT session_id FROM sessions WHERE status = 'active'").fetchall()]
    conn.close()
    for sid in ids:
        cancel_session(sid)
    return len(ids)


# ---------------------------------------------------------------------------
# Cart
# ---------------------------------------------------------------------------
def _check_add(cur: sqlite3.Cursor, session_id: int, item_name: str, qty: Any,
               already_pending: int = 0) -> tuple[Optional[dict], Optional[dict]]:
    """Validate an add. Returns (info, error)."""
    q = _to_int(qty)
    if q is None or q <= 0:
        return None, _err("invalid_qty", "Quantity must be a positive whole number.")
    if q > MAX_QTY_PER_LINE:
        return None, _err("invalid_qty", f"Please order at most {MAX_QTY_PER_LINE} of one dish at a time.")
    s = cur.execute("SELECT status FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
    if not s or s["status"] != "active":
        return None, _err("invalid_session", "This table session is no longer open. Please pick your table again.")
    row = cur.execute("SELECT * FROM menu WHERE name COLLATE NOCASE = ?", (str(item_name).strip(),)).fetchone()
    if not row:
        return None, _err("unknown_item", f"Item {item_name!r} is not on the menu.")
    if not row["available"] or row["stock_qty"] <= 0:
        return None, _err("sold_out", f"Item {row['name']!r} is currently sold out.")
    in_cart = cur.execute("SELECT COALESCE(SUM(quantity), 0) FROM order_items WHERE session_id = ? AND name = ?",
                          (session_id, row["name"])).fetchone()[0]
    left = row["stock_qty"] - in_cart - already_pending
    if q > left:
        msg = (f"Only {row['stock_qty']} {row['name']} left in stock." if in_cart + already_pending == 0
               else f"Only {max(left, 0)} more {row['name']} available (you already have {in_cart + already_pending}).")
        return None, _err("insufficient_stock", msg, available=max(left, 0))
    return {"name": row["name"], "price": row["price"], "quantity": q, "stock_left": left - q}, None


def check_can_add(session_id: int, item_name: str, qty: Any = 1, already_pending: int = 0) -> dict:
    """Dry run of add_item_to_order (used for AI orders that wait for the customer's yes/no)."""
    conn = _get_conn()
    info, err = _check_add(conn.cursor(), session_id, item_name, qty, already_pending)
    conn.close()
    return err if err else {"status": "ok", **info}


def add_item_to_order(session_id: int, item_name: str, qty: int = 1, instructions: str = "") -> dict:
    conn = _get_conn()
    cur = conn.cursor()
    info, err = _check_add(cur, session_id, item_name, qty)
    if err:
        conn.close()
        return err
    ins = str(instructions or "").strip()[:200]
    cur.execute("INSERT INTO order_items (session_id, name, quantity, instructions, unit_price) VALUES (?, ?, ?, ?, ?)",
                (session_id, info["name"], info["quantity"], ins, info["price"]))
    conn.commit()
    conn.close()
    return {"status": "ok", "added": {"item": info["name"], "quantity": info["quantity"], "instructions": ins,
                                      "unit_price": info["price"]}, "stock_left": info["stock_left"]}


def remove_item_from_order(session_id: int, item_name: str, qty: Optional[int] = None) -> dict:
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("SELECT name FROM menu WHERE name COLLATE NOCASE = ?", (str(item_name).strip(),))
    row = cur.fetchone()
    if not row:
        conn.close()
        return _err("unknown_item", f"Item {item_name!r} is not on the menu.")
    canonical_name = row["name"]

    cur.execute("SELECT item_id, quantity FROM order_items WHERE session_id = ? AND name = ?", (session_id, canonical_name))
    items = cur.fetchall()
    if not items:
        conn.close()
        return _err("not_in_order", f"Item {canonical_name!r} is not in your current order.")

    q = _to_int(qty) if qty is not None else None
    if q is None:
        cur.execute("DELETE FROM order_items WHERE session_id = ? AND name = ?", (session_id, canonical_name))
        removed_qty = sum(i["quantity"] for i in items)
    else:
        remaining = max(q, 0)
        removed_qty = 0
        for item in items:
            if remaining <= 0:
                break
            if item["quantity"] <= remaining:
                cur.execute("DELETE FROM order_items WHERE item_id = ?", (item["item_id"],))
                remaining -= item["quantity"]
                removed_qty += item["quantity"]
            else:
                cur.execute("UPDATE order_items SET quantity = ? WHERE item_id = ?", (item["quantity"] - remaining, item["item_id"]))
                removed_qty += remaining
                remaining = 0
    conn.commit()
    conn.close()
    return {"status": "ok", "removed": {"item": canonical_name, "quantity": removed_qty}}


def _cart_lines(cur: sqlite3.Cursor, session_id: int) -> list[sqlite3.Row]:
    return cur.execute("""
        SELECT name, SUM(quantity) AS quantity, COALESCE(instructions, '') AS instructions, unit_price
        FROM order_items WHERE session_id = ?
        GROUP BY name, COALESCE(instructions, ''), unit_price
        ORDER BY MIN(item_id)""", (session_id,)).fetchall()


def view_current_order(session_id: int) -> dict:
    conn = _get_conn()
    cur = conn.cursor()
    session = cur.execute("SELECT table_no, status, discount_type, discount_id FROM sessions WHERE session_id = ?",
                          (session_id,)).fetchone()
    if not session:
        conn.close()
        return _err("invalid_session", "Session not found.")
    rows = _cart_lines(cur, session_id)
    conn.close()

    items = []
    subtotal = 0.0
    for r in rows:
        line_total = round(r["quantity"] * r["unit_price"], 2)
        subtotal += line_total
        items.append({"name": r["name"], "quantity": r["quantity"], "instructions": r["instructions"] or "",
                      "unit_price": r["unit_price"], "line_total": line_total})
    subtotal = round(subtotal, 2)
    d_type, d_rate, d_amount = _discount_for(session["discount_type"], subtotal)
    service_fee = round((subtotal - d_amount) * SERVICE_FEE_RATE, 2)
    return {
        "status": "ok", "session_id": session_id, "table_no": session["table_no"],
        "is_empty": len(items) == 0, "items": items, "subtotal": subtotal,
        "discount_type": d_type, "discount_label": DISCOUNTS[d_type]["label"] if d_type else None,
        "discount_rate": d_rate, "discount_amount": d_amount, "discount_id": session["discount_id"],
        "service_fee_rate": SERVICE_FEE_RATE, "service_fee": service_fee,
        "grand_total": round(subtotal - d_amount + service_fee, 2), "currency": CURRENCY,
    }


def _discount_for(kind: Optional[str], subtotal: float) -> tuple[Optional[str], float, float]:
    """(type, rate, amount) for a session's discount; (None, 0, 0) when there is none."""
    if kind in DISCOUNTS:
        rate = DISCOUNTS[kind]["rate"]
        return kind, rate, round(subtotal * rate, 2)
    return None, 0.0, 0.0


def set_session_discount(session_id: int, kind: Optional[str], id_no: str = "") -> dict:
    """Apply (or remove, with kind=None/'') the PWD / Senior Citizen discount for this table session.
    The ID number is only a note for the cashier: staff must still check the physical ID."""
    kind = (str(kind).strip().lower() if kind else "") or None
    if kind is not None and kind not in DISCOUNTS:
        return _err("invalid_discount", "Discount must be one of: " + ", ".join(DISCOUNTS) + ".")
    id_clean = re.sub(r"[^A-Za-z0-9\- ]", "", str(id_no or ""))[:30].strip() or None
    conn = _get_conn()
    try:
        s = conn.execute("SELECT status FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not s or s["status"] != "active":
            return _err("invalid_session", "This table session is no longer open. Please pick your table again.")
        conn.execute("UPDATE sessions SET discount_type = ?, discount_id = ? WHERE session_id = ?",
                     (kind, id_clean if kind else None, session_id))
        conn.commit()
    finally:
        conn.close()
    return {"status": "ok", "discount_type": kind, "discount_label": DISCOUNTS[kind]["label"] if kind else None,
            "discount_id": id_clean if kind else None, "cart": view_current_order(session_id)}


def clear_order(session_id: int) -> dict:
    conn = _get_conn()
    conn.execute("DELETE FROM order_items WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()
    return {"status": "ok", "message": "Order cleared."}


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------
def _payment_note(method: str, ref: Optional[str]) -> str:
    if PAYMENT_METHODS[method]["type"] == "cash":
        return "Please pay cash at the counter or to your server."
    return f"Paid with {method} (demo payment - no real money moved). Reference: {ref}"


def confirm_order(session_id: int, payment_method: Optional[str] = None, tip: Any = 0.0,
                  split_count: Any = 1) -> dict:
    """Turn the cart into a kitchen order: checks + deducts stock, records payment, clears the cart.
    Everything happens in one transaction, so two tables can't both take the last portion."""
    method = find_payment_method(payment_method)
    if method is None:
        return _err("invalid_payment", "Please choose a payment method: " + ", ".join(PAYMENT_METHODS) + ".")
    tip_f = _to_float(tip, 0.0)
    if tip_f is None or not (0 <= tip_f <= 10000):
        return _err("invalid_tip", "Tip must be an amount between 0 and 10,000.")
    split = _to_int(split_count if split_count not in (None, "") else 1)
    if split is None or not (1 <= split <= 20):
        return _err("invalid_split", "Split must be between 1 and 20 people.")
    tip_f = round(tip_f, 2)

    conn = _get_conn()
    conn.isolation_level = None            # we manage the transaction ourselves
    cur = conn.cursor()
    try:
        cur.execute("BEGIN IMMEDIATE")
        s = cur.execute("SELECT table_no, status FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
        if not s or s["status"] != "active":
            cur.execute("ROLLBACK")
            return _err("invalid_session", "This table session is no longer open.")
        lines = _cart_lines(cur, session_id)
        if not lines:
            cur.execute("ROLLBACK")
            return _err("empty_order", "Cannot confirm an empty order.")

        need: dict[str, int] = {}
        for l in lines:
            need[l["name"]] = need.get(l["name"], 0) + l["quantity"]
        problems = []
        for name, qty in need.items():
            m = cur.execute("SELECT available, stock_qty FROM menu WHERE name = ?", (name,)).fetchone()
            if not m or not m["available"]:
                problems.append({"item": name, "available": 0})
            elif m["stock_qty"] < qty:
                problems.append({"item": name, "available": m["stock_qty"]})
        if problems:
            cur.execute("ROLLBACK")
            detail = "; ".join(f"{p['item']} (only {p['available']} left)" if p["available"] else f"{p['item']} (sold out)"
                               for p in problems)
            return {"status": "error", "error": "item_unavailable",
                    "message": f"Some items are no longer available: {detail}.", "problems": problems}
        for name, qty in need.items():
            cur.execute("UPDATE menu SET stock_qty = stock_qty - ? WHERE name = ?", (qty, name))

        items = []
        subtotal = 0.0
        for l in lines:
            lt = round(l["quantity"] * l["unit_price"], 2)
            subtotal += lt
            items.append({"name": l["name"], "quantity": l["quantity"], "instructions": l["instructions"],
                          "unit_price": l["unit_price"], "line_total": lt})
        subtotal = round(subtotal, 2)
        ds = cur.execute("SELECT discount_type, discount_id FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
        d_type, d_rate, d_amount = _discount_for(ds["discount_type"] if ds else None, subtotal)
        d_id = ds["discount_id"] if (ds and d_type) else None
        fee = round((subtotal - d_amount) * SERVICE_FEE_RATE, 2)
        grand = round(subtotal - d_amount + fee + tip_f, 2)
        round_no = cur.execute("SELECT COUNT(*) FROM orders WHERE session_id = ?", (session_id,)).fetchone()[0] + 1
        now = _now()
        online = PAYMENT_METHODS[method]["type"] == "online"

        cur.execute("""INSERT INTO orders (session_id, table_no, round_no, status, subtotal, service_fee, tip, grand_total,
                         split_count, payment_method, payment_status, created_at, updated_at, paid_at,
                         discount_type, discount_rate, discount_amount, discount_id)
                       VALUES (?, ?, ?, 'received', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (session_id, s["table_no"], round_no, subtotal, fee, tip_f, grand, split, method,
                     "paid" if online else "unpaid", now, now, now if online else None,
                     d_type, d_rate, d_amount, d_id))
        order_id = cur.lastrowid
        ref = None
        if online:
            ref = f"DEMO-{PAYMENT_METHODS[method]['code']}-{datetime.now():%Y%m%d}-{order_id:04d}"
            cur.execute("UPDATE orders SET payment_ref = ? WHERE order_id = ?", (ref, order_id))
        cur.executemany("INSERT INTO order_lines (order_id, name, quantity, instructions, unit_price) VALUES (?, ?, ?, ?, ?)",
                        [(order_id, i["name"], i["quantity"], i["instructions"], i["unit_price"]) for i in items])
        cur.execute("DELETE FROM order_items WHERE session_id = ?", (session_id,))
        cur.execute("UPDATE sessions SET payment_method = ? WHERE session_id = ?", (method, session_id))
        cur.execute("COMMIT")
    except Exception:
        try:
            cur.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.close()

    return {
        "status": "ok", "order_id": order_id, "round_no": round_no, "session_id": session_id,
        "table_no": s["table_no"], "items": items, "subtotal": subtotal, "service_fee": fee,
        "discount_type": d_type, "discount_label": DISCOUNTS[d_type]["label"] if d_type else None,
        "discount_rate": d_rate, "discount_amount": d_amount, "discount_id": d_id,
        "service_fee_rate": SERVICE_FEE_RATE, "tip": tip_f, "grand_total": grand, "split_count": split,
        "per_person": round(grand / split, 2), "currency": CURRENCY, "confirmed_at": now,
        "payment_method": method, "payment_type": PAYMENT_METHODS[method]["type"],
        "payment_status": "paid" if online else "unpaid", "payment_ref": ref,
        "payment_note": _payment_note(method, ref),
    }


def _order_dicts(conn: sqlite3.Connection, rows: Iterable[sqlite3.Row]) -> list[dict]:
    rows = list(rows)
    if not rows:
        return []
    ids = [r["order_id"] for r in rows]
    marks = ",".join("?" * len(ids))
    lines: dict[int, list] = {i: [] for i in ids}
    for l in conn.execute(f"SELECT * FROM order_lines WHERE order_id IN ({marks}) ORDER BY line_id", ids):
        lines[l["order_id"]].append({"name": l["name"], "quantity": l["quantity"], "instructions": l["instructions"] or "",
                                     "unit_price": l["unit_price"], "line_total": round(l["quantity"] * l["unit_price"], 2)})
    fb = {r["order_id"]: {"rating": r["rating"], "comment": r["comment"]}
          for r in conn.execute(f"SELECT order_id, rating, comment FROM feedback WHERE order_id IN ({marks})", ids)}
    now = datetime.now()
    out = []
    for r in rows:
        d = dict(r)
        created = _parse_ts(r["created_at"])
        d["age_seconds"] = max(0, int((now - created).total_seconds())) if created else 0
        d["items"] = lines[r["order_id"]]
        d["item_count"] = sum(i["quantity"] for i in d["items"])
        d["per_person"] = round(r["grand_total"] / max(r["split_count"], 1), 2)
        d["currency"] = CURRENCY
        d["feedback"] = fb.get(r["order_id"])
        out.append(d)
    return out


def get_order(order_id: int) -> Optional[dict]:
    conn = _get_conn()
    r = conn.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,)).fetchone()
    res = _order_dicts(conn, [r] if r else [])
    conn.close()
    return res[0] if res else None


def list_orders(status: Any = "active", session_id: Optional[int] = None, date: Optional[str] = None,
                table_no: Optional[int] = None, limit: int = 200) -> list[dict]:
    """status: 'active' (received/preparing/ready), 'all', one status, or a list of statuses.
    Active orders come oldest-first (kitchen queue); everything else newest-first."""
    where, params = [], []
    if status == "active":
        where.append("status IN ('received','preparing','ready')")
    elif status and status != "all":
        wanted = status if isinstance(status, (list, tuple)) else str(status).split(",")
        wanted = [s for s in wanted if s in ORDER_STATUSES]
        if not wanted:
            return []
        where.append(f"status IN ({','.join('?' * len(wanted))})")
        params += wanted
    if session_id is not None:
        where.append("session_id = ?"); params.append(session_id)
    if table_no is not None:
        where.append("table_no = ?"); params.append(table_no)
    if date:
        where.append("substr(created_at, 1, 10) = ?"); params.append(date)
    sql = "SELECT * FROM orders" + (" WHERE " + " AND ".join(where) if where else "")
    sql += " ORDER BY created_at ASC, order_id ASC" if status == "active" else " ORDER BY created_at DESC, order_id DESC"
    sql += " LIMIT ?"
    params.append(max(1, min(int(limit), 1000)))
    conn = _get_conn()
    res = _order_dicts(conn, conn.execute(sql, params).fetchall())
    conn.close()
    return res


def session_orders(session_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute("SELECT * FROM orders WHERE session_id = ? ORDER BY order_id", (session_id,)).fetchall()
    res = _order_dicts(conn, rows)
    conn.close()
    return res


def set_order_status(order_id: int, new_status: str, reason: str = "", role: str = "kitchen") -> dict:
    """Move an order along received -> preparing -> ready -> served (one step back is allowed to fix mistakes).
    Cancelling needs a reason; kitchen staff may cancel only received/preparing orders, managers any order."""
    if new_status not in ORDER_STATUSES:
        return _err("invalid_status", f"Status must be one of: {', '.join(ORDER_STATUSES)}.")
    conn = _get_conn()
    conn.isolation_level = None
    cur = conn.cursor()
    try:
        cur.execute("BEGIN IMMEDIATE")
        o = cur.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,)).fetchone()
        if not o:
            cur.execute("ROLLBACK")
            return _err("unknown_order", "That order does not exist.")
        cur_status = o["status"]
        now = _now()
        if cur_status == "cancelled":
            cur.execute("ROLLBACK")
            return _err("invalid_transition", "This order was cancelled and can't be changed.")
        if new_status == cur_status:
            cur.execute("ROLLBACK")
            return {"status": "ok", "order": get_order(order_id), "unchanged": True}

        if new_status == "cancelled":
            reason = str(reason or "").strip()[:200]
            if len(reason) < 2:
                cur.execute("ROLLBACK")
                return _err("reason_required", "Please give a short reason for cancelling.")
            if cur_status in ("ready", "served") and role != "manager":
                cur.execute("ROLLBACK")
                return _err("not_allowed", "Only a manager can cancel an order that is already ready or served.")
            if cur_status in ("received", "preparing"):     # food not made yet: put the stock back
                for l in cur.execute("SELECT name, quantity FROM order_lines WHERE order_id = ?", (order_id,)).fetchall():
                    cur.execute("UPDATE menu SET stock_qty = stock_qty + ? WHERE name = ?", (l["quantity"], l["name"]))
            pay = {"paid": "refunded", "unpaid": "void"}.get(o["payment_status"], o["payment_status"])
            cur.execute("UPDATE orders SET status = 'cancelled', cancel_reason = ?, payment_status = ?, updated_at = ? "
                        "WHERE order_id = ?", (reason, pay, now, order_id))
        else:
            if _NEXT.get(cur_status) == new_status:
                cur.execute(f"UPDATE orders SET status = ?, updated_at = ?, {_STATUS_TS[new_status]} = ? WHERE order_id = ?",
                            (new_status, now, now, order_id))
            elif _BACK.get(cur_status) == new_status:
                stale = _STATUS_TS.get(cur_status)
                extra = f", {stale} = NULL" if stale else ""
                cur.execute(f"UPDATE orders SET status = ?, updated_at = ?{extra} WHERE order_id = ?",
                            (new_status, now, order_id))
            else:
                cur.execute("ROLLBACK")
                return _err("invalid_transition", f"An order can't go from {cur_status} to {new_status}.")
        cur.execute("COMMIT")
    except Exception:
        try:
            cur.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.close()
    return {"status": "ok", "order": get_order(order_id), "previous": cur_status}


def mark_order_paid(order_id: int, ref: Optional[str] = None) -> dict:
    o = get_order(order_id)
    if not o:
        return _err("unknown_order", "That order does not exist.")
    if o["status"] == "cancelled":
        return _err("invalid_transition", "A cancelled order can't be paid.")
    if o["payment_status"] == "paid":
        return {"status": "ok", "order": o, "unchanged": True}
    ref = (str(ref).strip()[:40] if ref else None) or f"CASH-{datetime.now():%Y%m%d}-{order_id:04d}"
    conn = _get_conn()
    conn.execute("UPDATE orders SET payment_status = 'paid', payment_ref = ?, paid_at = ?, updated_at = ? WHERE order_id = ?",
                 (ref, _now(), _now(), order_id))
    conn.commit()
    conn.close()
    return {"status": "ok", "order": get_order(order_id)}


# ---------------------------------------------------------------------------
# Service requests (call server / water / bill)
# ---------------------------------------------------------------------------
def _request_dict(r: sqlite3.Row) -> dict:
    d = dict(r)
    d["label"] = SERVICE_KINDS.get(r["kind"], r["kind"])
    created = _parse_ts(r["created_at"])
    d["age_seconds"] = max(0, int((datetime.now() - created).total_seconds())) if created else 0
    return d


def create_service_request(session_id: int, kind: str, note: str = "") -> dict:
    if kind not in SERVICE_KINDS:
        return _err("invalid_kind", f"Request must be one of: {', '.join(SERVICE_KINDS)}.")
    conn = _get_conn()
    s = conn.execute("SELECT table_no, status FROM sessions WHERE session_id = ?", (session_id,)).fetchone()
    if not s or s["status"] != "active":
        conn.close()
        return _err("invalid_session", "Pick your table first.")
    dup = conn.execute("SELECT * FROM service_requests WHERE session_id = ? AND kind = ? AND status = 'open'",
                       (session_id, kind)).fetchone()
    if dup:
        conn.close()
        return {"status": "ok", "duplicate": True, "request": _request_dict(dup)}
    cur = conn.execute("INSERT INTO service_requests (session_id, table_no, kind, note, created_at) VALUES (?, ?, ?, ?, ?)",
                       (session_id, s["table_no"], kind, str(note or "").strip()[:200], _now()))
    conn.commit()
    r = conn.execute("SELECT * FROM service_requests WHERE request_id = ?", (cur.lastrowid,)).fetchone()
    conn.close()
    return {"status": "ok", "duplicate": False, "request": _request_dict(r)}


def list_service_requests(open_only: bool = True, session_id: Optional[int] = None, limit: int = 100) -> list[dict]:
    where, params = [], []
    if open_only:
        where.append("status = 'open'")
    if session_id is not None:
        where.append("session_id = ?"); params.append(session_id)
    sql = "SELECT * FROM service_requests" + (" WHERE " + " AND ".join(where) if where else "")
    sql += " ORDER BY created_at ASC, request_id ASC LIMIT ?"
    conn = _get_conn()
    rows = conn.execute(sql, (*params, limit)).fetchall()
    conn.close()
    return [_request_dict(r) for r in rows]


def resolve_service_request(request_id: int) -> dict:
    conn = _get_conn()
    r = conn.execute("SELECT * FROM service_requests WHERE request_id = ?", (request_id,)).fetchone()
    if not r:
        conn.close()
        return _err("unknown_request", "That request does not exist.")
    conn.execute("UPDATE service_requests SET status = 'done', done_at = ? WHERE request_id = ? AND status = 'open'",
                 (_now(), request_id))
    conn.commit()
    r = conn.execute("SELECT * FROM service_requests WHERE request_id = ?", (request_id,)).fetchone()
    conn.close()
    return {"status": "ok", "request": _request_dict(r)}


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------
def add_feedback(order_id: int, rating: Any, comment: str = "") -> dict:
    rt = _to_int(rating)
    if rt is None or not (1 <= rt <= 5):
        return _err("invalid_rating", "Rating must be a whole number from 1 to 5.")
    o = get_order(order_id)
    if not o:
        return _err("unknown_order", "That order does not exist.")
    if o["status"] == "cancelled":
        return _err("invalid_order", "A cancelled order can't be rated.")
    conn = _get_conn()
    try:
        conn.execute("INSERT INTO feedback (order_id, rating, comment, created_at) VALUES (?, ?, ?, ?)",
                     (order_id, rt, str(comment or "").strip()[:500], _now()))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return _err("already_rated", "You've already rated this order. Thank you!")
    conn.close()
    return {"status": "ok", "order_id": order_id, "rating": rt}


def list_feedback(limit: int = 100) -> dict:
    conn = _get_conn()
    rows = conn.execute("""SELECT f.*, o.table_no, o.round_no FROM feedback f
                           LEFT JOIN orders o ON o.order_id = f.order_id
                           ORDER BY f.feedback_id DESC LIMIT ?""", (limit,)).fetchall()
    agg = conn.execute("SELECT COUNT(*) AS n, AVG(rating) AS avg FROM feedback").fetchone()
    dist = {r["rating"]: r["n"] for r in conn.execute("SELECT rating, COUNT(*) AS n FROM feedback GROUP BY rating")}
    conn.close()
    return {"status": "ok", "count": agg["n"], "average": round(agg["avg"], 2) if agg["avg"] else None,
            "distribution": {str(i): dist.get(i, 0) for i in range(1, 6)}, "items": [dict(r) for r in rows]}


# ---------------------------------------------------------------------------
# Tables board + analytics
# ---------------------------------------------------------------------------
def tables_overview(n_tables: int = 8) -> list[dict]:
    conn = _get_conn()
    out = []
    for t in range(1, n_tables + 1):
        s = conn.execute("SELECT * FROM sessions WHERE table_no = ? AND status = 'active' "
                         "ORDER BY session_id DESC LIMIT 1", (t,)).fetchone()
        row = {"table_no": t, "state": "free", "session_id": None, "orders": 0, "unpaid_total": 0.0,
               "bill_requested": False, "open_requests": [], "cart_items": 0}
        if s:
            sid = s["session_id"]
            orders = conn.execute("SELECT status, payment_status, grand_total FROM orders WHERE session_id = ? "
                                  "AND status != 'cancelled'", (sid,)).fetchall()
            statuses = {o["status"] for o in orders}
            if not orders:
                state = "ordering"
            elif statuses & {"received", "preparing"}:
                state = "waiting"
            elif "ready" in statuses:
                state = "ready"
            else:
                state = "served"
            reqs = [_request_dict(r) for r in conn.execute(
                "SELECT * FROM service_requests WHERE session_id = ? AND status = 'open' ORDER BY request_id", (sid,))]
            row.update({
                "state": state, "session_id": sid, "orders": len(orders),
                "unpaid_total": round(sum(o["grand_total"] for o in orders if o["payment_status"] == "unpaid"), 2),
                "bill_requested": any(r["kind"] == "bill" for r in reqs), "open_requests": reqs,
                "cart_items": conn.execute("SELECT COALESCE(SUM(quantity),0) FROM order_items WHERE session_id = ?",
                                           (sid,)).fetchone()[0],
                "since": s["created_at"],
            })
        out.append(row)
    conn.close()
    return out


def analytics(days: int = 14) -> dict:
    days = max(1, min(_to_int(days) or 14, 90))
    today = datetime.now().date()
    start = today - timedelta(days=days - 1)
    start_s, today_s = start.isoformat(), today.isoformat()
    conn = _get_conn()
    live = "o.status != 'cancelled'"

    by_day = {r["d"]: r for r in conn.execute(f"""
        SELECT substr(o.created_at,1,10) AS d, COUNT(*) AS orders, ROUND(SUM(o.grand_total),2) AS revenue
        FROM orders o WHERE {live} AND substr(o.created_at,1,10) >= ? GROUP BY d""", (start_s,))}
    revenue_by_day = []
    for i in range(days):
        d = (start + timedelta(days=i)).isoformat()
        r = by_day.get(d)
        revenue_by_day.append({"date": d, "orders": r["orders"] if r else 0, "revenue": r["revenue"] if r else 0.0})

    top = conn.execute(f"""
        SELECT l.name AS name, SUM(l.quantity) AS qty, ROUND(SUM(l.quantity * l.unit_price),2) AS revenue
        FROM order_lines l JOIN orders o ON o.order_id = l.order_id
        WHERE {live} AND substr(o.created_at,1,10) >= ? GROUP BY l.name ORDER BY qty DESC, name LIMIT 10""",
                       (start_s,)).fetchall()
    sold = {r["name"]: r["qty"] for r in conn.execute(f"""
        SELECT l.name AS name, SUM(l.quantity) AS qty FROM order_lines l JOIN orders o ON o.order_id = l.order_id
        WHERE {live} AND substr(o.created_at,1,10) >= ? GROUP BY l.name""", (start_s,))}
    slowest = sorted(({"name": r["name"], "qty": sold.get(r["name"], 0)} for r in
                      conn.execute("SELECT name FROM menu WHERE available = 1")), key=lambda x: (x["qty"], x["name"]))[:5]

    hours = {int(r["h"]): r["n"] for r in conn.execute(f"""
        SELECT substr(o.created_at,12,2) AS h, COUNT(*) AS n FROM orders o
        WHERE {live} AND substr(o.created_at,1,10) >= ? GROUP BY h""", (start_s,))}
    busiest = [{"hour": h, "orders": hours.get(h, 0)} for h in range(24)]

    pay = [dict(r) for r in conn.execute(f"""
        SELECT COALESCE(o.payment_method,'?') AS method, COUNT(*) AS orders, ROUND(SUM(o.grand_total),2) AS revenue
        FROM orders o WHERE {live} AND substr(o.created_at,1,10) >= ? GROUP BY method ORDER BY orders DESC""", (start_s,))]

    statuses = {r["status"]: r["n"] for r in conn.execute(
        "SELECT status, COUNT(*) AS n FROM orders WHERE substr(created_at,1,10) = ? GROUP BY status", (today_s,))}
    t = conn.execute(f"""
        SELECT COUNT(*) AS orders, COALESCE(ROUND(SUM(grand_total),2),0) AS revenue,
               COALESCE(ROUND(SUM(tip),2),0) AS tips,
               COALESCE(ROUND(SUM(CASE WHEN payment_status='paid' THEN grand_total ELSE 0 END),2),0) AS paid,
               COALESCE(ROUND(SUM(CASE WHEN payment_status='unpaid' THEN grand_total ELSE 0 END),2),0) AS unpaid
        FROM orders o WHERE {live} AND substr(created_at,1,10) = ?""", (today_s,)).fetchone()
    rating = conn.execute("SELECT COUNT(*) AS n, AVG(rating) AS avg FROM feedback").fetchone()
    period = conn.execute(f"""SELECT COUNT(*) AS orders, COALESCE(ROUND(SUM(grand_total),2),0) AS revenue,
                              COALESCE(ROUND(AVG(grand_total),2),0) AS avg_order
                              FROM orders o WHERE {live} AND substr(created_at,1,10) >= ?""", (start_s,)).fetchone()
    conn.close()
    return {
        "status": "ok", "days": days, "currency": CURRENCY,
        "today": {"orders": t["orders"], "revenue": t["revenue"], "tips": t["tips"], "paid": t["paid"],
                  "unpaid": t["unpaid"], "avg_order": round(t["revenue"] / t["orders"], 2) if t["orders"] else 0.0,
                  "cancelled": statuses.get("cancelled", 0), "by_status": statuses},
        "period": {"orders": period["orders"], "revenue": period["revenue"], "avg_order": period["avg_order"]},
        "revenue_by_day": revenue_by_day, "top_items": [dict(r) for r in top], "slowest_items": slowest,
        "busiest_hours": busiest, "payment_split": pay,
        "rating": {"count": rating["n"], "average": round(rating["avg"], 2) if rating["avg"] else None},
        "low_stock": low_stock_items(),
    }


# ---------------------------------------------------------------------------
# Chat log (for the admin AI-log viewer)
# ---------------------------------------------------------------------------
def log_chat_turn(client: str, session_id: Optional[int], table_no: Optional[int], user_text: str,
                  assistant_text: str, state_before: str, state_after: str, tool_calls: Any = None,
                  degraded: bool = False) -> None:
    import json
    conn = _get_conn()
    conn.execute("""INSERT INTO chat_log (ts, client, session_id, table_no, user_text, assistant_text, state_before,
                    state_after, tool_calls, degraded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                 (_now(), client, session_id, table_no, user_text, assistant_text, state_before, state_after,
                  json.dumps(tool_calls or [], ensure_ascii=False), 1 if degraded else 0))
    conn.execute("DELETE FROM chat_log WHERE log_id <= (SELECT MAX(log_id) FROM chat_log) - 5000")   # keep it bounded
    conn.commit()
    conn.close()


def list_chat_log(limit: int = 200, client: Optional[str] = None) -> list[dict]:
    import json
    conn = _get_conn()
    if client:
        rows = conn.execute("SELECT * FROM chat_log WHERE client = ? ORDER BY log_id DESC LIMIT ?", (client, limit)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM chat_log ORDER BY log_id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["tool_calls"] = json.loads(d["tool_calls"] or "[]")
        except ValueError:
            d["tool_calls"] = []
        out.append(d)
    return out


# ---------------------------------------------------------------------------
def snapshot(session_id: Optional[int]) -> dict:
    if not session_id:
        return {"session": None, "order": {}}
    s = get_session(session_id)
    if not s:
        return {"session": None, "order": {}}
    return {
        "session": {"session_id": s["session_id"], "table_no": s["table_no"], "status": s["status"],
                    "payment_method": s["payment_method"]},
        "order": view_current_order(session_id),
    }


# ---------------------------------------------------------------------------
# LLM tool definitions
# ---------------------------------------------------------------------------
def llm_get_menu(category: str = "all") -> dict:
    """Compact menu for the model (no descriptions, to save context)."""
    res = get_menu_by_category(category)
    return {"status": "ok", "menu": {
        cat: [{"name": i["name"], "price": i["price"], "available": i["available"],
               "vegetarian": i["vegetarian"], "allergens": i["allergens"]} for i in items]
        for cat, items in res["menu"].items()}}


TOOL_SPECS = [
    {"tool": "add_item_to_order", "description": "Add a dish from the menu to the table order.",
     "arguments": {"item_name": "Exact name of the menu item", "qty": "Quantity (default 1)",
                   "instructions": "Optional custom preparation instructions (e.g., 'no onions')"}},
    {"tool": "remove_item_from_order", "description": "Remove or reduce quantity of a dish from the order.",
     "arguments": {"item_name": "Exact name of the menu item", "qty": "Optional quantity to remove"}},
    {"tool": "check_item_allergen", "description": "Check whether a dish contains an allergen (gluten, dairy, egg, soy, nuts...).",
     "arguments": {"item_name": "Exact name of the menu item", "allergen": "The allergen to check"}},
    {"tool": "get_popular_items", "description": "Get the most popular dishes right now (for recommendations).",
     "arguments": {"limit": "How many dishes (default 3)"}},
    {"tool": "request_review", "description": "Show the itemized bill and review summary to the customer.",
     "arguments": {}},
]

LLM_TOOLS = {
    "add_item_to_order": add_item_to_order,
    "remove_item_from_order": remove_item_from_order,
    "get_menu_by_category": llm_get_menu,
    "check_item_allergen": check_item_allergen,
    "get_popular_items": get_popular_items,
    "request_review": lambda session_id: {"status": "ok"},
}