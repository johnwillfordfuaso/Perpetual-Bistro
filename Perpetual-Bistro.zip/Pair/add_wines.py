"""Adds 4 wines (Albarino, Merlot, Pinot Noir, Riesling) to the Perpetual Bistro menu (own category: Wines).
Run once from the project folder:
    python add_wines.py
Safe to run twice - dishes that already exist are skipped. Edit prices/stock later in Admin > Menu & stock.
Photos: images/albarino.jpg, images/merlot.jpg, images/pinot-noir.jpg, images/riesling.jpg"""
import sys
from pathlib import Path

import db_tools as db

DB_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "restaurant.db"

DISHES = [
    dict(name="Albarino", category="Wines", price=280, stock=24, vegetarian=True, allergens="sulfites",
         description="Crisp, chilled white wine with bright citrus and stone-fruit notes. Lovely with seafood. Per glass, 21+ only."),
    dict(name="Merlot", category="Wines", price=260, stock=24, vegetarian=True, allergens="sulfites",
         description="Smooth, medium-bodied red wine with soft plum and cherry flavours. Pairs well with pasta and steak. Per glass, 21+ only."),
    dict(name="Pinot Noir", category="Wines", price=300, stock=24, vegetarian=True, allergens="sulfites",
         description="Elegant, light-bodied reserve red with red berry and earthy notes. Great with chicken and mushrooms. Per glass, 21+ only."),
    dict(name="Riesling", category="Wines", price=250, stock=24, vegetarian=True, allergens="sulfites",
         description="Fresh, aromatic white wine with green apple and peach, off-dry and refreshing. Per glass, 21+ only."),
]

db.set_db_path(DB_FILE)
db.init_db()
existing = {m["name"].lower(): m for m in db.list_menu_items()}
for d in DISHES:
    old = existing.get(d["name"].lower())
    if old:   # already added earlier (maybe under Drinks) -> just move it to the Wines category
        if old.get("category") != "Wines":
            db.admin_update_menu_item(old["id"], category="Wines")
            print("moved to Wines: " + d["name"])
        else:
            print("skipped: " + d["name"] + " (already in Wines)")
        continue
    r = db.admin_add_menu_item(**d)
    print(("added:   " if r["status"] == "ok" else "skipped: ") + d["name"] + ("" if r["status"] == "ok" else f" ({r.get('error')})"))
print("Done. Refresh the page to see them.")