"""
fsm_agent.py - Finite State Machine controller for the Perpetual Bistro virtual waiter.

States
  STATE_GREETING      waiting for a table number
  STATE_TAKING_ORDER  chatting / building the cart (also used between rounds)
  STATE_REVIEW        itemised tab shown, waiting for yes + payment method
  STATE_CONFIRMED     transient: order sent to the kitchen, then back to TAKING_ORDER so the
                      customer can order another round or ask for the bill

Safety nets
  * AI-proposed items are *staged* and only added after the customer says "yes" (confirm_ai_orders)
  * If Ollama is unreachable a small rule-based parser still understands "2 cheeseburgers"
"""
from __future__ import annotations

import inspect
import json
import re
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any, Callable, Optional

import db_tools as db
import guardrails

STATE_GREETING = "STATE_GREETING"
STATE_TAKING_ORDER = "STATE_TAKING_ORDER"
STATE_REVIEW = "STATE_REVIEW"
STATE_CONFIRMED = "STATE_CONFIRMED"

MAX_TOOL_ROUNDS = 5
MAX_CALLS_PER_ROUND = 4
MAX_HISTORY = 60
MAX_LOG_TURNS = 300

WAITER_NAME = "Zeya"

WELCOME = f"Hi, welcome to Perpetual Bistro! I'm {WAITER_NAME}, your virtual waiter. Which table number are you seated at?"

# --- a handful of canned replies in English and Filipino -------------------------------------
_T = {
    "welcome": {"en": WELCOME,
                "fil": f"Maligayang pagdating sa Perpetual Bistro! Ako po si {WAITER_NAME}, ang virtual waiter ninyo. Anong table number po kayo?"},
    "didnt_catch": {"en": "Sorry, I didn't catch that. Which table number are you seated at (for example, 'Table 4')?",
                    "fil": "Pasensya na po, hindi ko nakuha. Anong table number po kayo (halimbawa, 'Table 4')?"},
    "table_ok": {"en": "Lovely, Table {t} is all set! I'm " + WAITER_NAME + " and I'll be looking after you. What can I get for you? You can ask about the menu (type /menu to see everything).",
                 "fil": "Sige po, Table {t} na kayo! Ako po si " + WAITER_NAME + " at ako ang bahala sa inyo. Ano pong order ninyo? I-type ang /menu para makita ang buong menu."},
    "tab_empty": {"en": "Your tab is empty so far - what would you like to order?",
                  "fil": "Wala pa pong laman ang tab ninyo - ano pong gusto ninyong i-order?"},
    "cleared": {"en": "No problem - I've cleared your tab. What would you like instead?",
                "fil": "Sige po, nabura ko na ang tab ninyo. Ano pong gusto ninyo?"},
    "ask_confirm": {"en": "Did you mean: {items}? Say 'yes' to add, or 'no' to cancel.",
                    "fil": "Ang ibig ninyo po bang sabihin: {items}? Sabihin ang 'yes' para idagdag, o 'no' para kanselahin."},
    "added": {"en": "Added to your tab: {items}. Anything else?",
              "fil": "Naidagdag na po: {items}. May iba pa po ba?"},
    "discarded": {"en": "No problem, I haven't added anything. What would you like?",
                  "fil": "Sige po, wala akong idinagdag. Ano pong gusto ninyo?"},
    "pay_ask": {"en": "Almost done! How would you like to pay? We accept {methods}.",
                "fil": "Halos tapos na po! Paano po kayo magbabayad? Tinatanggap namin ang {methods}."},
    "bill_ok": {"en": "Done - I've let the team know. Someone will bring your bill shortly. Thank you for dining with us. I'm " + WAITER_NAME + " if you'd like to share any feedback!",
                "fil": "Naipaalam ko na po sa staff - dadalhin nila ang bill ninyo. Salamat po sa pagkain sa amin! Si " + WAITER_NAME + " po ito kung may feedback kayo."},
    "server_ok": {"en": "Done - I've called a member of staff to your table.",
                  "fil": "Tinawag ko na po ang staff - papunta na sila sa table ninyo."},
    "more": {"en": "Anything else? You can keep ordering, or just say 'bill' when you're ready.",
             "fil": "May iba pa po ba? Mag-order lang po ulit, o sabihin ang 'bill' kapag handa na kayo."},
    "all_set": {"en": "You're all set - your order is with the kitchen. Say 'bill' when you'd like to settle up, or order more any time.",
                "fil": "Okay na po - nasa kusina na ang order ninyo. Sabihin ang 'bill' kapag magbabayad na kayo, o mag-order ulit."},
    "offline": {"en": "My AI assistant is offline right now, but the menu buttons still work. You can also type something like '2 cheeseburgers'.",
                "fil": "Naka-offline po ang AI assistant ko ngayon, pero gumagana pa rin ang menu buttons. Pwede rin pong mag-type ng '2 cheeseburgers'."},
    "offline_guess": {"en": "My AI assistant is offline, but I think you'd like: {items}. Say 'yes' to add, or 'no' to cancel.",
                      "fil": "Naka-offline po ang AI assistant ko, pero parang ito po ang gusto ninyo: {items}. Sabihin ang 'yes' para idagdag, o 'no' para kanselahin."},
    "ask_table": {"en": "Which table number are you seated at (for example, 'Table 4')?",
                  "fil": "Anong table number po kayo (halimbawa, 'Table 4')?"},
    "order_locked": {"en": "Sorry, {what} already with the kitchen (order #{oid}, {status}), so I can't change or cancel it from here. "
                           "I've asked a member of staff to come to your table and help. Anything new you order now will go in as a separate order.",
                     "fil": "Pasensya na po, nasa kusina na ang order #{oid} ({status}) kaya hindi ko na po ito mababago o makakansela. "
                            "Tinawag ko na po ang staff para tumulong. Ang anumang bagong order ay hiwalay na order."},
    "order_already_cancelled": {"en": "Order #{oid} has already been cancelled by our staff, so there is nothing more to cancel. Would you like to order something else?",
                                "fil": "Nakansela na po ng staff ang order #{oid}, kaya wala na pong ika-cancel. Gusto po ba ninyong mag-order ng iba?"},
    "unknown_dish": {"en": "Sorry, I couldn't find that on our menu, so I haven't added anything. Try a dish name like 'one cheeseburger', or type /menu to see everything.",
                     "fil": "Pasensya na po, wala po iyon sa menu namin kaya wala akong idinagdag. Subukan po ang pangalan ng ulam tulad ng 'one cheeseburger', o i-type ang /menu."},
    "unclear": {"en": "Sorry, I didn't quite catch that. You can say things like 'one cheeseburger', 'what's good here?', or 'review my order'.",
                "fil": "Pasensya na po, hindi ko masyadong narinig. Pwede po ninyong sabihin ang 'one cheeseburger', 'ano po ang masarap?', o 'review my order'."},
    "closed": {"en": "Your table session was closed by our staff. ",
               "fil": "Isinara na po ng staff ang table session ninyo. "},
}


def tr(key: str, lang: str = "en", **kw: Any) -> str:
    entry = _T[key]
    return entry.get(lang, entry["en"]).format(**kw)


class LLMError(RuntimeError):
    """Raised when the language model cannot be reached or answers badly."""


class OllamaClient:
    def __init__(self, model: str = "qwen2.5:1.5b", host: str = "http://localhost:11434",
                 temperature: float = 0.1, timeout: int = 45):
        # "localhost" makes Windows try IPv6 (::1) first and wait ~2 s before falling back to IPv4, where Ollama listens
        self.model, self.host, self.temperature, self.timeout = model, host.rstrip("/").replace("//localhost", "//127.0.0.1"), temperature, timeout
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))    # never send local traffic through a system proxy

    def warm_up(self) -> bool:
        """Load the model into memory now, so the first customer doesn't wait 20+ seconds for it."""
        payload = json.dumps({"model": self.model, "messages": [{"role": "user", "content": "hi"}], "stream": False,
                              "keep_alive": "30m", "options": {"num_predict": 1, "num_ctx": 4096}}).encode()
        req = urllib.request.Request(f"{self.host}/api/chat", data=payload, headers={"Content-Type": "application/json"})
        try:
            with self._opener.open(req, timeout=120):
                return True
        except (urllib.error.URLError, TimeoutError, OSError):
            return False

    def __call__(self, messages: list[dict]) -> str:
        payload = json.dumps({
            "model": self.model,
            "messages": messages,
            "stream": False,
            "keep_alive": "30m",                       # stay loaded: the first call after idle is slow
            "options": {
                "temperature": self.temperature,
                "num_predict": 120,                    # replies are 1-2 sentences; tool calls are tiny
                "num_ctx": 4096,
            },
        }).encode()
        req = urllib.request.Request(f"{self.host}/api/chat", data=payload,
                                     headers={"Content-Type": "application/json"})
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read())
            return data["message"]["content"]
        except (urllib.error.URLError, TimeoutError, KeyError, json.JSONDecodeError, OSError) as exc:
            raise LLMError(f"Ollama request failed: {exc}") from exc


def parse_tool_calls(raw: str) -> list[dict]:
    calls, decoder, i = [], json.JSONDecoder(), 0
    while True:
        i = raw.find("{", i)
        if i == -1:
            break
        try:
            obj, end = decoder.raw_decode(raw, i)
        except json.JSONDecodeError:
            i += 1
            continue
        name = obj.get("tool") or obj.get("name") if isinstance(obj, dict) else None
        if isinstance(name, str):
            args = obj.get("arguments", obj.get("parameters", {}))
            calls.append({"tool": name, "arguments": args if isinstance(args, dict) else {}})
            i = end
        else:
            i += 1
    return calls[:MAX_CALLS_PER_ROUND]


# ---------------------------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------------------------
def money(x: float) -> str:
    return f"{x:,.2f}"


def format_tab(view: dict) -> str:
    if view.get("is_empty"):
        return "(Your tab is empty.)"
    rows = []
    for l in view["items"]:
        label = l["name"] + (f" ({l['instructions']})" if l["instructions"] else "")
        rows.append(f"  {l['quantity']}x {label:<46} {money(l['line_total']):>9}")
    rule = "  " + "-" * 60
    return "\n".join(
        rows + [
            rule,
            f"  {'Subtotal:':<50} {money(view['subtotal']):>9}",
            *([f"  {view['discount_label'] + ' discount (' + str(int(round(view['discount_rate'] * 100))) + '%):':<50} {'-' + money(view['discount_amount']):>9}"] if view.get("discount_amount") else []),
            f"  {'Service fee (' + str(int(round(view['service_fee_rate'] * 100))) + '%):':<50} {money(view['service_fee']):>9}",
            f"  {'TOTAL (' + view['currency'] + '):':<50} {money(view['grand_total']):>9}",
        ]
    )


def format_menu(result: dict) -> str:
    out = []
    for cat, items in result["menu"].items():
        out.append(cat.upper())
        for it in items:
            tags = []
            if it["vegetarian"]:
                tags.append("veg")
            if not it["available"]:
                tags.append("SOLD OUT")
            elif it.get("low_stock"):
                tags.append(f"only {it['stock']} left")
            if it.get("allergens"):
                tags.append("contains " + "/".join(it["allergens"]))
            tag = f"  [{', '.join(tags)}]" if tags else ""
            out.append(f"  {it['name']:<22} {money(it['price']):>8}{tag}")
    return "\n".join(out)


def format_receipt(r: dict) -> str:
    cur = r.get("currency", db.CURRENCY)
    rows = []
    for l in r["items"]:
        label = l["name"] + (f" ({l['instructions']})" if l["instructions"] else "")
        rows.append(f"  {l['quantity']}x {label:<46} {money(l['line_total']):>9}")
    lines = [
        "=" * 64,
        "  PERPETUAL BISTRO - OFFICIAL RECEIPT",
        f"  Order #{r.get('order_id', '-')} (round {r.get('round_no', 1)})   Table {r['table_no']}   {r['confirmed_at']}",
        "=" * 64,
        *rows,
        "  " + "-" * 60,
        f"  {'Subtotal:':<50} {money(r['subtotal']):>9}",
        *([f"  {r['discount_label'] + ' discount (' + str(int(round(r['discount_rate'] * 100))) + '%):':<50} {'-' + money(r['discount_amount']):>9}"] if r.get("discount_amount") else []),
        f"  {'Service fee (' + str(int(round(r.get('service_fee_rate', db.SERVICE_FEE_RATE) * 100))) + '%):':<50} {money(r['service_fee']):>9}",
    ]
    if r.get("tip"):
        lines.append(f"  {'Tip:':<50} {money(r['tip']):>9}")
    lines.append(f"  {'TOTAL (' + cur + '):':<50} {money(r['grand_total']):>9}")
    if r.get("split_count", 1) > 1:
        lines.append(f"  Split {r['split_count']} ways: {cur} {money(r['per_person'])} each")
    status = {"paid": "PAID", "unpaid": "PAY AT COUNTER"}.get(r.get("payment_status", ""), "")
    lines += [
        "-" * 64,
        f"  Payment method: {r.get('payment_method', '-')}" + (f"  [{status}]" if status else ""),
        f"  {r.get('payment_note', '')}",
        "=" * 64,
        "  Your order has been sent to the kitchen. Thank you!",
        "=" * 64,
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------------------------
# Language helpers
# ---------------------------------------------------------------------------------------------
# Words that (almost) never appear in plain English, so one hit is enough to say "this guest is writing Tagalog".
_FIL_WORDS = set("""po opo ho oho ako ko mo ka kami kayo tayo siya sila namin ninyo natin iyo iyon iyan ito ayoko ayaw gusto
gustong nais kumain kain inom uminom ulam pagkain masarap magkano presyo bayad magbayad singil kuha kunin pakuha paki pakiusap
pwede puwede maaari sige salamat walang wala mayroon meron hindi huwag wag oo ano anong ang ng mga sa nang naman lang nga pala
dalawa tatlo apat isa lima anim pito walo siyam sampu mesa dagdag idagdag alisin tanggalin tama mali kulang sobra malamig mainit
tubig kanin sabaw maanghang matamis maalat po? paano bakit saan kailan sino alin""".replace("?", "").split())
_FIL_RE = re.compile(r"[a-zñ']+", re.I)


def detect_language(text: str, current: str = "en") -> str:
    """'fil' when the guest writes Tagalog/Taglish, 'en' when they write plain English, otherwise keep `current`
    (short replies such as 'yes' or 'Table 4' don't flip the language)."""
    words = _FIL_RE.findall((text or "").lower())
    if any(w in _FIL_WORDS for w in words):
        return "fil"
    return "en" if len(words) >= 3 else current


_WORD_NUMBERS = {w: i for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve".split())}
# Tagalog numbers too ("dalawang cheeseburger", "table tatlo"); the -ng forms are how they sound before a noun
for _w, _n in {"isa": 1, "isang": 1, "dalawa": 2, "dalawang": 2, "tatlo": 3, "tatlong": 3, "apat": 4, "apat na": 4,
               "lima": 5, "limang": 5, "anim": 6, "pito": 7, "walo": 8, "siyam": 9, "sampu": 10, "sampung": 10}.items():
    if " " not in _w:
        _WORD_NUMBERS[_w] = _n
_STOP = set("hi hello hey i im i'm we're were at on in the a an is it's its sitting seated table number no "
            "please thanks thank you good morning afternoon evening our my".split())

DONE_RE = re.compile(
    r"\b(that'?s (all|it)|i'?m (done|finished)|we'?re (done|finished)|that will be (all|it)|"
    r"(the |my )?(bill|check)\b|check ?out|ready to (pay|confirm)|nothing (more|else)|"
    r"yun lang|iyon lang|tapos na|ayun lang)", re.I)
YES_RE = re.compile(
    r"^\s*(yes|yeah|yep|yup|ok(ay)?|sure|confirm(ed)?|correct|proceed|go ahead|looks good|oo|opo|sige|"
    r"that'?s (right|correct)|send( it)?( to (the )?kitchen)?)\s*[.!]*\s*$", re.I)
NO_RE = re.compile(r"^\s*(no|nope|nah|wait|not yet|hindi|huwag|wag)\s*[.!]*\s*$", re.I)
CLEAR_RE = re.compile(
    r"^\s*(cancel( (the|my))? (whole |entire )?order|cancel everything|start over|"
    r"clear (the |my )?(cart|order|tab))\b", re.I)
REVIEW_RE = re.compile(
    r"^\s*(please\s+)?(review|show|see|view|check)\b.{0,15}\b(order|tab|cart)\b|\bwhat'?s in (my|the) (order|tab|cart)\b", re.I)
# the model says it added / ordered something (we verify that against a real tool call)
CLAIM_RE = re.compile(
    r"\b(i'?ll|i will|i have|i've|let me)\s+(add|put|place)\b|\b(added|adding)\b|\byou('ve| have)?\s+ordered\b|\bto your (order|tab)\b", re.I)
# a canned refusal from the model
REFUSAL_RE = re.compile(r"(can'?t|cannot|unable to|not able to)\s+(assist|help)|i'?m sorry, but i can'?t", re.I)
BILL_RE = re.compile(r"\b(bill|check|cheque|singil)\b", re.I)
SERVER_RE = re.compile(
    r"\b(call|get|need|want|bring|ask|page|tawag)\b.{0,25}\b(waiter|server|staff|someone|manager)\b|"
    r"\b(waiter|server)\b\s*,?\s*(please|po)\b", re.I)
PAY_HINT_RE = re.compile(r"\b(pay|paying|payment|via|through|using)\b", re.I)


def extract_table_number(text: str) -> tuple[Optional[int], bool]:
    low = text.lower()
    m = re.search(r"\btable\s*(?:no\.?|number|#)?\s*(\d{1,2}|[a-z]+)\b", low)
    token = m.group(1) if m else None
    explicit_table = token is not None
    if token is None:
        words = re.findall(r"[\w']+", low)
        if len(words) <= 4:
            token = next((w for w in words if w.isdigit() or w in _WORD_NUMBERS), None)
    if token is None:
        return None, False
    number = int(token) if token.isdigit() else _WORD_NUMBERS.get(token)
    if number is None:
        return None, False
    leftover = [w for w in re.findall(r"[a-z']+", low) if w not in _STOP and w not in _WORD_NUMBERS]
    if not explicit_table and len(leftover) >= 2:      # "Darby's one cheeseburger" is a misheard order, not a table
        return None, False
    return number, len(leftover) >= 3


_QTY_PREFIX = r"(?:(\d{1,2})\s*x?\s*|(" + "|".join(w for w in _WORD_NUMBERS if w != "zero") + r")\s+|(?:a|an)\s+)?(?:orders?\s+of\s+)?"
_INSTR_RE = re.compile(r"\b((?:no|without|extra|walang|dagdag)\s+[^.;!?]+)", re.I)


_ORDER_FILLER = set("""i i'd i'll id ill we we'd we'll want wants wanna would like to order add get me my please pls and a an the of
some one more also then plus just can could may might have give po ng at gusto gustong ko namin kami paki pakidagdag dagdag
idagdag pahingi pabili naman lang din x pc pcs piece pieces serving servings plate plates glass glasses bowl bowls cup cups
order orders thanks thank you""".split())


def is_plain_order(text: str, guesses: list[dict]) -> bool:
    """True when the message is ONLY dish names, quantities and polite filler ("two cheeseburgers and a cola please"),
    so the rule-based parser reads it exactly and the language model doesn't have to."""
    if not guesses or "?" in text:
        return False
    known = set()
    for g in guesses:
        known.update(re.findall(r"[a-z']+", g["name"].lower()))
    for tok in re.findall(r"[a-z']+|\d+", text.lower().replace("&", " and ")):
        if tok.isdigit() or tok in _ORDER_FILLER or tok in _WORD_NUMBERS:
            continue
        if any(tok == k or tok == k + "s" or tok == k + "es" or (len(tok) > 3 and tok.rstrip("s") == k.rstrip("s")) for k in known):
            continue
        return False
    return True


def parse_simple_order(text: str, menu_names: list[str]) -> list[dict]:
    """Tiny rule-based order reader used only when the AI model is offline.
    '2 cheeseburgers without onions' -> [{'name': 'Cheeseburger', 'qty': 2, 'instructions': 'without onions'}]"""
    low = " " + text.lower().replace("&", " and ") + " "
    found: list[dict] = []
    for name in sorted(menu_names, key=len, reverse=True):
        body = r"[-\s]?".join(re.escape(p) for p in re.split(r"[-\s]+", name.lower()))
        pat = re.compile(r"(?<![a-z])" + _QTY_PREFIX + body + r"(?:s|es)?(?![a-z])")
        m = pat.search(low)
        if not m:
            continue
        qty = int(m.group(1)) if m.group(1) else _WORD_NUMBERS.get(m.group(2) or "", 1)
        found.append({"name": name, "qty": max(1, min(qty, db.MAX_QTY_PER_LINE)), "instructions": "", "_at": m.start()})
        low = low[:m.start()] + " " * (m.end() - m.start()) + low[m.end():]      # don't match the same words twice
    found.sort(key=lambda f: f["_at"])
    ins = _INSTR_RE.search(text)
    if ins and len(found) == 1:
        found[0]["instructions"] = ins.group(1).strip().rstrip(",")[:120]
    for f in found:
        f.pop("_at", None)
    return found


# ---------------------------------------------------------------------------------------------
class FSMAgent:
    def __init__(self, llm_chat: Callable[[list[dict]], str], llm_label: str = "qwen2.5:1.5b",
                 confirm_ai_orders: bool = True, notify: Optional[Callable[[str, dict], None]] = None,
                 client_id: str = ""):
        self.llm_chat = llm_chat
        self.llm_label = llm_label
        self.confirm_ai_orders = confirm_ai_orders
        self.notify: Callable[[str, dict], None] = notify or (lambda kind, payload: None)
        self.client_id = client_id
        self.language = "en"
        self.state = STATE_GREETING
        self.session_id: Optional[int] = None
        self.table_no: Optional[int] = None
        self.messages: list[dict] = []
        self.log: dict[str, Any] = {
            "meta": {"llm": llm_label, "client": client_id, "started_at": datetime.now().isoformat(timespec="seconds"),
                     "service_fee_rate": db.SERVICE_FEE_RATE, "currency": db.CURRENCY},
            "turns": [],
        }
        self._turn: dict[str, Any] = {"tool_calls": [], "transitions": []}
        self._review_requested = False
        self.payment_method: Optional[str] = None
        self.awaiting_payment = False
        self.pending_adds: list[dict] = []       # AI-proposed items waiting for the customer's yes/no
        self.order_ids: list[int] = []           # orders sent to the kitchen in this visit
        self.last_confirm: Optional[dict] = None
        self.last_offline = False                # True if the last reply came from the rule-based fallback
        self._last_user_text = ""

    # ---- small helpers ----------------------------------------------------------------------
    def _t(self, key: str, **kw: Any) -> str:
        return tr(key, self.language, **kw)

    def set_language(self, lang: str) -> None:
        self.language = "fil" if str(lang).lower().startswith(("fil", "tl")) else "en"
        if self.messages:
            self.messages[0] = {"role": "system", "content": self._system_prompt()}

    def start(self) -> str:
        return self._t("welcome")

    def _emit(self, kind: str, payload: dict) -> None:
        try:
            self.notify(kind, payload)
        except Exception:      # a broken listener must never break ordering
            pass

    # ---- main entry -------------------------------------------------------------------------
    def handle(self, text: str) -> str:
        text = (text or "").strip()
        if not text:
            return "I'm here whenever you're ready."
        before = self.state
        if not text.startswith("/"):                              # English by default; Tagalog when the guest uses it
            lang = detect_language(text, self.language)
            if lang != self.language:
                self.set_language(lang)
        self._turn = {"tool_calls": [], "transitions": []}
        self.last_offline = False
        prefix = ""
        try:
            if self.session_id is not None and not db.session_is_active(self.session_id):
                prefix = self._t("closed")                       # staff closed the table
                self._reset_for_next_customer()
            if text.startswith("/"):
                reply = self._command(text)
            elif self.state == STATE_GREETING:
                reply = self._greeting(text)
            elif self.state == STATE_TAKING_ORDER:
                reply = self._taking_order(text)
            else:
                reply = self._review(text)
        except LLMError:
            reply = self._t("offline")
        except Exception:
            reply = "Sorry, something went wrong on my side. Your tab is unchanged - please try again."
        reply = prefix + reply if prefix and self.state == STATE_GREETING and not reply.startswith(prefix) else reply
        self._record(text, before, reply)
        return reply

    def save_log(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.log, fh, indent=2, ensure_ascii=False)

    def shutdown(self) -> None:
        if self.session_id is not None:
            db.cancel_session(self.session_id)
            self.session_id = None

    def reset(self) -> None:
        """New customer: end the current session and forget everything about it."""
        self.shutdown()
        self.state = STATE_GREETING
        self.table_no = None
        self.messages = []
        self.payment_method, self.awaiting_payment = None, False
        self.pending_adds, self.order_ids = [], []

    def _set_state(self, new: str, reason: str) -> None:
        self._turn["transitions"].append({"from": self.state, "to": new, "reason": reason})
        self.state = new

    def _record(self, user_text: str, before: str, reply: str) -> None:
        sid = self.session_id if self.session_id else self._last_session()
        self.log["turns"].append({
            "turn": len(self.log["turns"]) + 1,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "user": user_text,
            "state_before": before,
            "tool_calls": self._turn["tool_calls"],
            "state_transitions": self._turn["transitions"],
            "state_after": self.state,
            "assistant": reply,
            "db_state": db.snapshot(sid),
        })
        if len(self.log["turns"]) > MAX_LOG_TURNS:
            del self.log["turns"][0]

    def _last_session(self) -> Optional[int]:
        for t in reversed(self.log["turns"]):
            sid = (t["db_state"].get("session") or {}).get("session_id")
            if sid:
                return sid
        return None

    # ---- prompt -----------------------------------------------------------------------------
    def _menu_for_prompt(self) -> str:
        lines = []
        for cat, items in db.get_menu_by_category("all")["menu"].items():
            parts = []
            for i in items:
                tag = ""
                if not i["available"]:
                    tag = " SOLD OUT"
                else:
                    if i["low_stock"]:
                        tag += f" only {i['stock']} left"
                    if i["vegetarian"]:
                        tag += " veg"
                    if i["allergens"]:
                        tag += " contains:" + "/".join(i["allergens"])
                parts.append(f"{i['name']} {i['price']:g}{tag}")
            lines.append(f"{cat}: " + "; ".join(parts))
        return "\n".join(lines)

    def _system_prompt(self) -> str:
        specs = json.dumps(db.TOOL_SPECS, separators=(",", ":"))
        popular = ", ".join(i["name"] for i in db.get_popular_items(3)["items"])
        lang = ("The guest is writing in Filipino/Tagalog: reply in Tagalog (Taglish is fine), politely, using 'po'. Keep dish names in English."
                if self.language == "fil" else
                "Reply in English. If the guest writes in Tagalog or Taglish, reply in Tagalog (Taglish is fine) using 'po'.")
        return f"""You are {WAITER_NAME}, the virtual waiter at Perpetual Bistro, serving Table {self.table_no}.
If a guest asks your name or who is serving them, say you are {WAITER_NAME}. If they have feedback or a complaint, thank them and say the manager will see it.
Prices are in {db.CURRENCY}. Be concise (1-2 sentences). {lang}

MENU (name price notes):
{self._menu_for_prompt()}
Popular right now: {popular}.

RULES:
- Only offer dishes from the MENU above. Never invent dishes or prices.
- If a dish is SOLD OUT, say so and suggest a similar dish from the same category.
- For allergen questions use the 'contains' notes or the check_item_allergen tool; if unsure, say so and suggest asking staff.
- When the customer orders a main dish and has no drink yet, offer one drink or side - once, never pushy.
- If asked for a recommendation, suggest the popular dishes.
- We have a separate 'Wines' category (per glass, 21 and above only). If the customer wants wine, ask if they prefer red or white, sweet or dry, or what they are eating, then suggest one or two wines from the MENU.

{guardrails.SCOPE_RULES}

CRITICAL INSTRUCTIONS:
To execute actions (like adding items to the order), you MUST output ONLY a valid JSON object matching this format:
{{"tool": "<tool_name>", "arguments": {{...}}}}
Do NOT write "TOOL_RESULT" in your text response. Only output JSON when executing a tool call.

AVAILABLE TOOLS:
{specs}"""

    def _refresh_prompt(self) -> None:
        if self.messages and self.messages[0].get("role") == "system":
            self.messages[0] = {"role": "system", "content": self._system_prompt()}   # live stock / popularity

    # ---- sessions ---------------------------------------------------------------------------
    def _new_session(self, table_no: int) -> dict:
        res = db.create_table_session(table_no)
        if res["status"] == "ok":
            self.session_id, self.table_no = res["session_id"], res["table_no"]
            self.payment_method, self.awaiting_payment = None, False
            self.pending_adds, self.order_ids = [], []
            self.messages = [{"role": "system", "content": self._system_prompt()}]
        return res

    def _reset_for_next_customer(self) -> None:
        self.session_id = self.table_no = None
        self.messages = []
        self.payment_method, self.awaiting_payment = None, False
        self.pending_adds, self.order_ids = [], []
        self._set_state(STATE_GREETING, "session reset for next customer")

    def _greeting(self, text: str) -> str:
        table, extra = extract_table_number(text)
        if table is None:
            cat = guardrails.classify_off_topic(text)
            if cat:
                self._log_guardrail("off_topic", {"category": cat, "text": text[:120]})
                return guardrails.redirect_reply(cat, self.language) + " " + self._t("ask_table")
            return self._t("didnt_catch")
        res = self._new_session(table)
        if res["status"] != "ok":
            return f"{res['message']} Could you tell me your table number again?"
        self._set_state(STATE_TAKING_ORDER, f"table {table} captured, session {self.session_id} opened")
        if extra:
            return self._taking_order(text)
        return self._t("table_ok", t=table)

    # ---- taking the order -------------------------------------------------------------------
    def _taking_order(self, text: str) -> str:
        short = len(text.split()) <= 8
        if self.pending_adds:
            if YES_RE.match(text):
                return self._apply_pending()
            if NO_RE.match(text) or CLEAR_RE.match(text):
                self.pending_adds = []
                return self._t("discarded")
            if short and DONE_RE.search(text) and not BILL_RE.search(text):
                added = self._apply_pending()                       # "that's all" = yes to what I just proposed
                view = db.view_current_order(self.session_id)
                return added if view["is_empty"] else f"{added}\n\n{self._enter_review('customer finished ordering')}"
            self.pending_adds = []                                  # they said something else: drop the proposal

        blocked = self._guard(text)
        if blocked:
            return blocked

        if CLEAR_RE.match(text):
            return self._clear()

        method = db.find_payment_method(text)
        if method and short and PAY_HINT_RE.search(text):
            self.payment_method = method
            return f"Noted, you'll pay with {method}. Say 'that's all' when you're ready."

        if short and SERVER_RE.search(text):
            return self._service_request("server")

        view = db.view_current_order(self.session_id)
        if short and view["is_empty"] and self.order_ids and BILL_RE.search(text):
            return self._service_request("bill")
        if short and YES_RE.match(text) and view["is_empty"]:
            return self._t("tab_empty")                       # nothing proposed, nothing to confirm: never let the model invent an answer
        if short and DONE_RE.search(text):
            if view["is_empty"]:
                return self._t("all_set") if self.order_ids else self._t("tab_empty")
            return self._enter_review("customer finished ordering")
        if short and REVIEW_RE.search(text):
            if view["is_empty"]:
                return self._t("tab_empty")
            return self._enter_review("customer asked to review the order")

        fast = self._fast_order(text)                    # "two cheeseburgers and a cola": no need to wait for the model
        if fast is not None:
            return fast

        self._last_user_text = text
        self._refresh_prompt()
        self.messages.append({"role": "user", "content": text})
        try:
            return self._run_llm()
        except LLMError:
            return self._offline_reply(text)

    def _fast_order(self, text: str) -> Optional[str]:
        guesses = parse_simple_order(text, self._menu_names())
        if not is_plain_order(text, guesses):
            return None
        notes, staged_any = [], False
        for g in guesses:
            res = self._stage_add(g["name"], g["qty"], g["instructions"])
            self._turn["tool_calls"].append({"tool": "fast_parse", "arguments": g, "result": res})
            if res["status"] == "ok":
                staged_any = True
            else:
                notes.append(res["message"])
        if not staged_any:
            return " ".join(notes) if notes else None
        reply = self._apply_pending() if not self.confirm_ai_orders else self._t("ask_confirm", items=self._pending_label())
        reply += (" " + " ".join(notes)) if notes else ""
        self.messages += [{"role": "user", "content": text}, {"role": "assistant", "content": reply}]
        self._trim_history()
        return reply

    def _service_request(self, kind: str) -> str:
        res = db.create_service_request(self.session_id, kind)
        self._turn["tool_calls"].append({"tool": "create_service_request", "arguments": {"kind": kind}, "result": res})
        if res["status"] != "ok":
            return res["message"]
        if not res.get("duplicate"):
            self._emit("request_new", {"request_id": res["request"]["request_id"], "kind": kind,
                                       "table_no": self.table_no})
        return self._t("bill_ok" if kind == "bill" else "server_ok")

    # ---- guardrails (see guardrails.py) -----------------------------------------------------
    def _menu_names(self) -> list[str]:
        return [i["name"] for items in db.get_menu_by_category("all")["menu"].values() for i in items]

    def _log_guardrail(self, kind: str, details: dict, result: Optional[dict] = None) -> None:
        self._turn["tool_calls"].append({"tool": "guardrail", "arguments": {"type": kind, **details},
                                         "result": result or {"status": "blocked"}})

    def _guard(self, text: str) -> Optional[str]:
        """Deterministic checks that run BEFORE the model. If one fires, its reply is returned and the
        model is never called, so a small model cannot be talked into breaking the rules."""
        cat = guardrails.classify_off_topic(text, self._menu_names())
        if cat:
            self._log_guardrail("off_topic", {"category": cat, "text": text[:120]})
            return guardrails.redirect_reply(cat, self.language)
        if self.session_id is not None and self.order_ids:
            return self._sent_order_lock(text)
        return None

    def _sent_order_lock(self, text: str) -> Optional[str]:
        """Orders already sent to the kitchen (the CONFIRMED state) can't be edited or cancelled by
        the customer or the model. We say so politely and hand the request to staff instead."""
        orders = db.session_orders(self.session_id)
        view = db.view_current_order(self.session_id)
        cart = [i["name"] for i in view.get("items", [])] if view.get("status") == "ok" else []
        sent = [it["name"] for o in orders for it in o["items"]]
        intent = guardrails.sent_order_edit_intent(text, sent, cart, self._menu_names(), bool(orders))
        if not intent:
            return None
        if intent["scope"] == "items":
            wanted = {n.lower() for n in intent["items"]}
            hits = [o for o in reversed(orders) if any(it["name"].lower() in wanted for it in o["items"])]
        else:
            hits = list(reversed(orders))
        target = hits[0] if hits else orders[-1]
        oid = target["order_id"]
        if target["status"] == "cancelled":
            self._log_guardrail("sent_order_locked", {"order_id": oid, "scope": intent["scope"]}, {"status": "already_cancelled"})
            return self._t("order_already_cancelled", oid=oid)
        res = db.create_service_request(self.session_id, "cancel_order", f"order #{oid}: \"{text.strip()[:140]}\"")
        if res.get("status") == "ok" and not res.get("duplicate"):
            self._emit("request_new", {"request_id": res["request"]["request_id"], "kind": "cancel_order",
                                       "table_no": self.table_no})
        self._log_guardrail("sent_order_locked", {"order_id": oid, "order_status": target["status"], "scope": intent["scope"],
                                                  "items": intent["items"], "text": text[:120]},
                            {"status": "blocked", "staff_request": res.get("status")})
        names = intent["items"]
        what = ("the " + " and ".join(names) + (" is" if len(names) == 1 else " are")) if names else "your order is"
        return self._t("order_locked", what=what, oid=oid, status=target["status"])

    # ---- AI proposals that wait for yes / no ------------------------------------------------
    def _stage_add(self, name: str, qty: Any, instructions: str = "") -> dict:
        pending_same = sum(p["qty"] for p in self.pending_adds if p["name"].lower() == str(name).strip().lower())
        info = db.check_can_add(self.session_id, name, qty, already_pending=pending_same)
        if info["status"] != "ok":
            return info
        ins = str(instructions or "").strip()[:200]
        for p in self.pending_adds:
            if p["name"] == info["name"] and p["instructions"] == ins:
                p["qty"] += info["quantity"]
                break
        else:
            self.pending_adds.append({"name": info["name"], "qty": info["quantity"], "instructions": ins,
                                      "unit_price": info["price"]})
        return {"status": "ok", "staged": True, "item": info["name"], "quantity": info["quantity"],
                "note": "Waiting for the customer to confirm. Do not say it was added yet."}

    def _pending_label(self) -> str:
        return ", ".join(f"{p['qty']}x {p['name']}" + (f" ({p['instructions']})" if p["instructions"] else "")
                         for p in self.pending_adds)

    def _apply_pending(self) -> str:
        done, failed = [], []
        for p in self.pending_adds:
            res = db.add_item_to_order(self.session_id, p["name"], p["qty"], p["instructions"])
            self._turn["tool_calls"].append({"tool": "add_item_to_order", "arguments": {
                "item_name": p["name"], "qty": p["qty"], "instructions": p["instructions"], "confirmed_by_customer": True},
                "result": res})
            (done if res["status"] == "ok" else failed).append((p, res))
        self.pending_adds = []
        if done:
            label = ", ".join(f"{p['qty']}x {p['name']}" + (f" ({p['instructions']})" if p["instructions"] else "")
                              for p, _ in done)
            self.messages.append({"role": "user", "content": f"SYSTEM: the customer confirmed and these were added: {label}"})
        reply = self._t("added", items=label) if done else ""
        for p, res in failed:
            reply += (" " if reply else "") + res["message"]
        return reply or self._t("discarded")

    def _offline_reply(self, text: str) -> str:
        """The AI model is unreachable: understand simple orders with plain rules, otherwise explain."""
        self.last_offline = True
        names = [i["name"] for items in db.get_menu_by_category("all")["menu"].values() for i in items]
        guesses = parse_simple_order(text, names)
        staged_any = False
        notes = []
        for g in guesses:
            res = self._stage_add(g["name"], g["qty"], g["instructions"])
            self._turn["tool_calls"].append({"tool": "offline_parse", "arguments": g, "result": res})
            if res["status"] == "ok":
                staged_any = True
            else:
                notes.append(res["message"])
        if staged_any:
            reply = self._t("offline_guess", items=self._pending_label())
            return reply + (" " + " ".join(notes) if notes else "")
        if notes:
            return " ".join(notes)
        return self._t("offline")

    def _run_llm(self) -> str:
        mark = len(self.messages) - 1
        retried = False
        try:
            for _ in range(MAX_TOOL_ROUNDS):
                raw = self.llm_chat(self.messages).strip()
                calls = parse_tool_calls(raw)

                if not calls:
                    if '"tool"' in raw and not retried:
                        retried = True
                        self.messages += [
                            {"role": "assistant", "content": raw},
                            {"role": "user", "content": "SYSTEM: invalid JSON tool call format. Reply with valid JSON only."},
                        ]
                        continue
                    if not self.pending_adds:
                        fixed = self._check_model_reply(raw)
                        if fixed is not None:
                            self.messages.append({"role": "assistant", "content": fixed})
                            self._trim_history()
                            return fixed
                    if self.pending_adds:                       # code, not the model, words the question
                        raw = self._t("ask_confirm", items=self._pending_label())
                    self.messages.append({"role": "assistant", "content": raw})
                    self._trim_history()
                    return raw or "Sorry, could you say that again?"

                self.messages.append({"role": "assistant", "content": raw})
                results = []
                for call in calls:
                    result = self._execute_tool(call)
                    self._turn["tool_calls"].append({**call, "result": result})
                    results.append({"tool": call["tool"], "result": result})
                if self._review_requested:
                    self._review_requested = False
                    self.messages.append({"role": "user", "content": "TOOL_RESULT: review started"})
                    return self._enter_review("LLM called request_review")
                self.messages.append({"role": "user", "content": "TOOL_RESULT: " + json.dumps(results)})
                if self.pending_adds and all(c.get("tool") == "add_item_to_order" for c in calls):
                    # the code (not the model) words the confirmation question, so a second model call would be wasted
                    notes = [r["result"].get("message", "") for r in results if r["result"].get("status") != "ok"]
                    reply = self._t("ask_confirm", items=self._pending_label()) + ((" " + " ".join(notes)) if notes else "")
                    self.messages.append({"role": "assistant", "content": reply})
                    self._trim_history()
                    return reply
        except LLMError:
            if self.pending_adds and len(self.messages) > mark + 1:      # tools ran, then the model died
                self.messages.append({"role": "assistant", "content": self._t("ask_confirm", items=self._pending_label())})
                return self._t("ask_confirm", items=self._pending_label())
            del self.messages[mark:]
            raise
        if self.pending_adds:
            return self._t("ask_confirm", items=self._pending_label())
        return "Sorry, I had trouble processing that. Could you rephrase your request?"

    def _check_model_reply(self, raw: str) -> Optional[str]:
        """Small models sometimes SAY they added something without calling a tool (or refuse a normal request).
        We never trust that: the database is the only truth.  Returns a replacement reply, or None if the reply is fine."""
        tools_used = {c.get("tool") for c in self._turn["tool_calls"]}
        if tools_used & {"add_item_to_order", "remove_item_from_order", "request_review"}:
            return None
        if CLAIM_RE.search(raw):
            recovered = []
            notes = []
            for g in parse_simple_order(self._last_user_text, self._menu_names()):
                res = self._stage_add(g["name"], g["qty"], g["instructions"])
                self._log_guardrail("unverified_claim", {"claimed": raw[:100], "recovered": g}, res)
                (recovered if res["status"] == "ok" else notes).append(res)
            if self.pending_adds:
                return self._t("ask_confirm", items=self._pending_label())
            if notes:
                return " ".join(n["message"] for n in notes)
            self._log_guardrail("unverified_claim", {"claimed": raw[:100], "recovered": None})
            return self._t("unknown_dish")
        if REFUSAL_RE.search(raw):
            self._log_guardrail("false_refusal", {"text": self._last_user_text[:100]})
            return self._t("unclear")
        return None

    def _trim_history(self) -> None:
        if len(self.messages) > MAX_HISTORY:
            self.messages = self.messages[:1] + self.messages[-(MAX_HISTORY - 1):]

    def _execute_tool(self, call: dict) -> dict:
        name, args = call["tool"], dict(call["arguments"])
        if name == "request_review":
            view = db.view_current_order(self.session_id)
            if view["is_empty"] and not self.pending_adds:
                return db._err("empty_order", "The tab is empty; nothing to review yet.")
            self._review_requested = True
            return {"status": "ok", "message": "Moving to review."}
        if name == "add_item_to_order" and self.confirm_ai_orders:
            return self._stage_add(args.get("item_name", ""), args.get("qty", 1), args.get("instructions", ""))
        fn = db.LLM_TOOLS.get(name)
        if fn is None:
            return db._err("unknown_tool", f"There is no tool named {name!r}.")
        params = inspect.signature(fn).parameters
        args = {k: v for k, v in args.items() if k in params and k != "session_id"}
        if "session_id" in params:
            args["session_id"] = self.session_id
        try:
            inspect.signature(fn).bind(**args)
        except TypeError as exc:
            return db._err("invalid_arguments", f"Bad arguments for {name}: {exc}")
        try:
            return fn(**args)
        except Exception as exc:
            return db._err("tool_failure", f"{name} failed unexpectedly ({type(exc).__name__}).")

    def _clear(self) -> str:
        db.clear_order(self.session_id)
        self.pending_adds = []
        if self.state != STATE_TAKING_ORDER:
            self._set_state(STATE_TAKING_ORDER, "order cleared")
        self.messages.append({"role": "user", "content": "SYSTEM: the customer cleared their whole order."})
        return self._t("cleared")

    # ---- review & payment -------------------------------------------------------------------
    def _enter_review(self, reason: str) -> str:
        self._set_state(STATE_REVIEW, reason)
        view = db.view_current_order(self.session_id)
        self.messages.append({"role": "assistant", "content": "(showed itemised tab)"})
        return (f"Here is your order for Table {self.table_no}:\n\n{format_tab(view)}\n\n"
                "Shall I send this to the kitchen? Say 'yes' to confirm and tell me how you'd like to pay "
                f"({', '.join(db.PAYMENT_METHODS)}), or tell me what to change.")

    def _review(self, text: str) -> str:
        blocked = self._guard(text)                      # off-topic / sent-order edits do not leave REVIEW
        if blocked:
            return blocked
        method = db.find_payment_method(text) if len(text.split()) <= 8 else None
        if method:
            self.payment_method = method
            return self._confirm()
        if YES_RE.match(text):
            return self._confirm()
        if CLEAR_RE.match(text):
            return self._clear()
        self.awaiting_payment = False
        self._set_state(STATE_TAKING_ORDER, "customer wants changes")
        if NO_RE.match(text):
            return "Of course - what would you like to change?"
        return self._taking_order(text)

    def _confirm(self, tip: Any = 0.0, split: Any = 1) -> str:
        self.last_confirm = None
        view = db.view_current_order(self.session_id)
        if view["is_empty"]:
            self._set_state(STATE_TAKING_ORDER, "nothing to confirm")
            return self._t("tab_empty")
        if not self.payment_method:
            self.awaiting_payment = True
            return self._t("pay_ask", methods=", ".join(db.PAYMENT_METHODS))
        self.awaiting_payment = False
        self._set_state(STATE_CONFIRMED, "customer confirmed order")
        result = db.confirm_order(self.session_id, self.payment_method, tip, split)
        self._turn["tool_calls"].append({"tool": "confirm_order",
                                         "arguments": {"session_id": self.session_id, "payment_method": self.payment_method,
                                                       "tip": tip, "split_count": split},
                                         "result": result})
        if result["status"] != "ok":
            self._set_state(STATE_TAKING_ORDER, f"commit failed: {result['error']}")
            return f"I'm sorry, I couldn't confirm that: {result['message']} Please adjust your order."
        self.last_confirm = result
        self.order_ids.append(result["order_id"])
        self.payment_method = None                       # each round is paid separately
        self._set_state(STATE_TAKING_ORDER, f"order #{result['order_id']} sent to the kitchen; ready for another round")
        self.messages.append({"role": "user", "content": f"SYSTEM: order #{result['order_id']} was sent to the kitchen. "
                                                         "The tab is empty again; the customer may order more or ask for the bill."})
        self._emit("order_new", {"order_id": result["order_id"], "table_no": self.table_no,
                                 "items": sum(i["quantity"] for i in result["items"])})
        return f"{format_receipt(result)}\n\n{self._t('more')}"

    def checkout(self, method: str, tip: Any = 0.0, split: Any = 1) -> dict:
        """Used by the payment pop-up: go straight from cart to a confirmed order."""
        self._turn = {"tool_calls": [], "transitions": []}
        before = self.state
        if self.session_id is None:
            return {"ok": False, "error": "no_session", "reply": "Tell the waiter your table number first (e.g. 'Table 4')."}
        if db.view_current_order(self.session_id)["is_empty"]:
            return {"ok": False, "error": "empty_order", "reply": "Your cart is empty."}
        self.pending_adds = []
        self.payment_method = method
        if self.state != STATE_REVIEW:
            self._set_state(STATE_REVIEW, "checkout button")
        reply = self._confirm(tip, split)
        ok = self.last_confirm is not None
        self._record(f"[checkout via {method}]", before, reply)
        return {"ok": ok, "reply": reply, "order": self.last_confirm,
                "error": None if ok else "not_confirmed"}

    # ---- commands ---------------------------------------------------------------------------
    def _command(self, text: str) -> str:
        cmd = text.split()[0].lower()
        if cmd == "/help":
            return "Commands: /menu /cart /orders /bill /confirm /clear /state /quit"
        if cmd == "/menu":
            return format_menu(db.get_menu_by_category("all"))
        if cmd == "/state":
            return f"State: {self.state} | table: {self.table_no} | session: {self.session_id}"
        if self.session_id is None:
            return "Please tell me your table number first."
        if cmd == "/cart":
            return format_tab(db.view_current_order(self.session_id))
        if cmd == "/orders":
            orders = db.session_orders(self.session_id)
            if not orders:
                return "You haven't sent any orders to the kitchen yet."
            return "\n".join(f"Order #{o['order_id']} (round {o['round_no']}): {o['status'].upper()} - "
                             f"{o['item_count']} item(s), {money(o['grand_total'])} {db.CURRENCY}" for o in orders)
        if cmd == "/bill":
            return self._service_request("bill") if self.order_ids else "You haven't ordered anything yet."
        if cmd == "/clear":
            return self._clear()
        if cmd == "/confirm":
            if self.state == STATE_REVIEW:
                return self._confirm()
            view = db.view_current_order(self.session_id)
            if view["is_empty"]:
                return self._t("tab_empty")
            return self._enter_review("/confirm command")
        return "Unknown command. Type /help to see options."