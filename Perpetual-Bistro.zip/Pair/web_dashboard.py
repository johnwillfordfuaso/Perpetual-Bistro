#!/usr/bin/env python3
"""
web_dashboard.py - Perpetual Bistro web app (standard library only).

Pages
  /          customer ordering dashboard (one independent waiter session per browser)
  /kitchen   kitchen display: live ticket board, service requests, quick sold-out switches
  /admin     manager console: tables, orders, menu & stock, analytics, QR codes, feedback, AI logs
  /receipt/N printable receipt for order N

Live updates use Server-Sent Events (/api/events); the pages fall back to polling.
Staff pages are protected by PINs (--manager-pin / --kitchen-pin, or BISTRO_MANAGER_PIN / BISTRO_KITCHEN_PIN).
"""
from __future__ import annotations

import argparse
import base64
import binascii
import hmac
import html
import json
import logging
import os
import re
import secrets
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from collections import deque
from datetime import datetime
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Callable, Optional

import db_tools as db
import speech_engine
from fsm_agent import STATE_GREETING, STATE_REVIEW, STATE_TAKING_ORDER, FSMAgent, LLMError, OllamaClient

HERE = Path(__file__).resolve().parent
PAGES = {"/": "menu.html", "/index.html": "menu.html", "/classic": "dashboard.html", "/admin": "admin.html", "/kitchen": "kitchen.html"}
MAX_BODY = 16 * 1024
MAX_IMAGE_BYTES = 2 * 1024 * 1024
MAX_IMAGE_BODY = 4 * 1024 * 1024
MAX_SSE_CLIENTS = 150
IMAGES_DIR = HERE / "images"
STATIC_DIR = HERE / "static"            # offline copies of Bootstrap / Chart.js / fonts (run fetch_assets.py once)
STATIC_TYPES = {".css": "text/css", ".js": "application/javascript", ".woff2": "font/woff2", ".woff": "font/woff",
                ".map": "application/json", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png"}
STATIC_NAME_RE = re.compile(r"^[A-Za-z0-9_.\-]+(/[A-Za-z0-9_.\-]+)*$")
MAX_AUDIO_BODY = 3 * 1024 * 1024        # a 30 s, 16 kHz mono WAV is about 1 MB
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg")
IMAGE_TYPES = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
               ".webp": "image/webp", ".gif": "image/gif", ".svg": "image/svg+xml"}
IMAGE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*\.(jpg|jpeg|png|webp|gif|svg)$", re.I)
CID_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
CID_COOKIE, ADMIN_COOKIE = "bistro_cid", "bistro_admin"
RESTAURANT = "Perpetual Bistro"
log = logging.getLogger("dashboard")

CATEGORY_EMOJI = {"Mains": "\U0001F37D️", "Sides": "\U0001F35F", "Drinks": "\U0001F964", "Desserts": "\U0001F368"}
MENU_META: dict[str, dict[str, str]] = {
    "Cheeseburger": {"emoji": "\U0001F354"}, "Veggie Burger": {"emoji": "\U0001F96C"},
    "Spaghetti Bolognese": {"emoji": "\U0001F35D"}, "Chicken Adobo Rice": {"emoji": "\U0001F357"},
    "Pesto Pasta": {"emoji": "\U0001F33F"}, "French Fries": {"emoji": "\U0001F35F"},
    "Garden Salad": {"emoji": "\U0001F957"}, "Onion Rings": {"emoji": "\U0001F9C5"},
    "Iced Tea": {"emoji": "\U0001F9CA"}, "Mango Smoothie": {"emoji": "\U0001F96D"},
    "Cola": {"emoji": "\U0001F964"}, "Bottled Water": {"emoji": "\U0001F4A7"},
    "Matcha Sea Salt": {"emoji": "\U0001F375"}, "Leche Flan": {"emoji": "\U0001F36E"},
    "Halo-Halo": {"emoji": "\U0001F367"},
}


def menu_slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def find_image(name: str) -> Optional[str]:
    slug = menu_slug(name)
    for ext in IMAGE_EXTS:
        f = IMAGES_DIR / f"{slug}{ext}"
        if f.is_file():
            return f"/images/{slug}{ext}?v={int(f.stat().st_mtime)}"      # ?v= busts the browser cache after an upload
    return None


def decorate_item(it: dict) -> dict:
    it["emoji"] = MENU_META.get(it["name"], {}).get("emoji", CATEGORY_EMOJI.get(it["category"], "\U0001F37D️"))
    it["description"] = it["description"] or "A Perpetual Bistro favourite."
    it["image"] = find_image(it["name"])
    return it


def decorate_menu(result: dict) -> dict:
    if result.get("status") != "ok":
        return result
    for items in result["menu"].values():
        for it in items:
            decorate_item(it)
    return result


def setup_logging(logfile: Path, verbose: bool) -> None:
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%H:%M:%S")
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    log.addHandler(console)
    try:
        f = RotatingFileHandler(logfile, maxBytes=500_000, backupCount=2, encoding="utf-8")
        f.setFormatter(fmt)
        log.addHandler(f)
    except OSError as exc:
        log.warning("Could not write log file %s (%s)", logfile, exc)


class ApiError(Exception):
    def __init__(self, code: int, error: str, message: str):
        super().__init__(message)
        self.code, self.error, self.message = code, error, message


# ---------------------------------------------------------------------------------------------
# AI plumbing
# ---------------------------------------------------------------------------------------------
class TrackedLLM:
    """Per-customer wrapper: remembers whether the last call failed, and queues calls so a small
    local model isn't flooded by several tables at once."""
    gate = threading.Semaphore(1)

    def __init__(self, client: Callable[[list], str]):
        self.client = client
        self.last_error: Optional[str] = None

    def __call__(self, messages: list) -> str:
        with TrackedLLM.gate:
            try:
                out = self.client(messages)
                self.last_error = None
                return out
            except LLMError as exc:
                self.last_error = str(exc)
                log.warning("LLM call failed: %s", exc)
                raise


class OllamaMonitor:
    def __init__(self, host: str, model: str, ttl: float = 3.0):
        self.host, self.model, self.ttl = host.rstrip("/"), model, ttl
        self._cache: Optional[dict] = None
        self._at = 0.0

    def status(self) -> dict:
        now = time.monotonic()
        if self._cache and now - self._at < self.ttl:
            return self._cache
        info: dict[str, Any] = {"host": self.host, "model": self.model, "online": False,
                                "model_installed": False, "hint": ""}
        try:
            req = urllib.request.Request(f"{self.host}/api/tags")
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=2) as resp:
                names = [m.get("name", "") for m in json.loads(resp.read()).get("models", [])]
            info["online"] = True
            info["model_installed"] = any(n == self.model or n.startswith(self.model + ":") for n in names)
            if not info["model_installed"]:
                info["hint"] = f"Model not installed. Run: ollama pull {self.model}"
        except (urllib.error.URLError, OSError, TimeoutError, json.JSONDecodeError, ValueError):
            info["hint"] = "Ollama is not running. Start it with: ollama serve"
        if info["online"] != (self._cache or {}).get("online"):
            log.info("Ollama status: %s %s", "ONLINE" if info["online"] else "OFFLINE", info["hint"])
        self._cache, self._at = info, now
        return info


# ---------------------------------------------------------------------------------------------
# Live events (Server-Sent Events)
# ---------------------------------------------------------------------------------------------
class Broker:
    """In-process pub/sub with a short replay buffer so a reconnecting browser doesn't miss events."""

    def __init__(self, keep: int = 300):
        self.cond = threading.Condition()
        self.events: deque = deque(maxlen=keep)
        self.next_id = 1
        self.closed = False
        self.listeners = 0

    @property
    def last_id(self) -> int:
        with self.cond:
            return self.next_id - 1

    def publish(self, type_: str, **data: Any) -> dict:
        with self.cond:
            ev = {"id": self.next_id, "type": type_, "ts": round(time.time(), 3), **data}
            self.next_id += 1
            self.events.append(ev)
            self.cond.notify_all()
        return ev

    def wait_after(self, last_id: int, timeout: float) -> list[dict]:
        end = time.monotonic() + timeout
        with self.cond:
            while not self.closed:
                new = [e for e in self.events if e["id"] > last_id]
                if new:
                    return new
                left = end - time.monotonic()
                if left <= 0:
                    return []
                self.cond.wait(left)
            return []

    def close(self) -> None:
        with self.cond:
            self.closed = True
            self.cond.notify_all()


# ---------------------------------------------------------------------------------------------
# Customers: one waiter session per browser (cookie)
# ---------------------------------------------------------------------------------------------
class Client:
    def __init__(self, cid: str, app: "App"):
        self.cid = cid
        self.lock = threading.RLock()
        self.llm = TrackedLLM(app.llm_client)
        self.agent = FSMAgent(self.llm, llm_label=app.model, confirm_ai_orders=app.confirm_ai,
                              notify=app.publish, client_id=cid[:8])
        self.session_ids: set[int] = set()      # sessions this browser owns (receipt / rating access)
        self.touched = time.time()

    def remember(self) -> None:
        if self.agent.session_id:
            self.session_ids.add(self.agent.session_id)


class AdminAuth:
    """Two PIN-protected roles. 'manager' can do everything; 'kitchen' can run the order board."""

    def __init__(self, manager_pin: str, kitchen_pin: str, ttl: float = 12 * 3600):
        self.pins = {"manager": manager_pin, "kitchen": kitchen_pin}
        self.ttl = ttl
        self.sessions: dict[str, tuple[str, float]] = {}
        self.fails: dict[str, list[float]] = {}
        self.lock = threading.Lock()

    def login(self, pin: str, ip: str) -> tuple[str, str]:
        now = time.time()
        with self.lock:
            recent = [t for t in self.fails.get(ip, []) if now - t < 300]
            if len(recent) >= 5:
                raise ApiError(429, "too_many_attempts", "Too many wrong PINs. Please wait a few minutes and try again.")
            role = None
            for name in ("manager", "kitchen"):         # compare against both so timing doesn't reveal which matched
                if hmac.compare_digest(str(pin).encode(), self.pins[name].encode()) and role is None:
                    role = name
            if role is None:
                recent.append(now)
                self.fails[ip] = recent
                raise ApiError(401, "bad_pin", "That PIN is not correct.")
            self.fails.pop(ip, None)
            token = secrets.token_urlsafe(32)
            self.sessions[token] = (role, now + self.ttl)
            return role, token

    def role(self, token: Optional[str]) -> Optional[str]:
        if not token:
            return None
        with self.lock:
            entry = self.sessions.get(token)
            if not entry:
                return None
            if entry[1] < time.time():
                del self.sessions[token]
                return None
            return entry[0]

    def logout(self, token: Optional[str]) -> None:
        with self.lock:
            self.sessions.pop(token or "", None)

    def purge(self) -> None:
        now = time.time()
        with self.lock:
            for t in [t for t, (_, exp) in self.sessions.items() if exp < now]:
                del self.sessions[t]


class Ctx:
    """Everything a route handler needs about one request."""

    def __init__(self, app: "App", method: str, path: str, query: dict, body: dict, params: tuple,
                 cid: str, role: Optional[str], ip: str):
        self.app, self.method, self.path, self.query, self.body, self.params = app, method, path, query, body, params
        self.cid, self.role, self.ip = cid, role, ip
        self.cookies: dict[str, str] = {}
        self.set_cookies: list[str] = []

    @property
    def client(self) -> Client:
        return self.app.clients_get(self.cid)


class Raw:
    """A non-JSON response (HTML page, download)."""

    def __init__(self, code: int, body: bytes, ctype: str, headers: Optional[dict] = None):
        self.code, self.body, self.ctype, self.headers = code, body, ctype, headers or {}


# ---------------------------------------------------------------------------------------------
class App:
    def __init__(self, model: str, monitor: OllamaMonitor, llm_client: Callable, log_path: Path, tables: int,
                 auth: AdminAuth, confirm_ai: bool = True, client_ttl: float = 4 * 3600):
        self.model, self.monitor, self.llm_client, self.log_path = model, monitor, llm_client, log_path
        self.n_tables, self.auth, self.confirm_ai, self.client_ttl = tables, auth, confirm_ai, client_ttl
        self.broker = Broker()
        self.started = time.time()
        self._clients: dict[str, Client] = {}
        self._clients_lock = threading.Lock()
        self._retired_turns: list[dict] = []
        self._last_purge = time.time()

    # ---- infrastructure ---------------------------------------------------------------------
    def publish(self, type_: str, payload: Optional[dict] = None, **extra: Any) -> None:
        self.broker.publish(type_, **{**(payload or {}), **extra})

    def clients_get(self, cid: str) -> Client:
        with self._clients_lock:
            c = self._clients.get(cid)
            if c is None:
                c = self._clients[cid] = Client(cid, self)
                log.info("new customer session holder %s (%d active)", cid[:8], len(self._clients))
            c.touched = time.time()
        self.housekeeping()
        return c

    def housekeeping(self) -> None:
        if time.time() - self._last_purge < 300:
            return
        self._last_purge = time.time()
        self.auth.purge()
        cutoff = time.time() - self.client_ttl
        with self._clients_lock:
            stale = [cid for cid, c in self._clients.items() if c.touched < cutoff]
            for cid in stale:
                c = self._clients.pop(cid)
                self._retired_turns += [{**t, "client": cid[:8]} for t in c.agent.log["turns"]]
                del self._retired_turns[:-2000]
                c.agent.shutdown()
        if stale:
            log.info("expired %d idle customer sessions", len(stale))

    def all_turns(self) -> list[dict]:
        with self._clients_lock:
            clients = list(self._clients.items())
        turns = list(self._retired_turns)
        for cid, c in clients:
            turns += [{**t, "client": cid[:8]} for t in c.agent.log["turns"]]
        return sorted(turns, key=lambda t: t["timestamp"])

    def save_logs(self) -> None:
        try:
            with open(self.log_path, "w", encoding="utf-8") as fh:
                json.dump({"meta": {"llm": self.model, "saved_at": datetime.now().isoformat(timespec="seconds"),
                                    "service_fee_rate": db.SERVICE_FEE_RATE, "currency": db.CURRENCY},
                           "turns": self.all_turns()}, fh, indent=2, ensure_ascii=False)
        except OSError as exc:
            log.warning("Could not save conversation log: %s", exc)

    def shutdown(self) -> None:
        self.broker.close()
        with self._clients_lock:
            clients = list(self._clients.values())
        for c in clients:
            c.agent.shutdown()
        self.save_logs()

    # ---- public info ------------------------------------------------------------------------
    def health(self, ctx: Ctx):
        return 200, {"server": "ok", "uptime_s": int(time.time() - self.started), "ollama": self.monitor.status(),
                     "customers": len(self._clients)}

    def status(self, ctx: Ctx):
        st = self.monitor.status()
        ok = st["online"] and st["model_installed"]
        return 200, {"status": "ok" if ok else "offline", "online": st["online"],
                     "model_installed": st["model_installed"], "model": st["model"], "hint": st["hint"]}

    def config(self, ctx: Ctx):
        return 200, {"restaurant": RESTAURANT, "tables": self.n_tables, "currency": db.CURRENCY,
                     "service_fee_rate": db.SERVICE_FEE_RATE, "low_stock_threshold": db.LOW_STOCK_THRESHOLD,
                     "ai_model": self.model, "confirm_ai_orders": self.confirm_ai,
                     "payment_methods": self._methods(), "service_kinds": db.SERVICE_KINDS,
                     "allergens": db.ALLERGEN_CHOICES, "languages": {"en": "English", "fil": "Filipino"},
                     "discounts": {k: {"label": v["label"], "rate": v["rate"]} for k, v in db.DISCOUNTS.items()},
                     "lan_url": getattr(self, "lan_url", None),
                     "stt_offline": self.stt.status() if getattr(self, "stt", None) and self.stt.available else None}

    @staticmethod
    def _methods() -> list[dict]:
        return [{"name": n, **meta} for n, meta in db.PAYMENT_METHODS.items()]

    def payment_methods(self, ctx: Ctx):
        return 200, {"methods": self._methods()}

    def menu(self, ctx: Ctx):
        return 200, decorate_menu(db.get_menu_by_category("all"))

    def greeting(self, ctx: Ctx):
        return 200, {"reply": ctx.client.agent.start()}

    # ---- customer state ---------------------------------------------------------------------
    @staticmethod
    def _public_order(o: dict) -> dict:
        keep = ("order_id", "round_no", "status", "items", "item_count", "subtotal", "service_fee", "tip", "grand_total",
                "split_count", "per_person", "payment_method", "payment_status", "payment_ref", "cancel_reason",
                "created_at", "age_seconds", "feedback", "currency", "table_no",
                "discount_type", "discount_rate", "discount_amount", "discount_id")
        return {k: o[k] for k in keep}

    def _check_closed(self, c: Client) -> bool:
        """If staff closed this customer's table, reset the waiter. Returns True when that happened."""
        a = c.agent
        if a.session_id is not None and not db.session_is_active(a.session_id):
            a.reset()
            return True
        return False

    def state(self, ctx: Ctx):
        c = ctx.client
        with c.lock:
            closed = self._check_closed(c)
            a = c.agent
            c.remember()
            sid = a.session_id
            cart = db.view_current_order(sid) if sid else None
            if cart and cart.get("status") != "ok":
                cart = None
            orders = [self._public_order(o) for o in db.session_orders(sid)] if sid else []
            reqs = db.list_service_requests(open_only=True, session_id=sid) if sid else []
            return 200, {
                "state": a.state, "table_no": a.table_no, "session_id": sid, "cart": cart, "orders": orders,
                "requests": [{"request_id": r["request_id"], "kind": r["kind"], "label": r["label"]} for r in reqs],
                "pending_adds": [{"name": p["name"], "qty": p["qty"], "instructions": p["instructions"]} for p in a.pending_adds],
                "awaiting_payment": a.awaiting_payment and a.state == STATE_REVIEW,
                "payment_methods": self._methods(), "language": a.language, "closed_by_staff": closed,
            }

    # ---- customer actions -------------------------------------------------------------------
    def chat(self, ctx: Ctx):
        text = str(ctx.body.get("text", "")).strip()[:500]
        if not text:
            raise ApiError(400, "empty_message", "Please type something.")
        c = ctx.client
        log.info("customer %s: %s", c.cid[:6], text)
        with c.lock:
            if ctx.body.get("lang"):
                c.agent.set_language(str(ctx.body["lang"]))
            c.llm.last_error = None
            self._check_closed(c)
            reply = c.agent.handle(text)
            c.remember()
            a = c.agent
            degraded = c.llm.last_error is not None or a.last_offline
            turn = a.log["turns"][-1] if a.log["turns"] else {}
            try:
                db.log_chat_turn(c.cid[:8], a.session_id, a.table_no, text, reply, turn.get("state_before", ""),
                                 a.state, turn.get("tool_calls"), degraded)
            except Exception:
                log.exception("could not write chat log")
            needs_payment = a.awaiting_payment and a.state == STATE_REVIEW
            pending = [{"name": p["name"], "qty": p["qty"], "instructions": p["instructions"]} for p in a.pending_adds]
        log.info("waiter (%s%s): %s", a.state, ", DEGRADED" if degraded else "", reply.splitlines()[0][:100])
        return 200, {"reply": reply, "degraded": degraded, "needs_payment": needs_payment, "pending_adds": pending}

    def set_language(self, ctx: Ctx):
        c = ctx.client
        with c.lock:
            c.agent.set_language(str(ctx.body.get("lang", "en")))
            return 200, {"language": c.agent.language, "reply": c.agent.start()}

    def _need_session(self, c: Client, message: str = "Tell the waiter your table number first (e.g. 'Table 4').") -> int:
        sid = c.agent.session_id
        if sid is None:
            raise ApiError(409, "no_session", message)
        return sid

    @staticmethod
    def _sync_agent(c: Client, what: str) -> None:
        a = c.agent
        if a.state == STATE_REVIEW:
            a.state = STATE_TAKING_ORDER
        a.awaiting_payment = False
        if a.messages:
            a.messages.append({"role": "user", "content": f"SYSTEM: the customer {what} using the on-screen menu."})

    def order_add(self, ctx: Ctx):
        name = str(ctx.body.get("item_name", "")).strip()
        if not name:
            raise ApiError(400, "missing_item", "item_name is required.")
        c = ctx.client
        with c.lock:
            self._check_closed(c)
            sid = self._need_session(c)
            res = db.add_item_to_order(sid, name, ctx.body.get("qty", 1), ctx.body.get("instructions", ""))
            if res["status"] == "ok":
                self._sync_agent(c, f"added {res['added']['quantity']}x {res['added']['item']}")
            res["cart"] = db.view_current_order(sid)
        return (200 if res["status"] == "ok" else 422), res

    def order_add_many(self, ctx: Ctx):
        items = ctx.body.get("items")
        if not isinstance(items, list) or not items or len(items) > 30:
            raise ApiError(400, "bad_items", "items must be a list of 1-30 dishes.")
        c = ctx.client
        results: list[dict] = []
        with c.lock:
            self._check_closed(c)
            sid = self._need_session(c)
            for it in items:
                name = str(it.get("item_name", "")).strip() if isinstance(it, dict) else ""
                if not name:
                    results.append({"item_name": name, "status": "error", "message": "Missing item_name."})
                    continue
                res = db.add_item_to_order(sid, name, it.get("qty", 1), it.get("instructions", ""))
                results.append({"item_name": name, "status": res["status"], "error": res.get("error"),
                                "message": res.get("message"), "added": res.get("added")})
            done = [r for r in results if r["status"] == "ok"]
            if done:
                self._sync_agent(c, "added " + ", ".join(f"{r['added']['quantity']}x {r['added']['item']}" for r in done))
            cart = db.view_current_order(sid)
        status = "ok" if len(done) == len(results) else ("partial" if done else "error")
        return (200 if done else 422), {"status": status, "results": results, "cart": cart}

    def order_remove(self, ctx: Ctx):
        name = str(ctx.body.get("item_name", "")).strip()
        if not name:
            raise ApiError(400, "missing_item", "item_name is required.")
        c = ctx.client
        with c.lock:
            self._check_closed(c)
            sid = self._need_session(c, "No open order.")
            res = db.remove_item_from_order(sid, name, ctx.body.get("qty"))
            if res["status"] == "ok":
                self._sync_agent(c, f"removed {res['removed']['quantity']}x {res['removed']['item']}")
            res["cart"] = db.view_current_order(sid)
        return (200 if res["status"] == "ok" else 422), res

    def reset(self, ctx: Ctx):
        c = ctx.client
        with c.lock:
            c.agent.reset()
            c.session_ids.clear()
        log.info("customer %s: new customer", c.cid[:6])
        return 200, {"reply": c.agent.start()}

    def checkout(self, ctx: Ctx):
        method = db.find_payment_method(ctx.body.get("payment_method"))
        if method is None:
            raise ApiError(400, "invalid_payment", "Please choose one of: " + ", ".join(db.PAYMENT_METHODS) + ".")
        # Demo payment screen: "fail" lets you show the declined path without a real gateway.
        if ctx.body.get("simulate") == "fail" and db.PAYMENT_METHODS[method]["type"] == "online":
            raise ApiError(402, "payment_declined", f"The demo {method} payment was declined. Nothing was charged and "
                                                    "your cart is unchanged. Try again or choose another method.")
        c = ctx.client
        with c.lock:
            self._check_closed(c)
            self._need_session(c)
            res = c.agent.checkout(method, ctx.body.get("tip", 0), ctx.body.get("split_count", 1))
            c.remember()
        log.info("checkout via %s -> %s", method, "confirmed" if res["ok"] else res["error"])
        if res["ok"]:
            return 200, {"status": "ok", "confirmed": True, "payment_method": method, "reply": res["reply"],
                         "order": self._public_order(db.get_order(res["order"]["order_id"]))}
        code = {"no_session": 409, "empty_order": 422}.get(res["error"], 422)
        return code, {"status": "error", "confirmed": False, "error": res["error"], "message": res["reply"],
                      "reply": res["reply"]}

    def discount(self, ctx: Ctx):
        """Apply or remove the PWD / Senior Citizen discount for this table. Body: {"type": "pwd"|"senior"|"", "id_no": "..."}"""
        c = ctx.client
        with c.lock:
            self._check_closed(c)
            sid = self._need_session(c, "Pick your table first.")
            res = db.set_session_discount(sid, ctx.body.get("type"), ctx.body.get("id_no", ""))
        return (200 if res["status"] == "ok" else 422), res

    def service_request(self, ctx: Ctx):
        kind = str(ctx.body.get("kind", ""))
        c = ctx.client
        with c.lock:
            self._check_closed(c)
            sid = self._need_session(c, "Pick your table first.")
            if kind == "bill" and not db.session_orders(sid):
                raise ApiError(422, "nothing_ordered", "You haven't sent an order to the kitchen yet.")
            res = db.create_service_request(sid, kind, ctx.body.get("note", ""))
            table = c.agent.table_no
        if res["status"] != "ok":
            raise ApiError(422, res["error"], res["message"])
        if not res["duplicate"]:
            self.publish("request_new", request_id=res["request"]["request_id"], kind=kind, table_no=table)
        return 200, {"status": "ok", "duplicate": res["duplicate"], "request": res["request"],
                     "message": "Already on its way - thank you for your patience." if res["duplicate"]
                     else "Done - the team has been notified."}

    def feedback(self, ctx: Ctx):
        oid = db._to_int(ctx.body.get("order_id"))
        if oid is None:
            raise ApiError(400, "invalid_order", "order_id is required.")
        c = ctx.client
        o = db.get_order(oid)
        if not o or o["session_id"] not in c.session_ids:
            raise ApiError(403, "forbidden", "You can only rate your own orders.")
        res = db.add_feedback(oid, ctx.body.get("rating"), ctx.body.get("comment", ""))
        if res["status"] != "ok":
            raise ApiError(409 if res["error"] == "already_rated" else 422, res["error"], res["message"])
        self.publish("feedback_new", order_id=oid, rating=res["rating"])
        return 200, res

    def receipt(self, ctx: Ctx):
        oid = int(ctx.params[0])
        o = db.get_order(oid)
        allowed = ctx.role is not None or (o is not None and o["session_id"] in ctx.client.session_ids)
        if not o or not allowed:
            return Raw(404, b"<h2>Receipt not found</h2>", "text/html")
        return Raw(200, receipt_html(o).encode("utf-8"), "text/html")

    # ---- staff: auth ------------------------------------------------------------------------
    def admin_login(self, ctx: Ctx):
        role, token = self.auth.login(str(ctx.body.get("pin", "")), ctx.ip)
        ctx.set_cookies.append(f"{ADMIN_COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={int(self.auth.ttl)}")
        log.info("staff login: %s from %s", role, ctx.ip)
        return 200, {"status": "ok", "role": role}

    def admin_logout(self, ctx: Ctx):
        self.auth.logout(ctx.cookies.get(ADMIN_COOKIE))
        ctx.set_cookies.append(f"{ADMIN_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")
        return 200, {"status": "ok"}

    def admin_me(self, ctx: Ctx):
        return 200, {"role": ctx.role, "tables": self.n_tables, "server_time": datetime.now().isoformat(timespec="seconds")}

    # ---- staff: orders & requests -----------------------------------------------------------
    def admin_orders(self, ctx: Ctx):
        status = ctx.query.get("status", "active")
        orders = db.list_orders(status=status, date=ctx.query.get("date") or None,
                                table_no=db._to_int(ctx.query.get("table")), limit=db._to_int(ctx.query.get("limit")) or 200)
        return 200, {"orders": orders, "server_time": datetime.now().isoformat(timespec="seconds")}

    def admin_order_status(self, ctx: Ctx):
        oid = int(ctx.params[0])
        res = db.set_order_status(oid, str(ctx.body.get("status", "")), ctx.body.get("reason", ""), role=ctx.role or "kitchen")
        if res["status"] != "ok":
            code = {"unknown_order": 404, "not_allowed": 403, "invalid_transition": 409}.get(res["error"], 400)
            raise ApiError(code, res["error"], res["message"])
        if not res.get("unchanged"):
            o = res["order"]
            self.publish("order_status", order_id=oid, status=o["status"], table_no=o["table_no"],
                         reason=o.get("cancel_reason") or "")
            log.info("order #%s: %s -> %s (%s)", oid, res.get("previous"), o["status"], ctx.role)
        return 200, res

    def admin_order_paid(self, ctx: Ctx):
        oid = int(ctx.params[0])
        res = db.mark_order_paid(oid, ctx.body.get("ref"))
        if res["status"] != "ok":
            raise ApiError(404 if res["error"] == "unknown_order" else 409, res["error"], res["message"])
        self.publish("order_paid", order_id=oid, table_no=res["order"]["table_no"])
        return 200, res

    def admin_requests(self, ctx: Ctx):
        return 200, {"requests": db.list_service_requests(open_only=ctx.query.get("all") != "1")}

    def admin_request_done(self, ctx: Ctx):
        res = db.resolve_service_request(int(ctx.params[0]))
        if res["status"] != "ok":
            raise ApiError(404, res["error"], res["message"])
        self.publish("request_done", request_id=res["request"]["request_id"], table_no=res["request"]["table_no"])
        return 200, res

    # ---- staff: menu & stock ----------------------------------------------------------------
    def admin_menu(self, ctx: Ctx):
        return 200, {"items": [decorate_item(i) for i in db.list_menu_items()],
                     "low_stock_threshold": db.LOW_STOCK_THRESHOLD, "allergens": db.ALLERGEN_CHOICES}

    def _menu_result(self, res: dict, created: bool = False):
        if res["status"] != "ok":
            code = {"unknown_item": 404, "duplicate_name": 409, "item_in_use": 409}.get(res["error"], 400)
            raise ApiError(code, res["error"], res["message"])
        if "item" in res:
            decorate_item(res["item"])
        self.publish("menu_changed")
        return (201 if created else 200), res

    def admin_menu_add(self, ctx: Ctx):
        return self._menu_result(db.admin_add_menu_item(**ctx.body), created=True)

    def admin_menu_update(self, ctx: Ctx):
        item_id = int(ctx.params[0])
        fields = dict(ctx.body)
        if ctx.role != "manager":           # kitchen staff may only flip availability and restock
            extra = set(fields) - {"available", "stock", "stock_qty"}
            if extra:
                raise ApiError(403, "forbidden", "Only a manager can edit those fields.")
        return self._menu_result(db.admin_update_menu_item(item_id, **fields))

    def admin_menu_delete(self, ctx: Ctx):
        item = db.get_menu_item(int(ctx.params[0]))
        res = db.admin_delete_menu_item(int(ctx.params[0]))
        if res["status"] == "ok" and item:
            self._remove_images(item["name"])
        return self._menu_result(res)

    @staticmethod
    def _remove_images(name: str) -> None:
        slug = menu_slug(name)
        for ext in IMAGE_EXTS:
            try:
                (IMAGES_DIR / f"{slug}{ext}").unlink()
            except OSError:
                pass

    def admin_menu_image(self, ctx: Ctx):
        item = db.get_menu_item(int(ctx.params[0]))
        if not item:
            raise ApiError(404, "unknown_item", "That menu item does not exist.")
        if ctx.body.get("remove"):
            self._remove_images(item["name"])
            self.publish("menu_changed")
            return 200, {"status": "ok", "image": None}
        raw = str(ctx.body.get("data", ""))
        if raw.startswith("data:"):
            raw = raw.split(",", 1)[-1]
        try:
            blob = base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError):
            raise ApiError(400, "bad_image", "The image data could not be read.")
        if len(blob) > MAX_IMAGE_BYTES:
            raise ApiError(413, "image_too_large", "Please use an image under 2 MB.")
        if blob[:3] == b"\xff\xd8\xff":
            ext = ".jpg"
        elif blob[:8] == b"\x89PNG\r\n\x1a\n":
            ext = ".png"
        elif blob[:4] == b"GIF8":
            ext = ".gif"
        elif blob[:4] == b"RIFF" and blob[8:12] == b"WEBP":
            ext = ".webp"
        else:
            raise ApiError(415, "bad_image", "Only JPG, PNG, GIF or WebP images are accepted.")
        IMAGES_DIR.mkdir(exist_ok=True)
        self._remove_images(item["name"])
        (IMAGES_DIR / f"{menu_slug(item['name'])}{ext}").write_bytes(blob)
        self.publish("menu_changed")
        return 200, {"status": "ok", "image": find_image(item["name"])}

    # ---- staff: overview, analytics, feedback, logs, tables --------------------------------
    def admin_overview(self, ctx: Ctx):
        a = db.analytics(7)
        active = db.list_orders("active")
        return 200, {
            "tables": db.tables_overview(self.n_tables), "today": a["today"], "rating": a["rating"],
            "active_counts": {s: sum(1 for o in active if o["status"] == s) for s in db.ACTIVE_STATUSES},
            "requests": db.list_service_requests(True), "low_stock": a["low_stock"],
            "server_time": datetime.now().isoformat(timespec="seconds"),
        }

    def admin_analytics(self, ctx: Ctx):
        return 200, db.analytics(db._to_int(ctx.query.get("days")) or 14)

    def admin_feedback(self, ctx: Ctx):
        return 200, db.list_feedback()

    def admin_logs(self, ctx: Ctx):
        limit = min(db._to_int(ctx.query.get("limit")) or 200, 1000)
        if ctx.query.get("download"):
            body = json.dumps({"meta": {"llm": self.model, "exported_at": datetime.now().isoformat(timespec="seconds")},
                               "turns": self.all_turns()}, indent=2, ensure_ascii=False).encode("utf-8")
            return Raw(200, body, "application/json",
                       {"Content-Disposition": 'attachment; filename="conversation_log.json"'})
        return 200, {"logs": db.list_chat_log(limit, ctx.query.get("client") or None)}

    def admin_close_table(self, ctx: Ctx):
        n = int(ctx.params[0])
        res = db.close_table(n)
        self.publish("table_closed", table_no=n)
        log.info("table %d closed by %s", n, ctx.role)
        return 200, res


# ---------------------------------------------------------------------------------------------
def receipt_html(o: dict) -> str:
    e = html.escape
    rows = "".join(
        f"<tr><td>{i['quantity']}&times; {e(i['name'])}"
        + (f"<br><small>{e(i['instructions'])}</small>" if i["instructions"] else "")
        + f"</td><td class='r'>{i['line_total']:,.2f}</td></tr>" for i in o["items"])
    status = {"paid": "PAID", "unpaid": "PAY AT COUNTER", "refunded": "REFUNDED", "void": "VOID"}.get(o["payment_status"], "")
    cancelled = f"<p class='cancel'>CANCELLED: {e(o['cancel_reason'] or '')}</p>" if o["status"] == "cancelled" else ""
    split = (f"<tr><td>Split {o['split_count']} ways</td><td class='r'>{o['per_person']:,.2f} each</td></tr>"
             if o["split_count"] > 1 else "")
    tip = f"<tr><td>Tip</td><td class='r'>{o['tip']:,.2f}</td></tr>" if o["tip"] else ""
    disc = ""
    if o.get("discount_amount"):
        dlabel = db.DISCOUNTS.get(o.get("discount_type") or "", {}).get("label", "Discount")
        disc = (f"<tr><td>{e(dlabel)} discount ({int(round((o.get('discount_rate') or 0) * 100))}%)</td>"
                f"<td class='r'>-{o['discount_amount']:,.2f}</td></tr>")
        if o.get("discount_id"):
            disc += f"<tr><td colspan='2' class='demo'>ID no. {e(o['discount_id'])} (staff checks the ID)</td></tr>"
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Receipt #{o['order_id']} - {RESTAURANT}</title>
<style>body{{font:15px/1.5 ui-monospace,Menlo,Consolas,monospace;max-width:380px;margin:24px auto;padding:0 16px;color:#222}}
h1{{font-size:18px;text-align:center;margin:0}}p.sub{{text-align:center;margin:2px 0 14px;color:#666}}
table{{width:100%;border-collapse:collapse}}td{{padding:3px 0;vertical-align:top}}td.r{{text-align:right;white-space:nowrap}}
tr.total td{{border-top:2px solid #222;font-weight:700;padding-top:6px}}hr{{border:0;border-top:1px dashed #999;margin:12px 0}}
.cancel{{color:#b00020;font-weight:700;text-align:center}}.demo{{font-size:12px;color:#777;text-align:center}}
button{{display:block;margin:18px auto 0;padding:8px 18px;font:inherit}}@media print{{button{{display:none}}}}</style></head><body>
<h1>{RESTAURANT}</h1><p class="sub">Official receipt</p>
<table><tr><td>Order</td><td class="r">#{o['order_id']} (round {o['round_no']})</td></tr>
<tr><td>Table</td><td class="r">{o['table_no']}</td></tr><tr><td>Date</td><td class="r">{e(o['created_at'])}</td></tr></table><hr>
<table>{rows}</table><hr>
<table><tr><td>Subtotal</td><td class="r">{o['subtotal']:,.2f}</td></tr>
{disc}<tr><td>Service fee ({int(round(db.SERVICE_FEE_RATE * 100))}%)</td><td class="r">{o['service_fee']:,.2f}</td></tr>{tip}
<tr class="total"><td>TOTAL ({o['currency']})</td><td class="r">{o['grand_total']:,.2f}</td></tr>{split}</table><hr>
<table><tr><td>Payment</td><td class="r">{e(o['payment_method'] or '-')}</td></tr>
<tr><td>Status</td><td class="r">{status}</td></tr>
{f"<tr><td>Reference</td><td class='r'>{e(o['payment_ref'])}</td></tr>" if o['payment_ref'] else ''}</table>{cancelled}
<p class="demo">Demo payment - no real money moved.</p><p class="sub">Thank you for dining with us!</p>
<button onclick="window.print()">Print receipt</button></body></html>"""


# ---------------------------------------------------------------------------------------------
class DashboardServer(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True
    request_queue_size = 64


def build_routes(app: App):
    # (method, regex, handler, auth, max_body)   auth: None | "staff" (kitchen or manager) | "manager"
    R = [
        ("GET", r"/api/health", app.health, None),
        ("GET", r"/api/status", app.status, None),
        ("GET", r"/api/config", app.config, None),
        ("GET", r"/api/payment-methods", app.payment_methods, None),
        ("GET", r"/api/greeting", app.greeting, None),
        ("GET", r"/api/menu", app.menu, None),
        ("GET", r"/api/state", app.state, None),
        ("POST", r"/api/chat", app.chat, None),
        ("POST", r"/api/language", app.set_language, None),
        ("POST", r"/api/order/add", app.order_add, None),
        ("POST", r"/api/order/add-many", app.order_add_many, None),
        ("POST", r"/api/order/remove", app.order_remove, None),
        ("POST", r"/api/reset", app.reset, None),
        ("POST", r"/api/checkout", app.checkout, None),
        ("POST", r"/api/discount", app.discount, None),
        ("POST", r"/api/request", app.service_request, None),
        ("POST", r"/api/feedback", app.feedback, None),
        ("GET", r"/receipt/(\d+)", app.receipt, None),
        ("POST", r"/api/admin/login", app.admin_login, None),
        ("POST", r"/api/admin/logout", app.admin_logout, None),
        ("GET", r"/api/admin/me", app.admin_me, None),
        ("GET", r"/api/admin/orders", app.admin_orders, "staff"),
        ("POST", r"/api/admin/orders/(\d+)/status", app.admin_order_status, "staff"),
        ("POST", r"/api/admin/orders/(\d+)/paid", app.admin_order_paid, "staff"),
        ("GET", r"/api/admin/requests", app.admin_requests, "staff"),
        ("POST", r"/api/admin/requests/(\d+)/done", app.admin_request_done, "staff"),
        ("GET", r"/api/admin/menu", app.admin_menu, "staff"),
        ("POST", r"/api/admin/menu", app.admin_menu_add, "manager"),
        ("POST", r"/api/admin/menu/(\d+)", app.admin_menu_update, "staff"),
        ("POST", r"/api/admin/menu/(\d+)/delete", app.admin_menu_delete, "manager"),
        ("POST", r"/api/admin/menu/(\d+)/image", app.admin_menu_image, "manager", MAX_IMAGE_BODY),
        ("GET", r"/api/admin/overview", app.admin_overview, "manager"),
        ("GET", r"/api/admin/analytics", app.admin_analytics, "manager"),
        ("GET", r"/api/admin/feedback", app.admin_feedback, "manager"),
        ("GET", r"/api/admin/logs", app.admin_logs, "manager"),
        ("GET", r"/api/log", app.admin_logs, "manager"),
        ("POST", r"/api/admin/tables/(\d+)/close", app.admin_close_table, "manager"),
    ]
    return [(m, re.compile(p), fn, auth, (rest[0] if rest else MAX_BODY)) for m, p, fn, auth, *rest in R]


def make_handler(app: App, cors: bool):
    routes = build_routes(app)
    quiet_paths = ("/api/state", "/api/status", "/api/health", "/api/events", "/api/admin/orders",
                   "/api/admin/requests", "/api/admin/me", "/api/menu", "/api/config")

    class Handler(BaseHTTPRequestHandler):
        server_version = "BistroDashboard/3.0"

        def log_message(self, fmt, *args):
            pass

        # ---- low-level ----
        def _cookies(self) -> dict[str, str]:
            jar = SimpleCookie()
            try:
                jar.load(self.headers.get("Cookie", ""))
            except Exception:
                return {}
            return {k: m.value for k, m in jar.items()}

        def _send(self, code: int, body: bytes, ctype: str, extra: Optional[dict] = None, cache: str = "no-store",
                  cookies: Optional[list] = None) -> None:
            self.send_response(code)
            textual = ctype.startswith("text/") or ctype.endswith("json")
            self.send_header("Content-Type", f"{ctype}; charset=utf-8" if textual else ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "SAMEORIGIN")
            self.send_header("Referrer-Policy", "no-referrer")
            if cors:
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
            for c in (cookies or []):
                self.send_header("Set-Cookie", c)
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, code: int, obj: Any, **kw) -> None:
            self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json", **kw)

        def _read_json(self, limit: int) -> dict:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise ApiError(400, "bad_request", "Bad Content-Length header.")
            if length > limit:
                raise ApiError(413, "too_large", "Request too large.")
            raw = self.rfile.read(length) if length else b"{}"
            try:
                data = json.loads(raw or b"{}")
            except (json.JSONDecodeError, UnicodeDecodeError):
                raise ApiError(400, "bad_json", "Body is not valid JSON.")
            if not isinstance(data, dict):
                raise ApiError(400, "bad_json", "JSON body must be an object.")
            return data

        # ---- Server-Sent Events ----
        def _sse(self, query: dict) -> None:
            if app.broker.listeners >= MAX_SSE_CLIENTS:
                raise ApiError(503, "busy", "Too many live connections.")
            try:
                last = int(query.get("since") or self.headers.get("Last-Event-ID") or app.broker.last_id)
            except ValueError:
                last = app.broker.last_id
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Accel-Buffering", "no")
            self.send_header("Connection", "close")
            self.end_headers()
            with app.broker.cond:
                app.broker.listeners += 1
            try:
                self.wfile.write(b"retry: 3000\n\n")
                self.wfile.flush()
                while not app.broker.closed:
                    events = app.broker.wait_after(last, 15)
                    if not events:
                        self.wfile.write(b": ping\n\n")
                    for ev in events:
                        last = ev["id"]
                        self.wfile.write(f"id: {ev['id']}\nevent: {ev['type']}\ndata: {json.dumps(ev)}\n\n".encode("utf-8"))
                    self.wfile.flush()
            except OSError:
                pass
            finally:
                with app.broker.cond:
                    app.broker.listeners -= 1

        # ---- dispatch ----
        def _dispatch(self, method: str) -> None:
            t0 = time.perf_counter()
            parts = urllib.parse.urlsplit(self.path)
            path = parts.path
            query = dict(urllib.parse.parse_qsl(parts.query))
            code = 500
            cookies = self._cookies()
            cid = cookies.get(CID_COOKIE, "")
            new_cookies: list[str] = []
            if not CID_RE.match(cid):
                cid = secrets.token_urlsafe(24)
                new_cookies.append(f"{CID_COOKIE}={cid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=86400")
            role = app.auth.role(cookies.get(ADMIN_COOKIE))
            try:
                if method == "GET" and path in PAGES:
                    page = HERE / PAGES[path]
                    if not page.exists():
                        raise ApiError(404, "missing_page", f"{PAGES[path]} not found next to web_dashboard.py ({page}).")
                    code = 200
                    self._send(200, page.read_bytes(), "text/html", cookies=new_cookies)
                    return
                if method == "GET" and path.startswith("/images/"):
                    name = path[len("/images/"):]
                    file = IMAGES_DIR / name
                    if not IMAGE_NAME_RE.match(name) or not file.is_file():
                        raise ApiError(404, "http_error", "Image not found.")
                    code = 200
                    self._send(200, file.read_bytes(), IMAGE_TYPES[file.suffix.lower()], cache="no-cache")
                    return
                if method == "GET" and path.startswith("/static/"):
                    name = path[len("/static/"):]
                    file = (STATIC_DIR / name)
                    if (not STATIC_NAME_RE.match(name) or ".." in name or file.suffix.lower() not in STATIC_TYPES
                            or not file.is_file()):
                        raise ApiError(404, "http_error", "Static file not found. Run: python fetch_assets.py")
                    code = 200
                    self._send(200, file.read_bytes(), STATIC_TYPES[file.suffix.lower()], cache="public, max-age=86400")
                    return
                if method == "POST" and path == "/api/stt":
                    code = 200
                    self._stt(app, query)
                    return
                if path == "/favicon.ico":
                    code = 204
                    self.send_response(204)
                    self.end_headers()
                    return
                if method == "GET" and path == "/api/events":
                    code = 200
                    self._sse(query)
                    return

                matched, allowed = None, False
                for m, rx, fn, auth, limit in routes:
                    mo = rx.fullmatch(path)
                    if mo:
                        allowed = True
                        if m == method:
                            matched = (fn, auth, limit, mo.groups())
                            break
                if not matched:
                    if allowed:
                        raise ApiError(405, "http_error", f"{method} not allowed on {path}.")
                    raise ApiError(404, "http_error", f"No such page: {path}")
                fn, auth, limit, params = matched
                if auth and role is None:
                    raise ApiError(401, "login_required", "Please sign in with your staff PIN.")
                if auth == "manager" and role != "manager":
                    raise ApiError(403, "forbidden", "This needs the manager PIN.")
                body = self._read_json(limit) if method == "POST" else {}
                ctx = Ctx(app, method, path, query, body, params, cid, role, self.client_address[0])
                ctx.cookies = cookies
                result = fn(ctx)
                if isinstance(result, Raw):
                    code = result.code
                    self._send(code, result.body, result.ctype, result.headers, cookies=new_cookies + ctx.set_cookies)
                else:
                    code, payload = result
                    self._json(code, payload, cookies=new_cookies + ctx.set_cookies)
            except ApiError as exc:
                code = exc.code
                try:
                    self._json(code, {"status": "error", "error": exc.error, "message": exc.message}, cookies=new_cookies)
                except OSError:
                    pass
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                code = 499
            except Exception as exc:
                code = 500
                log.exception("Unhandled error on %s %s", method, path)
                try:
                    self._json(500, {"status": "error", "error": "internal_error", "message": "Something went wrong on the server."})
                except OSError:
                    pass
            finally:
                if method != "GET" or code >= 400 and path not in quiet_paths or path in PAGES:
                    log.info("%s %s -> %s (%d ms)", method, path, code, (time.perf_counter() - t0) * 1000)

        def _stt(self, app, query: dict) -> None:
            """POST /api/stt  (body = 16 kHz mono 16-bit WAV) -> {"text": "..."}.  Offline speech-to-text."""
            stt = getattr(app, "stt", None)
            if not stt or not stt.available:
                return self._json(501, {"status": "error", "error": "stt_unavailable",
                                        "message": "No offline speech recogniser installed on the server."})
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = 0
            if n <= 0 or n > MAX_AUDIO_BODY:
                self.rfile.read(min(max(n, 0), MAX_AUDIO_BODY))
                return self._json(413, {"status": "error", "error": "bad_audio", "message": "Audio too long or empty."})
            data = self.rfile.read(n)
            vocab = [m["name"] for m in db.list_menu_items()] if hasattr(db, "list_menu_items") else []
            try:
                text = stt.transcribe(data, language=query.get("lang", "en"), vocabulary=vocab)
            except speech_engine.SpeechError as exc:
                log.warning("STT failed: %s", exc)
                return self._json(500, {"status": "error", "error": "stt_failed", "message": str(exc)})
            self._json(200, {"status": "ok", "text": text})

        def do_GET(self): self._dispatch("GET")
        def do_POST(self): self._dispatch("POST")

        def do_OPTIONS(self):
            if cors:
                self._send(204, b"", "text/plain")
            else:
                self._json(405, {"error": "http_error", "message": "CORS disabled."})

    return Handler


def lan_ip():
    """This computer's address on the Wi-Fi/LAN (what a phone must use). No packet is actually sent."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
        return None if ip.startswith("127.") else ip
    except OSError:
        return None


def bind_server(bind: str, port: int, handler, tries: int = 10) -> DashboardServer:
    for p in range(port, port + tries):
        try:
            return DashboardServer((bind, p), handler)
        except OSError as exc:
            log.warning("Port %d not available (%s) - trying %d", p, exc.strerror or exc, p + 1)
    sys.exit(f"No free port between {port} and {port + tries - 1}.")


def build_app(args: argparse.Namespace) -> tuple[App, OllamaMonitor]:
    monitor = OllamaMonitor(args.ollama_host, args.model)
    auth = AdminAuth(args.manager_pin, args.kitchen_pin)
    app = App(args.model, monitor, OllamaClient(args.model, args.ollama_host), Path(args.log), args.tables, auth,
              confirm_ai=not args.no_confirm_ai, client_ttl=args.client_ttl_hours * 3600)
    return app, monitor


def main() -> None:
    ap = argparse.ArgumentParser(description="Perpetual Bistro web dashboard")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--bind", default="0.0.0.0", help="0.0.0.0 (default) lets phones on your Wi-Fi scan the table QR codes; use 127.0.0.1 to keep it on this computer only")
    ap.add_argument("--model", default="qwen2.5:1.5b")
    ap.add_argument("--ollama-host", default="http://localhost:11434")
    ap.add_argument("--db", default=str(HERE / "restaurant.db"))
    ap.add_argument("--log", default=str(HERE / "conversation_log.json"))
    ap.add_argument("--logfile", default=str(HERE / "dashboard.log"))
    ap.add_argument("--tables", type=int, default=8, help="number of tables shown to customers and staff (1-50)")
    ap.add_argument("--manager-pin", default=os.environ.get("BISTRO_MANAGER_PIN", "admin123"))
    ap.add_argument("--kitchen-pin", default=os.environ.get("BISTRO_KITCHEN_PIN", "kitchen123"))
    ap.add_argument("--no-confirm-ai", action="store_true", help="let the AI add items without asking the customer to confirm")
    ap.add_argument("--client-ttl-hours", type=float, default=4.0, help="forget idle customer sessions after this long")
    ap.add_argument("--reset-db", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--cors", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    args.tables = max(1, min(args.tables, 50))

    setup_logging(Path(args.logfile), args.verbose)
    db.set_db_path(args.db)
    db.init_db(reset=args.reset_db)
    orphans = db.close_orphan_sessions()
    if orphans:
        log.info("closed %d table session(s) left over from the last run", orphans)
    try:
        IMAGES_DIR.mkdir(exist_ok=True)
    except OSError:
        pass

    app, monitor = build_app(args)
    st = monitor.status()
    if not st["online"] or not st["model_installed"]:
        log.warning("AI is unavailable: %s  (ordering by buttons and simple typed orders still works)", st["hint"])

    app.stt = speech_engine.LocalTranscriber()
    if app.stt.available:
        log.info("Offline speech-to-text: %s (%s) - the browser microphone audio never leaves this computer.",
                 app.stt.backend, app.stt.model_name)
        threading.Thread(target=lambda: (app.stt.load(), log.info("Offline STT model loaded.")), daemon=True).start()
    else:
        log.warning("No offline speech recogniser installed (pip install faster-whisper). The browser's own microphone "
                    "recogniser will be used, and that one NEEDS INTERNET.")
    if st["online"] and st["model_installed"]:        # load the model in the background so the first customer isn't slow
        threading.Thread(target=lambda: log.info("AI model warmed up: %s", "ready" if app.llm_client.warm_up() else "failed"),
                         daemon=True).start()
    server = bind_server(args.bind, args.port, make_handler(app, args.cors))
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}"
    ip = lan_ip() if args.bind in ("0.0.0.0", "") else None
    app.lan_url = f"http://{ip}:{port}" if ip else None
    log.info("Perpetual Bistro running at %s   (kitchen: /kitchen   admin: /admin   Ctrl+C to stop)", url)
    if app.lan_url:
        log.info("Phones on the same Wi-Fi (table QR codes): %s   (if a phone cannot open it, allow Python through the Windows firewall)", app.lan_url)
    if args.manager_pin == "admin123" or args.kitchen_pin == "kitchen123":
        log.warning("Using the DEFAULT staff PINs (manager: admin123, kitchen: kitchen123). "
                    "Change them with --manager-pin / --kitchen-pin before showing this to anyone.")

    if not args.no_browser:
        threading.Timer(0.8, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        app.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()